using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

//dscgirls.live shows rooms from three sources, told apart by the profile page:
//  - streamate performers under /model/x/{slug}: streamate's manifest server lists an hls playlist per
//    resolution, which ffmpeg records directly
//  - imlive performers, also under /model/x/{slug}: status only, their player is webrtc
//  - dscgirls' own models under /model/{slug}: status only, they broadcast over livekit (webrtc)
//the source (and streamate's own name for the room, which doesn't always match the slug) is kept in
//the room's cache slot, so a streamate room needs one manifest request per check
public sealed partial class DscGirlsProbe : SiteProbe
{
    private const string SiteUrl = "https://www.dscgirls.live";
    private const string StreamatePrefix = "streamate:";
    private const string ImLiveSource = "imlive";
    private const string DscSource = "dsc";

    //streamate's manifest server only answers players embedded on its partner sites
    private static readonly string[] ManifestHeaders =
    {
        "Accept: application/json, text/plain, */*",
        $"Origin: {SiteUrl}",
        $"Referer: {SiteUrl}/"
    };

    public override ChatRoomWebsite Website => ChatRoomWebsite.DscGirls;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(context.Cache) && !await IdentifyAsync(context, cancellationToken))
        {
            return ProbeResult.Error;
        }

        return context.Cache!.StartsWith(StreamatePrefix, StringComparison.Ordinal)
            ? await ProbeStreamateAsync(context, context.Cache[StreamatePrefix.Length..], cancellationToken)
            : await ProbePageAsync(context, cancellationToken);
    }

    //finds out where the room lives - the streamate/imlive path first, dscgirls' own models second
    private static async Task<bool> IdentifyAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        JsonObject? page = await GetPageAsync(context, $"{SiteUrl}/model/x/{context.Name}", cancellationToken);
        JsonObject? model = Obj(page?["props"]?["model"]);

        if (Str(page?["component"]) is { } component && component.StartsWith("external/", StringComparison.Ordinal) && model != null)
        {
            string? site = Str(model["site"]);
            string? name = Str(model["name"]);

            if (site == "streamate" && !string.IsNullOrEmpty(name))
            {
                context.Cache = StreamatePrefix + name;
                context.Info($"a streamate room, streamate name '{name}'");

                return true;
            }

            context.Cache = ImLiveSource;
            context.Info($"a {site} room - its status is shown, but it can't be recorded");

            return true;
        }

        page = await GetPageAsync(context, $"{SiteUrl}/model/{context.Name}", cancellationToken);

        if (Str(page?["component"]) == "chat-model/profile-page")
        {
            context.Cache = DscSource;
            context.Info("a dscgirls model - its status is shown, but it can't be recorded (the stream is livekit/webrtc)");

            return true;
        }

        context.Error("no such room on dscgirls.live (neither /model/x/ nor /model/ has it)");

        return false;
    }

    private static async Task<ProbeResult> ProbeStreamateAsync(ProbeContext context, string name, CancellationToken cancellationToken)
    {
        string manifestUrl = $"https://manifest-server.naiadsystems.com/live/s:{Uri.EscapeDataString(name)}.json";
        HttpResult result = await CurlClient.SendAsync(manifestUrl, cancellationToken, ManifestHeaders).ConfigureAwait(false);

        //the manifest exists only while the room is free to watch: 403 for paid shows, 404 offline
        ChatRoomStatus status = result.StatusCode switch
        {
            200 => ChatRoomStatus.Public,
            403 => ChatRoomStatus.Private,
            404 => ChatRoomStatus.Offline,
            _ => ChatRoomStatus.Error
        };

        if (status == ChatRoomStatus.Error)
        {
            context.Error($"streamate's manifest server answered http {result.StatusCode}{CurlError(result)} - {Snippet(result.Body)}");

            return ProbeResult.Error;
        }

        context.Info($"status - {status} (manifest http {result.StatusCode})");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        JsonArray? encodings = JsonNode.Parse(result.Body)?["formats"]?["mp4-hls"]?["encodings"] as JsonArray;

        List<(Resolution Resolution, string Url)> streams = (encodings ?? new JsonArray())
            .OfType<JsonObject>()
            .Select(encoding => (
                Resolution: new Resolution((short)(Int(encoding["videoWidth"]) ?? 0), (short)(Int(encoding["videoHeight"]) ?? 0)),
                Url: Str(encoding["location"]) ?? string.Empty))
            .Where(stream => stream.Url.Length > 0)
            .ToList();

        //each encoding is its own media playlist of mpeg-ts segments with audio muxed in
        return Finish(context, status, manifestUrl, streams.Select(stream => stream.Resolution).ToList(),
            index => new RecordTarget(RecordMethod.FFmpegMedia, streams[index].Url, index, string.Empty));
    }

    //imlive and dscgirls' own rooms: the status from the profile page, never a recording
    private static async Task<ProbeResult> ProbePageAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        bool own = context.Cache == DscSource;
        JsonObject? page = await GetPageAsync(context, own ? $"{SiteUrl}/model/{context.Name}" : $"{SiteUrl}/model/x/{context.Name}", cancellationToken);

        if (page == null)
        {
            return ProbeResult.Error;
        }

        ChatRoomStatus status;

        if (own)
        {
            JsonObject? broadcast = Obj(page["props"]?["broadcast"]);

            status = broadcast == null || Str(broadcast["status"]) != "started"
                ? ChatRoomStatus.Offline
                : Str(broadcast["mode"]) switch
                {
                    "public" => ChatRoomStatus.Public,
                    "group" => ChatRoomStatus.Group,
                    "private" or "exclusive" or "gold" => ChatRoomStatus.Private,
                    _ => ChatRoomStatus.Unknown
                };
        }
        else
        {
            status = Str(page["props"]?["model"]?["room_status"]) == "online" ? ChatRoomStatus.Public : ChatRoomStatus.Offline;
        }

        context.Info($"status - {status}");

        if (status == ChatRoomStatus.Public)
        {
            context.Warning("the room is live, but its stream is webrtc - it can't be recorded");
        }

        return ProbeResult.Of(status);
    }

    //the pages are inertia pages: everything the page knows sits in one json script element
    private static async Task<JsonObject?> GetPageAsync(ProbeContext context, string url, CancellationToken cancellationToken)
    {
        HttpResult result = await CurlClient.SendAsync(url, cancellationToken).ConfigureAwait(false);

        if (result.StatusCode == 404)
        {
            return null;
        }

        if (result.StatusCode != 200)
        {
            context.Error($"dscgirls.live answered http {result.StatusCode} for {url}{CurlError(result)} - {Snippet(result.Body)}");

            return null;
        }

        Match match = PageData().Match(result.Body);

        if (!match.Success)
        {
            context.Error($"the page at {url} had no page data - the site may have changed or shown a challenge page");

            return null;
        }

        try
        {
            return JsonNode.Parse(match.Groups[1].Value) as JsonObject;
        }
        catch (Exception exception)
        {
            context.Error($"the page data at {url} isn't valid json: {exception.Message}");

            return null;
        }
    }

    [GeneratedRegex("<script data-page=\"app\" type=\"application/json\">(.*?)</script>", RegexOptions.Singleline)]
    private static partial Regex PageData();
}
