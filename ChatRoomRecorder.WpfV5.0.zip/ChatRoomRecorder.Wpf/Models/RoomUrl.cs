using System.Text.RegularExpressions;

namespace ChatRoomRecorder.Wpf.Models;

public sealed record RoomUrl(ChatRoomWebsite Website, string Name, string Url)
{
    //top-level pages of the stripchat storefronts that aren't rooms
    private static readonly HashSet<string> StorefrontPages = new(StringComparer.Ordinal)
    {
        "girls", "couples", "men", "trans", "terms", "privacy", "cookies-policy", "2257", "dmca",
        "parental-control", "join-free", "signup-model", "signup-studio", "hc", "search", "watch-history",
        "favorites", "login", "signup", "tags", "categories"
    };

    //the same rules as the classic app's ChatRoom.ParseUrl - the canonical url is what goes into the
    //database, so rooms imported from the classic app keep matching
    public static RoomUrl? Parse(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        url = url.Trim().ToLowerInvariant();

        if (url[^1] != '/')
        {
            url += '/';
        }

        Match m;

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9-.]+.)?chaturbate.com/([^/]+)/.*$")).Success ||
            (m = Regex.Match(url, @"^chaturbate[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.Chaturbate, m, "https://chaturbate.com/{0}/");
        }

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9-.]+.)?bongacams[0-9]*.(?:com|cam)/([^/]+(?=#!/.*$)|[^/]+(?=/.*$))")).Success ||
            (m = Regex.Match(url, @"^bongacams[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.BongaCams, m, "https://bongacams.com/{0}/");
        }

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9\-.]+)?stripchat\.(?:com|global)/([^/]+)/.*$")).Success ||
            (m = Regex.Match(url, @"^stripchat[ ]+([^ ]+).*/$")).Success ||
            (m = Regex.Match(url, @"^https://(?:www\.)?lemoncam\.com/([^/]+)/?$")).Success)
        {
            return Create(ChatRoomWebsite.Stripchat, m, "https://www.stripchat.com/{0}/");
        }

        //booble and xhamsterlive are stripchat storefronts: the same models under the same names, so
        //their links become stripchat rooms. their site pages share the room path, so those are skipped
        if (((m = Regex.Match(url, @"^https://(?:[a-z0-9-]+\.)?booble\.com/([^/#]+)[/#].*$")).Success ||
             (m = Regex.Match(url, @"^https://(?:[a-z0-9-]+\.)?xhamsterlive\.com/([^/#]+)[/#].*$")).Success) &&
            !StorefrontPages.Contains(m.Groups[1].Value))
        {
            return Create(ChatRoomWebsite.Stripchat, m, "https://www.stripchat.com/{0}/");
        }

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9-.]+.)?flirt4free.com/\?model=([^/]+)/.*$")).Success ||
            (m = Regex.Match(url, @"^flirt4free[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.Flirt4Free, m, "https://flirt4free.com/?model={0}/");
        }

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9-.]+.)?camsoda.com/([^/]+)/.*$")).Success ||
            (m = Regex.Match(url, @"^camsoda[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.CamSoda, m, "https://camsoda.com/{0}/");
        }

        if ((m = Regex.Match(url, @"^https://(?:[a-z0-9-.]+.)?cam4.com/([^/]+)/.*$")).Success ||
            (m = Regex.Match(url, @"^cam4[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.Cam4, m, "https://cam4.com/{0}/");
        }

        //streamate and imlive rooms live under /model/x/, the site's own models under /model/ - the
        //canonical url keeps that, the probe works the source out by itself
        if ((m = Regex.Match(url, @"^https://(?:www\.)?dscgirls\.live/model/(x/)?([^/]+)/.*$")).Success)
        {
            string slug = m.Groups[2].Value;

            return new RoomUrl(ChatRoomWebsite.DscGirls, slug, $"https://www.dscgirls.live/model/{m.Groups[1].Value}{slug}/");
        }

        if ((m = Regex.Match(url, @"^dscgirls[ ]+([^ ]+).*/$")).Success)
        {
            return Create(ChatRoomWebsite.DscGirls, m, "https://www.dscgirls.live/model/x/{0}/");
        }

        return null;
    }

    //links copied from a browser carry tracking parameters that aren't part of the room name -
    //flirt4free is the exception, there the query string names the room
    public static RoomUrl? ParseLink(string line)
    {
        string url = line.Trim();

        if (!url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        int query = url.IndexOf('?');

        if (query > 0 && url.IndexOf("flirt4free.com", StringComparison.OrdinalIgnoreCase) == -1)
        {
            url = url[..query];
        }

        return Parse(url);
    }

    private static RoomUrl Create(ChatRoomWebsite website, Match match, string format)
    {
        string name = match.Groups[1].Value;

        return new RoomUrl(website, name, string.Format(format, name));
    }
}
