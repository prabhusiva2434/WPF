﻿namespace ChatRoomRecorder
{
    public enum VideoEncoder
    {
        Copy,
        H264,
        H265,
        H264_NVENC,
        H265_NVENC,
        H264_QSV,
        H265_QSV
    }
}
