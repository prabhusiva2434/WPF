﻿using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace ChatRoomRecorder
{
    public class ChatRoom : IDisposable
    {
        public static Tuple<ChatRoomWebsite, string, string> ParseUrl(string url)
        {
            if (url == null || url.Length == 0)
            {
                return null;
            }

            url = url.Trim().ToLower();
            if (url[url.Length - 1] != '/')
            {
                url += '/';
            }

            MatchCollection matches;

            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?chaturbate.com/([^/]+)/.*$")).Count > 0 ||
                (matches = Regex.Matches(url, @"^chaturbate[ ]+([^ ]+).*/$")).Count > 0)

            {
                return Tuple.Create(ChatRoomWebsite.Chaturbate, matches[0].Groups[1].Value, string.Format("https://chaturbate.com/{0}/", matches[0].Groups[1].Value));
            }

            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?bongacams[0-9]*.(?:com|cam)/([^/]+(?=#!/.*$)|[^/]+(?=/.*$))")).Count > 0 ||
                (matches = Regex.Matches(url, @"^bongacams[ ]+([^ ]+).*/$")).Count > 0)
            {
                return Tuple.Create(ChatRoomWebsite.BongaCams, matches[0].Groups[1].Value, string.Format("https://bongacams.com/{0}/", matches[0].Groups[1].Value));
            }
            if (
            // Match original Stripchat URLs
            (matches = Regex.Matches(url, @"^https://(?:[a-z0-9\-.]+)?stripchat\.(?:com|global)/([^/]+)/.*$")).Count > 0
            ||
            (matches = Regex.Matches(url, @"^stripchat[ ]+([^ ]+).*/$")).Count > 0
            ||

            // Match lemoncams Stripchat style URLs
            (matches = Regex.Matches(url, @"^https://(?:www\.)?lemoncam\.com/([^/]+)/?$")).Count > 0
        )
            {
                return Tuple.Create(
                    ChatRoomWebsite.Stripchat,
                    matches[0].Groups[1].Value,
                    string.Format("https://www.lemoncam.com/{0}/", matches[0].Groups[1].Value)
                );
            }
            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?stripchat.(?:com|global)/([^/]+)/.*$")).Count > 0 ||
                (matches = Regex.Matches(url, @"^stripchat[ ]+([^ ]+).*/$")).Count > 0)
            {
                return Tuple.Create(ChatRoomWebsite.Stripchat, matches[0].Groups[1].Value, string.Format("https://www.lemoncam.com/{0}/", matches[0].Groups[1].Value));
            }

            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?flirt4free.com/\?model=([^/]+)/.*$")).Count > 0 ||
                (matches = Regex.Matches(url, @"^flirt4free[ ]+([^ ]+).*/$")).Count > 0)
            {
                return Tuple.Create(ChatRoomWebsite.Flirt4Free, matches[0].Groups[1].Value, string.Format("https://flirt4free.com/?model={0}/", matches[0].Groups[1].Value));
            }

            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?camsoda.com/([^/]+)/.*$")).Count > 0 ||
                (matches = Regex.Matches(url, @"^camsoda[ ]+([^ ]+).*/$")).Count > 0)
            {
                return Tuple.Create(ChatRoomWebsite.CamSoda, matches[0].Groups[1].Value, string.Format("https://camsoda.com/{0}/", matches[0].Groups[1].Value));
            }

            if ((matches = Regex.Matches(url, @"^https://(?:[a-z0-9-.]+.)?cam4.com/([^/]+)/.*$")).Count > 0 ||
                (matches = Regex.Matches(url, @"^cam4[ ]+([^ ]+).*/$")).Count > 0)
            {
                return Tuple.Create(ChatRoomWebsite.Cam4, matches[0].Groups[1].Value, string.Format("https://cam4.com/{0}/", matches[0].Groups[1].Value));
            }

            return null;
        }

        public ChatRoom(string url)
        {
            Tuple<ChatRoomWebsite, string, string> parsedUrl = ParseUrl(url);
            if (parsedUrl != null)
            {
                _id = 0;
                _website = parsedUrl.Item1;
                _name = parsedUrl.Item2;
                _status = ChatRoomStatus.Unknown;
                _action = ChatRoomAction.None;
                _chatRoomUrl = parsedUrl.Item3;
                _playlistUrl = String.Empty;
                _availableResolutions = new List<ChatRoomResolution>();
                _preferredResolution = ChatRoomResolution.MaxValue;
                _outputDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
                _ffmpegPath = string.Format("{0}\\Streamlink\\ffmpeg\\ffmpeg.exe", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
                _streamlinkPath = string.Format("{0}\\Streamlink\\bin\\streamlink.exe", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
                _videoEncoder = VideoEncoder.Copy;
                _videoQuality = 28;
                _videoPreset = VideoPreset.VeryFast;
                _audioBitrate = 0;
                _maxVideoHeight = 0;
                _delay = 0;
                _processes = new List<Process>();
                _fileName = string.Empty;
                _fileSize = -1;
                _lastUpdated = DateTime.MinValue;
                _lastSeen = DateTime.MinValue;
                _isUpdating = false;
                _disposingStarted = false;
                _disposingFinished = false;
                _cancellationTokenSource = new CancellationTokenSource();
                _cancellationToken = _cancellationTokenSource.Token;
                _browser = null;
                _browserInitialized = false;
                _stripchatModelId = string.Empty;
                _uri = string.Empty;
                _timer = new System.Windows.Forms.Timer();
                _timer.Interval = 1000;
                _timer.Tick += _timer_Tick;
                _semaphore = new SemaphoreSlim(1, 1);
                _log = new ConcurrentQueue<Tuple<DateTime, string>>();
                Interlocked.Increment(ref s_totalCount);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public void Dispose()
        {
            _semaphore.Wait();
            try
            {
                if (!_disposingStarted)
                {
                    _disposingStarted = true;
                    _cancellationTokenSource.Cancel();
                    _timer.Start();
                }
            }
            finally
            {
                _semaphore.Release();
            }
        }

        public void Update()
        {
            _semaphore.Wait();
            try
            {
                if (_disposingStarted || (DateTime.Now - _lastUpdated).TotalSeconds < c_updateLimit)
                {
                    return;
                }

                _isUpdating = true;
                _lastUpdated = DateTime.Now;

                //we're recording and that's what we want - return, otherwise - continue

                if (_action == ChatRoomAction.Record && _status == ChatRoomStatus.Record)
                {
                    if (_processes.Count > 0)
                    {
                        bool processesAreRunning = true;

                        foreach (Process process in _processes)
                        {
                            processesAreRunning = processesAreRunning && !process.HasExited;
                        }

                        if (processesAreRunning)
                        {
                            try
                            {
                                FileInfo fi = new(_fileName);
                                if (fi.Length > _fileSize)
                                {
                                    _fileSize = fi.Length;
                                    _isUpdating = false;

                                    return;
                                }
                            }
                            catch (Exception)
                            {
                                //do nothing
                            }
                        }
                    }
                }

                //stop any recording (if we need to restart it, we'll do it later)

                foreach (Process process in _processes)
                {
                    if (process.HasExited == false)
                    {
                        process.Kill();
                        process.WaitForExit();
                    }
                    process.Close();
                }
                _processes.Clear();
                _fileName = string.Empty;
                _fileSize = -1;

                //we don't want to monitor or record, so clear data and return

                if (_action == ChatRoomAction.None)
                {
                    _status = ChatRoomStatus.Unknown;
                    _playlistUrl = String.Empty;
                    _availableResolutions.Clear();

                    if (_browser != null)
                    {
                        _browser.Dispose();
                        _browser = null;
                        _browserInitialized = false;
                    }

                    _isUpdating = false;

                    return;
                }

                //initialize the browser, if it's not ready. stripchat is polled with curl, so those
                //rooms don't need one at all - and skipping it saves a webview2 per room

                bool needsBrowser = _website != ChatRoomWebsite.Stripchat;

                if (needsBrowser && _browser == null)
                {
                    _browser = new WebView2();
                    _browser.CoreWebView2InitializationCompleted += _browser_CoreWebView2InitializationCompleted;
                    _browser.Source = new Uri("about:blank", UriKind.Absolute);

                    return;
                }

                //update room's info

                if (_browserInitialized || !needsBrowser)
                {
                    switch (_website)
                    {
                        case ChatRoomWebsite.Chaturbate:
                            SendRequestChaturbate();
                            break;
                        case ChatRoomWebsite.BongaCams:
                            SendRequestBongaCams();
                            break;
                        case ChatRoomWebsite.Stripchat:
                            SendRequestStripchat();
                            break;
                        case ChatRoomWebsite.Flirt4Free:
                            SendRequestFlirt4Free();
                            break;
                        case ChatRoomWebsite.CamSoda:
                            SendRequestCamSoda();
                            break;
                        case ChatRoomWebsite.Cam4:
                            SendRequestCam4();
                            break;
                    }
                }
            }
            finally
            {
                _semaphore.Release();

                if (!_isUpdating)
                {
                    UpdateCompleted?.Invoke(this, EventArgs.Empty);
                }
            }
        }

        private async void _timer_Tick(object sender, EventArgs e)
        {
            if (_semaphore.CurrentCount > 0)
            {
                await _semaphore.WaitAsync();
                try
                {
                    if (_timer.Enabled && !_disposingFinished && (!_isUpdating || _isUpdating && (DateTime.Now - _lastUpdated).TotalSeconds >= c_updateLimit))
                    {
                        _timer.Stop();

                        foreach (Process process in _processes)
                        {
                            if (process.HasExited == false)
                            {
                                process.Kill();
                                process.WaitForExit();
                            }
                            process.Close();
                        }

                        if (_browser != null)
                        {
                            _browser.Dispose();
                        }

                        _disposingFinished = true;
                        Interlocked.Decrement(ref s_totalCount);
                    }
                }
                finally
                {
                    _semaphore.Release();
                }
            }
        }

        private async void _browser_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            await _semaphore.WaitAsync();
            try
            {
                _browser.CoreWebView2.WebResourceResponseReceived += _browser_WebResourceResponseReceived;
                _browser.CoreWebView2.NavigationCompleted += _browser_NavigationCompleted;

                //override the default webview2 user agent (which carries an "edg/..." token) with a
                //plain desktop chrome string - this is also exactly what brave sends, brave does not
                //add a "brave" token. helps against sites that block on the edge/webview user agent.
                try
                {
                    _browser.CoreWebView2.Settings.UserAgent = c_userAgent;
                }
                catch (Exception exception)
                {
                    AddLogEntry(string.Format("{0} - couldn't set the user agent - {1}: {2}",
                        c_errorOccuredLogMessage, exception.GetType().Name, exception.Message));
                }

                _browserInitialized = true;
                _isUpdating = false;
            }
            finally
            {
                _semaphore.Release();
            }

            UpdateCompleted?.Invoke(this, EventArgs.Empty);
        }

        private async void _browser_WebResourceResponseReceived(object sender, CoreWebView2WebResourceResponseReceivedEventArgs e)
        {
            string template = @"https://[^/]+/(.*)";
            MatchCollection matches1;
            MatchCollection matches2;

            if (!_isUpdating)
            {
                return;
            }

            //only care about the response to the API request we issued (same path as _uri)
            bool uriMatches =
                (matches1 = Regex.Matches(_uri, template, RegexOptions.IgnoreCase)).Count > 0 &&
                (matches2 = Regex.Matches(e.Request.Uri, template, RegexOptions.IgnoreCase)).Count > 0 &&
                matches1[0].Groups[1].Value == matches2[0].Groups[1].Value;

            if (!uriMatches)
            {
                return;
            }

            int statusCode = e.Response.StatusCode;
            string reasonPhrase = e.Response.ReasonPhrase;
            string contentType = string.Empty;
            try
            {
                if (e.Response.Headers.Contains("Content-Type"))
                {
                    contentType = e.Response.Headers.GetHeader("Content-Type");
                }
            }
            catch
            {
                //do nothing
            }

            string response;
            try
            {
                response = await (new StreamReader(await e.Response.GetContentAsync())).ReadToEndAsync();
            }
            catch (Exception exception)
            {
                //no readable body - typical for a blocked / rate-limited response (e.g. stripchat http 418)
                //or a redirect. if the status already says it failed, end the update as an error instead
                //of leaving it stuck until the 60s watchdog; otherwise just wait for a later response.
                AddLogEntry(string.Format("{0} - couldn't read the response body of {1} - http {2} {3} - {4}: {5}",
                    c_errorOccuredLogMessage, e.Request.Uri, statusCode, reasonPhrase, exception.GetType().Name, exception.Message));

                if (statusCode < 200 || statusCode >= 300)
                {
                    await _semaphore.WaitAsync();
                    try
                    {
                        if (_isUpdating)
                        {
                            _status = ChatRoomStatus.Error;
                            _playlistUrl = String.Empty;
                            _availableResolutions.Clear();
                            _isUpdating = false;

                            AddLogEntry(string.Format("{0} - {1} rejected the request with http {2} (no body) - the request is most likely blocked or rate-limited",
                                c_errorOccuredLogMessage, _website, statusCode));
                        }
                    }
                    finally
                    {
                        _semaphore.Release();
                    }

                    UpdateCompleted?.Invoke(this, EventArgs.Empty);
                }

                return;
            }

            bool looksLikeHtml = response.TrimStart().StartsWith("<");

            //log every response we got for the API request: status, type, size, and whether
            //the body is HTML (a Cloudflare / login / geo-block page) instead of the expected JSON
            AddLogEntry(string.Format("{0} - {1} - http {2} {3} - content-type '{4}' - {5} bytes{6}",
                c_responseReceivedLogMessage, e.Request.Uri, statusCode, reasonPhrase, contentType ?? string.Empty, response.Length,
                looksLikeHtml ? " - body is HTML/redirect, not JSON" : string.Empty));

            if (statusCode != 200 || looksLikeHtml)
            {
                AddLogEntry(string.Format("{0} - unexpected response for {1} - http {2} - first {3} chars: {4}",
                    c_errorOccuredLogMessage, e.Request.Uri, statusCode, c_logSnippetLength, Snippet(response)));
            }

            if (statusCode >= 300 && statusCode < 400 && !looksLikeHtml)
            {
                //redirect with an empty body - wait for the response to the redirected request
                return;
            }

            await ProcessResponseAndCompleteUpdate(response);
        }

        //parses a response body with the website's parser and ends the update
        private async Task ProcessResponseAndCompleteUpdate(string response)
        {
            try
            {
                await Task.Factory.StartNew(async () =>
                {
                    await _semaphore.WaitAsync();
                    try
                    {
                        switch (_website)
                        {
                            case ChatRoomWebsite.Chaturbate:
                                ProcessResponseChaturbate(response);
                                break;
                            case ChatRoomWebsite.BongaCams:
                                ProcessResponseBongaCams(response);
                                break;
                            case ChatRoomWebsite.Stripchat:
                                ProcessResponseStripchat(response);
                                break;
                            case ChatRoomWebsite.Flirt4Free:
                                ProcessResponseFlirt4Free(response);
                                break;
                            case ChatRoomWebsite.CamSoda:
                                ProcessResponseCamSoda(response);
                                break;
                            case ChatRoomWebsite.Cam4:
                                ProcessResponseCam4(response);
                                break;
                        }

                        _isUpdating = false;
                    }
                    finally
                    {
                        _semaphore.Release();
                    }
                }, TaskCreationOptions.LongRunning).WaitAsync(_cancellationToken);

                UpdateCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception exception)
            {
                AddLogEntry(string.Format("{0} - {1}: {2}", c_errorOccuredLogMessage, exception.GetType().Name, exception.Message));
            }
        }

        //ends the update as an error - so a failed request doesn't leave the room stuck until the
        //60s watchdog lets the next one through
        private async void FailUpdate(string message)
        {
            await _semaphore.WaitAsync();
            try
            {
                if (!_isUpdating)
                {
                    return;
                }

                _status = ChatRoomStatus.Error;
                _playlistUrl = String.Empty;
                _availableResolutions.Clear();
                _isUpdating = false;

                AddLogEntry(string.Format("{0} - {1}", c_errorOccuredLogMessage, message));
            }
            finally
            {
                _semaphore.Release();
            }

            UpdateCompleted?.Invoke(this, EventArgs.Empty);
        }

        private async void _browser_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            await _semaphore.WaitAsync();
            try
            {
                if (!_isUpdating)
                {
                    return;
                }

                //always log the outcome of the navigation so we can tell a network failure
                //(IsSuccess == false) from a server that answered with an error page / challenge
                //(IsSuccess == true but HttpStatusCode 403/429/503 and an HTML body)
                AddLogEntry(string.Format("{0} - {1} - success {2} - http {3} - weberror {4} - landed on {5}",
                    c_navigationLogMessage,
                    _uri,
                    e.IsSuccess,
                    e.HttpStatusCode,
                    e.WebErrorStatus,
                    (_browser != null && _browser.Source != null) ? _browser.Source.ToString() : "(none)"));

                if (!e.IsSuccess)
                {
                    _status = ChatRoomStatus.Error;
                    _playlistUrl = String.Empty;
                    _availableResolutions.Clear();

                    _browser.Dispose();
                    _browser = null;
                    _browserInitialized = false;

                    _isUpdating = false;

                    AddLogEntry(string.Format("{0} - navigation to {1} failed - weberror {2} - http {3}",
                        c_errorOccuredLogMessage, _uri, e.WebErrorStatus, e.HttpStatusCode));
                }
            }
            finally
            {
                _semaphore.Release();
            }
        }

        private async void SendRequestChaturbate()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (_browser.Source == new Uri("about:blank"))
                {
                    _uri = string.Format("https://chaturbate.com/api/chatvideocontext/{0}/", _name);

                    CoreWebView2WebResourceRequest request = _browser.CoreWebView2.Environment.CreateWebResourceRequest(
                        _uri,
                        "GET",
                        null,
                        string.Empty);
                    _browser.CoreWebView2.NavigateWithWebResourceRequest(request);
                }
                else
                {
                    _browser.Reload();
                }
            }
            catch
            {
                //do nothing
            }
        }

        private async void SendRequestBongaCams()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (_browser.Source == new Uri("about:blank"))
                {
                    _uri = "https://bongacams.com/tools/listing_v3.php";

                    string postData = "model_search[display_name]=" + _name;
                    CoreWebView2WebResourceRequest request = _browser.CoreWebView2.Environment.CreateWebResourceRequest(
                        _uri,
                        "POST",
                        new MemoryStream(Encoding.UTF8.GetBytes(postData)),
                        "Content-Type: application/x-www-form-urlencoded\r\nX-Requested-With: XMLHttpRequest");
                    _browser.CoreWebView2.NavigateWithWebResourceRequest(request);
                }
                else
                {
                    _browser.Reload();
                }
            }
            catch
            {
                //do nothing
            }
        }

        //the /models/username/{name}/cam endpoint the app used to poll is blocked by cloudflare's
        //bot management - that one path answers http 418 for everything. the id-addressed endpoint
        ///models/{id}/cam isn't blocked, so the poll takes two steps: resolve the username to the
        //numeric model id once, then ask for the cam by id (the id also survives a rename, which is
        //why the site moved to it).
        //
        //since then stripchat.com answers http 418 for the username lookup (/users/username/{name})
        //too. its mirrors run the same api without that rule, so the requests go to the hosts in
        //s_stripchatApiHosts in turn until one of them gives a real answer.
        //
        //the requests are made with windows' own curl rather than with s_httpClient. cloudflare
        //fingerprints the client, and every .net stack gets a 403 challenge page on these paths no
        //matter what headers it sends - SocketsHttpHandler and WinHttpHandler alike, with tls 1.2
        //forced, with alpn off, over http/1.1 and over http/2. curl gets through with a browser
        //user agent (with its own default one it's a 403 too), and it's a lot cheaper than driving
        //a webview per room.
        private async void SendRequestStripchat()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (string.IsNullOrEmpty(_stripchatModelId))
                {
                    _stripchatModelId = await ResolveStripchatModelId();

                    if (string.IsNullOrEmpty(_stripchatModelId))
                    {
                        FailUpdate(string.Format(c_modelIdUnavailableErrorMessage, _name));

                        return;
                    }
                }

                Tuple<int, string> result = await SendStripchatApiRequest(c_stripchatCamUri, _stripchatModelId);

                if (result.Item1 == 404)
                {
                    //the cached id no longer resolves - the model was renamed or re-registered.
                    //drop it, the next cycle starts over from the username lookup
                    AddLogEntry(string.Format("{0} - model id {1} is stale (http 404) - it will be resolved again",
                        c_errorOccuredLogMessage, _stripchatModelId));

                    _stripchatModelId = string.Empty;
                }

                if (result.Item1 != 200)
                {
                    FailUpdate(string.Format("the api answered http {0} for {1} - first {2} chars: {3}",
                        result.Item1, _uri, c_logSnippetLength, Snippet(result.Item2)));

                    return;
                }

                await ProcessResponseAndCompleteUpdate(result.Item2);
            }
            catch (OperationCanceledException)
            {
                //do nothing - the room is being disposed
            }
            catch (Exception exception)
            {
                FailUpdate(string.Format("{0}: {1}", exception.GetType().Name, exception.Message));
            }
        }

        //resolves a username to the numeric model id. the username is checked against the answer so
        //a rename or a redirect can't silently swap the room out from under us.
        private async Task<string> ResolveStripchatModelId()
        {
            Tuple<int, string> result = await SendStripchatApiRequest(c_stripchatUserUri, Uri.EscapeDataString(_name));

            if (result.Item1 != 200)
            {
                return string.Empty;
            }

            JsonNode itemNode;

            try
            {
                itemNode = JsonNode.Parse(result.Item2)?["item"];
            }
            catch (Exception exception)
            {
                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    result.Item2 != null ? result.Item2.Length : 0, Snippet(result.Item2)));

                return string.Empty;
            }

            if (itemNode == null || itemNode["id"] == null)
            {
                return string.Empty;
            }

            string reportedName = itemNode["username"] != null ? (string)itemNode["username"] : null;

            if (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, _name, StringComparison.OrdinalIgnoreCase))
            {
                AddLogEntry(string.Format("{0} - {1}", c_errorOccuredLogMessage,
                    string.Format(c_wrongModelErrorMessage, reportedName, _name)));

                return string.Empty;
            }

            string modelId = itemNode["id"].ToString();

            AddLogEntry(string.Format("{0} - model id of {1} is {2}", c_statusObtainedLogMessage, _name, modelId));

            return modelId;
        }

        //sends an api request to the stripchat hosts in turn and returns the first real answer - a 200,
        //or a 404, which is about the room and would be the same on every host. anything else (the
        //418 block, a 403 challenge page, a curl failure) moves on to the next host.
        private async Task<Tuple<int, string>> SendStripchatApiRequest(string uriFormat, string argument)
        {
            Tuple<int, string> result = null;

            foreach (string host in s_stripchatApiHosts)
            {
                _uri = string.Format(uriFormat, host, argument);
                result = await SendStripchatRequest(_uri);

                if (result.Item1 == 200 || result.Item1 == 404)
                {
                    break;
                }
            }

            return result;
        }

        //runs curl and returns the http status code along with the response body. curl writes the
        //body to stdout and then the status code on a line of its own, so the body is everything up
        //to the last newline.
        private async Task<Tuple<int, string>> SendStripchatRequest(string uri)
        {
            if (!File.Exists(s_curlPath))
            {
                AddLogEntry(string.Format("{0} - {1} isn't there - stripchat can't be polled without it",
                    c_errorOccuredLogMessage, s_curlPath));

                return Tuple.Create(0, string.Empty);
            }

            const string quote = "\"";

            ProcessStartInfo psi = new()
            {
                FileName = s_curlPath,
                Arguments =
                    "-s -S --max-time " + c_stripchatTimeout +
                    " -A " + quote + c_userAgent + quote +
                    " -H " + quote + "Accept: application/json" + quote +
                    " -H " + quote + "Referer: https://stripchat.com/" + quote +
                    " -w " + quote + "\\n%{http_code}" + quote +
                    " " + quote + uri + quote,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            string output;
            string error;

            using (Process process = new() { StartInfo = psi })
            {
                process.Start();

                Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
                Task<string> errorTask = process.StandardError.ReadToEndAsync();

                await process.WaitForExitAsync(_cancellationToken);

                output = await outputTask;
                error = await errorTask;
            }

            int separator = output.LastIndexOf('\n');
            string response = separator >= 0 ? output.Substring(0, separator).TrimEnd() : string.Empty;
            int statusCode;

            if (!int.TryParse((separator >= 0 ? output.Substring(separator + 1) : output).Trim(), out statusCode))
            {
                statusCode = 0;
            }

            AddLogEntry(string.Format("{0} - {1} - http {2} - {3} bytes{4}",
                c_responseReceivedLogMessage, uri, statusCode, response.Length,
                string.IsNullOrWhiteSpace(error) ? string.Empty : " - curl said: " + error.Trim()));

            return Tuple.Create(statusCode, response);
        }

        private async void SendRequestFlirt4Free()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (_browser.Source == new Uri("about:blank"))
                {
                    _uri = "https://www.flirt4free.com/?tpl=index2&model=json";

                    CoreWebView2WebResourceRequest request = _browser.CoreWebView2.Environment.CreateWebResourceRequest(
                        _uri,
                        "GET",
                        null,
                        "Content-Type: application/x-www-form-urlencoded\r\nX-Requested-With: XMLHttpRequest");
                    _browser.CoreWebView2.NavigateWithWebResourceRequest(request);
                }
                else
                {
                    _browser.Reload();
                }
            }
            catch
            {
                //do nothing
            }
        }

        private async void SendRequestCamSoda()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (_browser.Source == new Uri("about:blank"))
                {
                    _uri = string.Format("https://www.camsoda.com/api/v1/video/vtoken/{0}", _name);

                    CoreWebView2WebResourceRequest request = _browser.CoreWebView2.Environment.CreateWebResourceRequest(
                        _uri,
                        "GET",
                        null,
                        "Content-Type: application/x-www-form-urlencoded\r\nX-Requested-With: XMLHttpRequest");
                    _browser.CoreWebView2.NavigateWithWebResourceRequest(request);
                }
                else
                {
                    _browser.Reload();
                }
            }
            catch
            {
                //do nothing
            }
        }

        private async void SendRequestCam4()
        {
            try
            {
                await Task.Delay(s_random.Next(0, _delay * 1000), _cancellationToken);

                if (_browser.Source == new Uri("about:blank"))
                {
                    _uri = string.Format("https://cam4.com/directoryCams?directoryJson=true&online=true&username={0}", _name);

                    CoreWebView2WebResourceRequest request = _browser.CoreWebView2.Environment.CreateWebResourceRequest(
                        _uri,
                        "GET",
                        null,
                        "Content-Type: application/x-www-form-urlencoded\r\nX-Requested-With: XMLHttpRequest");
                    _browser.CoreWebView2.NavigateWithWebResourceRequest(request);
                }
                else
                {
                    _browser.Reload();
                }
            }
            catch
            {
                //do nothing
            }
        }

        private void ProcessResponseChaturbate(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                JsonNode chatRoomNode = JsonNode.Parse(response);

                switch ((string)chatRoomNode["room_status"])
                {
                    case "public":
                        status = ChatRoomStatus.Public;
                        break;
                    case "private":
                        status = ChatRoomStatus.Private;
                        break;
                    case "password protected":
                        status = ChatRoomStatus.Private;
                        break;
                    case "hidden":
                        status = ChatRoomStatus.Hidden;
                        break;
                    case "away":
                        status = ChatRoomStatus.Away;
                        break;
                    case "offline":
                        status = ChatRoomStatus.Offline;
                        break;
                }

                AddLogEntry(string.Format("{0} - {1} ('{2}')", c_statusObtainedLogMessage, status, (string)chatRoomNode["room_status"]));

                if (status == ChatRoomStatus.Public)
                {
                    playlistUrl = (string)chatRoomNode["hls_source"];

                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    HttpRequestMessage reqMsg = new(HttpMethod.Get, playlistUrl);
                    reqMsg.Headers.Add("Accept-Encoding", "gzip");
                    HttpResponseMessage respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                    string[] playlist = new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd().Split('\n');
                    for (int i = 0; i < playlist.Length; i++)
                    {
                        MatchCollection matches = Regex.Matches(playlist[i], "^.*RESOLUTION=([0-9]*x[0-9]*).*$", RegexOptions.IgnoreCase);
                        if (matches.Count > 0)
                        {
                            availableResolutions.Add(ChatRoomResolution.Parse(matches[0].Groups[1].Value));
                        }
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, streamIndex);
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = string.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void ProcessResponseBongaCams(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                JsonNode rootNode = JsonNode.Parse(response);
                JsonNode chatRoomNode = null;

                for (int i = 0; i < (int)rootNode["total_count"] && chatRoomNode == null; i++)
                {
                    JsonNode node = ((JsonArray)rootNode["models"])[i];
                    string name = (string)node["username"];
                    if (name != null && name.ToLower() == _name)
                    {
                        chatRoomNode = node;
                    }
                }

                if (chatRoomNode == null)
                {
                    throw new ArgumentException();
                }

                string esid = (string)chatRoomNode["esid"];

                if (esid == null)
                {
                    throw new ArgumentException();
                }

                playlistUrl = string.Format("https://{0}.bcvcdn.com/hls/stream_{1}/playlist.m3u8", esid, (string)chatRoomNode["username"]);

                HttpRequestMessage reqMsg = new(HttpMethod.Get, playlistUrl);
                HttpResponseMessage respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                if (respMsg.IsSuccessStatusCode)
                {
                    status = ChatRoomStatus.Public;
                }
                else
                {
                    status = ChatRoomStatus.Offline;
                }

                AddLogEntry(string.Format("{0} - {1}", c_statusObtainedLogMessage, status));

                if (status == ChatRoomStatus.Public)
                {
                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    string[] playlist = new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd().Split('\n');
                    for (int i = 0; i < playlist.Length; i++)
                    {
                        MatchCollection matches = Regex.Matches(playlist[i], "^.*RESOLUTION=([0-9]*x[0-9]*).*$", RegexOptions.IgnoreCase);
                        if (matches.Count > 0)
                        {
                            availableResolutions.Add(ChatRoomResolution.Parse(matches[0].Groups[1].Value));
                        }
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, streamIndex);
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = String.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void ProcessResponseStripchat(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                JsonNode rootNode = JsonNode.Parse(response);

                //the api is addressed by the model id now, and a wrong id would quietly return
                //another model's stream - check that the answer is about the room we asked for and
                //drop the cached id if it isn't, so the next cycle resolves it again
                JsonNode userNode = rootNode["user"] != null ? rootNode["user"]["user"] : null;
                string reportedName = (userNode != null && userNode["username"] != null) ? (string)userNode["username"] : null;

                if (!string.IsNullOrEmpty(_stripchatModelId) &&
                    !string.IsNullOrEmpty(reportedName) &&
                    !string.Equals(reportedName, _name, StringComparison.OrdinalIgnoreCase))
                {
                    _stripchatModelId = string.Empty;

                    throw new ArgumentException(string.Format(c_wrongModelErrorMessage, reportedName, _name));
                }

                switch ((string)rootNode["user"]["user"]["status"])
                {
                    case "public":
                        status = ChatRoomStatus.Public;
                        break;
                    case "virtualPrivate":
                        status = ChatRoomStatus.Private;
                        break;
                    case "private":
                        status = ChatRoomStatus.Private;
                        break;
                    case "p2p":
                        status = ChatRoomStatus.Private;
                        break;
                    case "p2pVoice":
                        status = ChatRoomStatus.Private;
                        break;
                    case "groupShow":
                        status = ChatRoomStatus.Group;
                        break;
                    case "idle":
                        status = ChatRoomStatus.Idle;
                        break;
                    case "off":
                        status = ChatRoomStatus.Offline;
                        break;
                    case "":
                        status = ChatRoomStatus.Hidden;
                        break;
                }

                AddLogEntry(string.Format("{0} - {1} ('{2}')", c_statusObtainedLogMessage, status, rootNode["user"]["user"]["status"]));

                if (status == ChatRoomStatus.Public)
                {
                    //https://media-hls.growcdnssedge.com
                    //https://media-hls.doppiocdn.org/
                    playlistUrl = string.Format("https://media-hls.growcdnssedge.com/b-hls-{0:00}/{1}/{1}.m3u8", s_random.Next(1, 26), rootNode["cam"]["streamName"]);

                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    //the website used to publish a preset ladder in cam.broadcastSettings, nowadays only
                    //the source resolution is published, in cam.broadcastConfig
                    JsonNode configNode = rootNode["cam"]["broadcastConfig"];
                    JsonNode settingsNode = rootNode["cam"]["broadcastSettings"];

                    if (configNode != null)
                    {
                        availableResolutions.Add(new ChatRoomResolution((short)configNode["flashWidth"], (short)configNode["flashHeight"]));
                    }
                    else if (settingsNode != null)
                    {
                        availableResolutions.Add(new ChatRoomResolution((short)settingsNode["width"], (short)settingsNode["height"]));
                    }
                    else
                    {
                        throw new ArgumentException(c_resolutionsUnavailableErrorMessage);
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, null);
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = String.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void ProcessResponseFlirt4Free(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                string name = string.Format("\"{0}\"", _name);
                int pos = response.IndexOf(name);
                int first = -1;
                int last = -1;
                int k = 0;
                for (int i = pos - 1; i >= 0 && first == -1; i--)
                {
                    switch (response[i])
                    {
                        case '{': if (k == 0) first = i; else k--; break;
                        case '}': k++; break;
                    }
                }
                for (int i = pos + name.Length; i < response.Length && first != -1 && last == -1; i++)
                {
                    switch (response[i])
                    {
                        case '}': if (k == 0) last = i; else k--; break;
                        case '{': k++; break;
                    }
                }
                JsonNode chatRoomNode = JsonNode.Parse((first != -1 && last != -1) ? response.Substring(first, last - first + 1) : "{\"room_status_char\":\"\"}");

                switch ((string)chatRoomNode["room_status_char"])
                {
                    case "O":
                        status = ChatRoomStatus.Public;
                        break;
                    case "P":
                        status = ChatRoomStatus.Private;
                        break;
                    case "F":
                        status = ChatRoomStatus.Private;
                        break;
                    case "":
                        status = ChatRoomStatus.Offline;
                        break;
                }

                AddLogEntry(string.Format("{0} - {1} ('{2}')", c_statusObtainedLogMessage, status, chatRoomNode["room_status_char"]));

                if (status == ChatRoomStatus.Public)
                {
                    int id = Convert.ToInt32((string)chatRoomNode["model_id"]);

                    string streamInfoUrl = string.Format("https://www.flirt4free.com/ws/chat/get-stream-urls.php?model_id={0}", id);
                    HttpRequestMessage reqMsg = new(HttpMethod.Get, streamInfoUrl);
                    HttpResponseMessage respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                    JsonNode streamInfoNode = JsonNode.Parse(new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd());
                    playlistUrl = string.Format("https:{0}", (string)streamInfoNode["data"]["hls"][0]["url"]);

                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    reqMsg = new(HttpMethod.Get, playlistUrl);
                    respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                    string[] playlist = new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd().Split('\n');
                    for (int i = 0; i < playlist.Length; i++)
                    {
                        MatchCollection matches = Regex.Matches(playlist[i], "^.*RESOLUTION=([0-9]*x[0-9]*).*$", RegexOptions.IgnoreCase);
                        if (matches.Count > 0)
                        {
                            availableResolutions.Add(ChatRoomResolution.Parse(matches[0].Groups[1].Value));
                        }
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, streamIndex);
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = String.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void ProcessResponseCamSoda(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                JsonNode chatRoomNode = JsonNode.Parse(response);
                JsonArray serversNode = (JsonArray)chatRoomNode["edge_servers"];
                string streamName = (string)chatRoomNode["stream_name"];

                if (streamName == string.Empty)
                {
                    status = ChatRoomStatus.Offline;
                }
                else if (serversNode.Count == 0)
                {
                    status = ChatRoomStatus.Private;
                }
                else
                {
                    status = ChatRoomStatus.Public;
                }

                AddLogEntry(string.Format("{0} - {1}", c_statusObtainedLogMessage, status));

                if (status == ChatRoomStatus.Public)
                {
                    playlistUrl = string.Format("https://{0}/{1}_v1/playlist.m3u8", (string)serversNode[0], streamName);

                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    HttpRequestMessage reqMsg = new(HttpMethod.Get, playlistUrl);
                    HttpResponseMessage respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                    string[] playlist = new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd().Split('\n');
                    for (int i = 0; i < playlist.Length; i++)
                    {
                        MatchCollection matches = Regex.Matches(playlist[i], "^.*RESOLUTION=([0-9]*x[0-9]*).*$", RegexOptions.IgnoreCase);
                        if (matches.Count > 0)
                        {
                            availableResolutions.Add(ChatRoomResolution.Parse(matches[0].Groups[1].Value));
                        }
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, string.Format("{0}p", availableResolutions[streamIndex].Height.ToString()));
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = String.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void ProcessResponseCam4(string response)
        {
            ChatRoomStatus status = ChatRoomStatus.Unknown;
            string playlistUrl = string.Empty;
            List<ChatRoomResolution> availableResolutions = new List<ChatRoomResolution>();

            try
            {
                JsonNode chatRoomNode = null;

                JsonArray allNodes = (JsonArray)JsonNode.Parse(response);
                if (allNodes.Count > 0)
                {
                    chatRoomNode = allNodes[0];

                    switch ((string)chatRoomNode["showType"])
                    {
                        case "NORMAL":
                            status = ChatRoomStatus.Public;
                            break;
                        case "PRIVATE_SHOW":
                            status = ChatRoomStatus.Private;
                            break;
                        case "GROUP_SHOW":
                            status = ChatRoomStatus.Group;
                            break;
                    }
                }
                else
                {
                    status = ChatRoomStatus.Offline;
                }

                if (status == ChatRoomStatus.Public && (string)chatRoomNode["hlsPreviewUrl"] == string.Empty)
                {
                    status = ChatRoomStatus.Private;
                }

                AddLogEntry(string.Format("{0} - {1}", c_statusObtainedLogMessage, status));

                if (status == ChatRoomStatus.Public)
                {
                    playlistUrl = (string)chatRoomNode["hlsPreviewUrl"];

                    AddLogEntry(string.Format("{0} - {1}", c_playlistObtainedLogMessage, playlistUrl));

                    HttpRequestMessage reqMsg = new(HttpMethod.Get, playlistUrl);
                    HttpResponseMessage respMsg = s_httpClient.Send(reqMsg, _cancellationToken);
                    string[] playlist = new StreamReader(respMsg.Content.ReadAsStream()).ReadToEnd().Split('\n');
                    for (int i = 0; i < playlist.Length; i++)
                    {
                        MatchCollection matches = Regex.Matches(playlist[i], "^.*RESOLUTION=([0-9]*x[0-9]*).*$", RegexOptions.IgnoreCase);
                        if (matches.Count > 0)
                        {
                            availableResolutions.Add(ChatRoomResolution.Parse(matches[0].Groups[1].Value));
                        }
                    }

                    AddLogEntry(string.Format("{0} - {1}", c_resolutionsObtainedLogMessage, string.Join(", ", availableResolutions)));
                }

                if (status == ChatRoomStatus.Public && _action == ChatRoomAction.Record)
                {
                    status = ChatRoomStatus.Record;
                }

                if (status == ChatRoomStatus.Public || status == ChatRoomStatus.Record)
                {
                    int streamIndex = ChatRoomResolution.FindClosest(_preferredResolution, availableResolutions.ToArray());

                    if (streamIndex == -1)
                    {
                        throw new ArgumentException();
                    }

                    if (status == ChatRoomStatus.Record)
                    {
                        Record(playlistUrl, streamIndex);
                    }
                }
            }
            catch (Exception exception)
            {
                status = ChatRoomStatus.Error;
                playlistUrl = String.Empty;
                availableResolutions.Clear();

                AddLogEntry(string.Format("{0} - {1}: {2} | raw response ({3} chars): {4}",
                    c_errorOccuredLogMessage, exception.GetType().Name, exception.Message,
                    response != null ? response.Length : 0, Snippet(response)));
            }
            finally
            {
                _status = status;
                _playlistUrl = playlistUrl;
                _availableResolutions = availableResolutions;
            }

            if (_status != ChatRoomStatus.Offline && _status != ChatRoomStatus.Error && _status != ChatRoomStatus.Unknown)
            {
                _lastSeen = DateTime.Now;
            }
        }

        private void Record(string playlistUrl, object stream)
        {
            Directory.CreateDirectory(string.Format("{0}\\{1} {2}", _outputDirectory, _website, _name).ToLower());

            _fileName = string.Format("{0}\\{1} {2}\\{1} {2} {3}.ts", _outputDirectory, _website, _name, DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss")).ToLower();
            _fileSize = 0;

            int port = s_random.Next(16384, 65536);

            string outputArguments = BuildOutputArguments();

            List<ProcessStartInfo> psis = new List<ProcessStartInfo>();

            switch (_website)
            {
                case ChatRoomWebsite.Chaturbate:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-analyzeduration 16M -i \"{0}\" -map 0:p:{1} {2} \"{3}\"", playlistUrl, Convert.ToInt32(stream), outputArguments, _fileName)
                    });
                    break;
                case ChatRoomWebsite.BongaCams:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-analyzeduration 16M -i \"{0}\" -map 0:p:{1} {2} \"{3}\"", playlistUrl, Convert.ToInt32(stream), outputArguments, _fileName)
                    });
                    break;
                case ChatRoomWebsite.Stripchat:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _streamlinkPath,
                        Arguments = string.Format("--player-external-http --player-external-http-continuous false --player-external-http-interface 127.0.0.1 --player-external-http-port {0} " +
                            "--default-stream best --stream-segment-timeout 60 --stream-timeout 60 --http-timeout 60 --hls-segment-queue-threshold 99 {1}", port, playlistUrl)
                    });
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-reconnect 1 -reconnect_at_eof 1 -reconnect_on_network_error 1 -reconnect_on_http_error 1 -reconnect_streamed 1 -i http://127.0.0.1:{0} {1} \"{2}\"", port, outputArguments, _fileName)
                    });
                    break;
                case ChatRoomWebsite.Flirt4Free:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-analyzeduration 16M -i \"{0}\" -map 0:p:{1} {2} \"{3}\"", playlistUrl, Convert.ToInt32(stream), outputArguments, _fileName)
                    });
                    break;
                case ChatRoomWebsite.CamSoda:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _streamlinkPath,
                        Arguments = string.Format("--player-external-http --player-external-http-continuous false --player-external-http-interface 127.0.0.1 --player-external-http-port {0} " +
                            "--default-stream {1} --stream-segment-timeout 60 --stream-timeout 60 --http-timeout 60 --hls-segment-queue-threshold 99 {2}", port, stream, playlistUrl)
                    });
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-reconnect 1 -reconnect_at_eof 1 -reconnect_on_network_error 1 -reconnect_on_http_error 1 -reconnect_streamed 1 -i http://127.0.0.1:{0} {1} \"{2}\"", port, outputArguments, _fileName)
                    });
                    break;
                case ChatRoomWebsite.Cam4:
                    psis.Add(new ProcessStartInfo()
                    {
                        FileName = _ffmpegPath,
                        Arguments = string.Format("-analyzeduration 16M -i \"{0}\" -map 0:p:{1} {2} \"{3}\"", playlistUrl, Convert.ToInt32(stream), outputArguments, _fileName)
                    });
                    break;
            }

            foreach (ProcessStartInfo psi in psis)
            {
                psi.UseShellExecute = false;
                psi.LoadUserProfile = false;
                psi.CreateNoWindow = true;
                _processes.Add(Process.Start(psi));

                AddLogEntry(string.Format("{0} - {1} {2}", c_recordingStartedLogMessage, psi.FileName, psi.Arguments));
            }
        }

        private string BuildOutputArguments()
        {
            if (_videoEncoder == VideoEncoder.Copy)
            {
                return "-c copy";
            }

            StringBuilder arguments = new StringBuilder();

            if (_maxVideoHeight > 0)
            {
                //the height is only reduced, never increased, and the width is kept even to stay encoder friendly
                arguments.AppendFormat("-vf \"scale=-2:'min({0},ih)'\" ", _maxVideoHeight);
            }

            switch (_videoEncoder)
            {
                case VideoEncoder.H264:
                    arguments.AppendFormat("-c:v libx264 -preset {0} -crf {1}", SoftwarePreset(_videoPreset), _videoQuality);
                    break;
                case VideoEncoder.H265:
                    arguments.AppendFormat("-c:v libx265 -preset {0} -crf {1}", SoftwarePreset(_videoPreset), _videoQuality);
                    break;
                case VideoEncoder.H264_NVENC:
                    arguments.AppendFormat("-c:v h264_nvenc -preset {0} -rc vbr -cq {1} -b:v 0", NvencPreset(_videoPreset), _videoQuality);
                    break;
                case VideoEncoder.H265_NVENC:
                    arguments.AppendFormat("-c:v hevc_nvenc -preset {0} -rc vbr -cq {1} -b:v 0", NvencPreset(_videoPreset), _videoQuality);
                    break;
                case VideoEncoder.H264_QSV:
                    arguments.AppendFormat("-c:v h264_qsv -preset {0} -global_quality {1}", QsvPreset(_videoPreset), _videoQuality);
                    break;
                case VideoEncoder.H265_QSV:
                    arguments.AppendFormat("-c:v hevc_qsv -preset {0} -global_quality {1}", QsvPreset(_videoPreset), _videoQuality);
                    break;
            }

            if (_audioBitrate > 0)
            {
                arguments.AppendFormat(" -c:a aac -b:a {0}k", _audioBitrate);
            }
            else
            {
                arguments.Append(" -c:a copy");
            }

            return arguments.ToString();
        }

        private static string SoftwarePreset(VideoPreset preset)
        {
            switch (preset)
            {
                case VideoPreset.UltraFast:
                    return "ultrafast";
                case VideoPreset.SuperFast:
                    return "superfast";
                case VideoPreset.VeryFast:
                    return "veryfast";
                case VideoPreset.Faster:
                    return "faster";
                case VideoPreset.Fast:
                    return "fast";
                case VideoPreset.Medium:
                    return "medium";
                default:
                    return "slow";
            }
        }

        private static string NvencPreset(VideoPreset preset)
        {
            //p1 is the fastest and p7 is the slowest NVENC preset
            return string.Format("p{0}", (int)preset + 1);
        }

        private static string QsvPreset(VideoPreset preset)
        {
            //QSV doesn't support the two fastest presets
            switch (preset)
            {
                case VideoPreset.UltraFast:
                case VideoPreset.SuperFast:
                case VideoPreset.VeryFast:
                    return "veryfast";
                case VideoPreset.Faster:
                    return "faster";
                case VideoPreset.Fast:
                    return "fast";
                case VideoPreset.Medium:
                    return "medium";
                default:
                    return "slow";
            }
        }

        private void AddLogEntry(string info)
        {
            _log.Enqueue(new Tuple<DateTime, string>(DateTime.Now, info));
        }

        private static string Snippet(string text)
        {
            if (text == null)
            {
                return "(null)";
            }

            string oneLine = text.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ").Trim();

            return oneLine.Length <= c_logSnippetLength
                ? oneLine
                : string.Format("{0}...(truncated, {1} chars total)", oneLine.Substring(0, c_logSnippetLength), text.Length);
        }

        public event EventHandler UpdateCompleted;

        public int ID
        {
            set
            {
                _id = value;
            }
            get
            {
                return _id;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public ChatRoomWebsite Website
        {
            get
            {
                return _website;
            }
        }

        public ChatRoomStatus Status
        {
            get
            {
                return _status;
            }
        }

        public ChatRoomAction Action
        {
            set
            {
                _action = value;
            }
            get
            {
                return _action;
            }
        }

        public string ChatRoomUrl
        {
            get
            {
                return _chatRoomUrl;
            }
        }

        public string PlaylistUrl
        {
            get
            {
                return _playlistUrl;
            }
        }

        public ChatRoomResolution[] AvailableResolutions
        {
            get
            {
                return _availableResolutions.ToArray();
            }
        }

        public ChatRoomResolution PreferredResolution
        {
            set
            {
                _preferredResolution = value;
            }
            get
            {
                return _preferredResolution;
            }
        }

        public string OutputDirectory
        {
            set
            {
                if (value == null)
                {
                    throw new ArgumentException();
                }
                else
                {
                    _outputDirectory = value;
                }
            }
            get
            {
                return _outputDirectory;
            }
        }

        public string FFmpegPath
        {
            set
            {
                if (value == null)
                {
                    throw new ArgumentException();
                }
                else
                {
                    _ffmpegPath = value;
                }
            }
            get
            {
                return _ffmpegPath;
            }
        }

        public string StreamlinkPath
        {
            set
            {
                if (value == null)
                {
                    throw new ArgumentException();
                }
                else
                {
                    _streamlinkPath = value;
                }
            }
            get
            {
                return _streamlinkPath;
            }
        }

        public VideoEncoder VideoEncoder
        {
            set
            {
                _videoEncoder = value;
            }
            get
            {
                return _videoEncoder;
            }
        }

        public int VideoQuality
        {
            set
            {
                _videoQuality = value < 0 ? 0 : (value > 51 ? 51 : value);
            }
            get
            {
                return _videoQuality;
            }
        }

        public VideoPreset VideoPreset
        {
            set
            {
                _videoPreset = value;
            }
            get
            {
                return _videoPreset;
            }
        }

        public int AudioBitrate
        {
            set
            {
                _audioBitrate = (value < 0) ? 0 : value;
            }
            get
            {
                return _audioBitrate;
            }
        }

        public int MaxVideoHeight
        {
            set
            {
                _maxVideoHeight = (value < 0) ? 0 : value;
            }
            get
            {
                return _maxVideoHeight;
            }
        }

        public int Delay
        {
            set
            {
                _delay = (value < 0) ? 0 : value;
            }
            get
            {
                return _delay;
            }
        }

        public DateTime LastUpdated
        {
            set
            {
                _lastUpdated = value;
            }
            get
            {
                return _lastUpdated;
            }
        }

        public DateTime LastSeen
        {
            set
            {
                _lastSeen = value;
            }
            get
            {
                return _lastSeen;
            }
        }

        public bool DisposingStarted
        {
            get
            {
                return _disposingStarted;
            }
        }

        public bool DisposingFinished
        {
            get
            {
                return _disposingFinished;
            }
        }

        public ConcurrentQueue<Tuple<DateTime, string>> Log
        {
            get
            {
                return _log;
            }
        }

        public static int TotalCount
        {
            get
            {
                return s_totalCount;
            }
        }

        private int _id;
        private string _name;
        private ChatRoomWebsite _website;
        private ChatRoomStatus _status;
        private ChatRoomAction _action;
        private string _chatRoomUrl;
        private string _playlistUrl;
        private List<ChatRoomResolution> _availableResolutions;
        private ChatRoomResolution _preferredResolution;
        private string _outputDirectory;
        private string _ffmpegPath;
        private string _streamlinkPath;
        private VideoEncoder _videoEncoder;
        private int _videoQuality;
        private VideoPreset _videoPreset;
        private int _audioBitrate;
        private int _maxVideoHeight;
        private int _delay;
        private List<Process> _processes;
        private string _fileName;
        private long _fileSize;
        private DateTime _lastUpdated;
        private DateTime _lastSeen;
        private bool _isUpdating;
        private bool _disposingStarted;
        private bool _disposingFinished;
        private CancellationTokenSource _cancellationTokenSource;
        private CancellationToken _cancellationToken;
        private WebView2 _browser;
        private bool _browserInitialized;
        private string _stripchatModelId;
        private string _uri;
        private System.Windows.Forms.Timer _timer;
        private SemaphoreSlim _semaphore;
        private ConcurrentQueue<Tuple<DateTime, string>> _log;

        private const int c_updateLimit = 60;

        private static HttpClient s_httpClient = new(new HttpClientHandler() { AutomaticDecompression = DecompressionMethods.GZip });
        private static string s_curlPath = Path.Combine(Environment.SystemDirectory, "curl.exe");
        private static Random s_random = new Random();
        private static int s_totalCount = 0;

        private const string c_statusObtainedLogMessage = "status";
        private const string c_playlistObtainedLogMessage = "playlist";
        private const string c_resolutionsObtainedLogMessage = "resolutions";
        private const string c_recordingStartedLogMessage = "recording";
        private const string c_errorOccuredLogMessage = "error occured";
        private const string c_responseReceivedLogMessage = "response";
        private const string c_navigationLogMessage = "navigation";
        private const string c_resolutionsUnavailableErrorMessage = "the website didn't report the stream resolution";
        private const string c_wrongModelErrorMessage = "the api answered about '{0}' instead of '{1}' - the resolved model id is wrong and has been discarded";
        private const int c_stripchatTimeout = 15;
        private const string c_modelIdUnavailableErrorMessage = "couldn't resolve the model id of '{0}'";
        private const string c_stripchatUserUri = "https://{0}/api/front/v2/users/username/{1}";
        private const string c_stripchatCamUri = "https://{0}/api/front/v2/models/{1}/cam";
        private static readonly string[] s_stripchatApiHosts = { "stripchat.com", "vr.stripchat.com" };
        private const int c_logSnippetLength = 600;

        //plain desktop chrome user agent - brave sends the same string (no "brave" token) to reduce
        //fingerprinting. bump the chrome version here from time to time to keep it current.
        private const string c_userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    }
}