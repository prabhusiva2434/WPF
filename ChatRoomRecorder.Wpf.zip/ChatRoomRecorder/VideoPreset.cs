﻿namespace ChatRoomRecorder
{
    public enum VideoPreset
    {
        UltraFast,
        SuperFast,
        VeryFast,
        Faster,
        Fast,
        Medium,
        Slow
    }
}
