using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.ViewModels;
using ChatRoomRecorder.Wpf.Views;

namespace ChatRoomRecorder.Wpf;

public partial class App : Application
{
    private readonly LogService _log = new();
    private Mutex? _singleInstance;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        //one instance per folder. a second copy in another folder has its own database and rooms, so it
        //can run at the same time; a second copy of the same folder would fight over one database and
        //record every room twice
        string folder = AppPaths.DataDirectory.ToLowerInvariant();
        string key = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(folder)))[..16];
        _singleInstance = new Mutex(true, $"ChatRoomRecorderWpf.{key}", out bool createdNew);

        if (!createdNew)
        {
            MessageBox.Show(
                $"ChatRoom Recorder Studio is already running from this folder:\n{AppPaths.DataDirectory}\n\n" +
                "To run another instance, copy the whole app folder somewhere else and start it from there - that copy keeps its own rooms and settings.",
                "ChatRoom Recorder Studio", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();

            return;
        }

        //nothing unexpected takes the app down or leaves it frozen - it's logged and the app carries on
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Report("background task", args.Exception);
            args.SetObserved();
        };
        AppDomain.CurrentDomain.UnhandledException += (_, args) => Report("fatal", args.ExceptionObject as Exception);

        Views.MainWindow window = new(new MainViewModel(_log, new DialogService()));
        MainWindow = window;
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _singleInstance?.Dispose();

        base.OnExit(e);
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Report("ui", e.Exception);
        e.Handled = true;
    }

    private void Report(string source, Exception? exception)
    {
        if (exception == null)
        {
            return;
        }

        _log.Error(source, $"{exception.GetType().Name}: {exception.Message}");

        try
        {
            Directory.CreateDirectory(AppPaths.DataDirectory);
            File.AppendAllText(AppPaths.CrashLogPath, $"{DateTime.Now:O} [{source}] {exception}{Environment.NewLine}{Environment.NewLine}");
        }
        catch
        {
            //nowhere left to report to
        }
    }
}
