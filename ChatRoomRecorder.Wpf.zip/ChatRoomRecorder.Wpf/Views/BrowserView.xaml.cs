using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.ViewModels;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace ChatRoomRecorder.Wpf.Views;

//a plain browser for finding rooms. it's created the first time the page is opened, so the app
//doesn't pay for a webview it may never use
public partial class BrowserView : UserControl
{
    private WebView2? _webView;
    private bool _initializing;

    public BrowserView()
    {
        InitializeComponent();
    }

    public async void EnsureInitialized()
    {
        if (_webView != null || _initializing)
        {
            return;
        }

        _initializing = true;

        try
        {
            CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(
                null, Path.Combine(AppPaths.DataDirectory, "WebView2"));

            WebView2 webView = new();
            BrowserHost.Child = webView;
            await webView.EnsureCoreWebView2Async(environment);

            webView.CoreWebView2.Settings.UserAgent = CurlClient.UserAgent;
            webView.SourceChanged += (_, _) => AddressBox.Text = webView.Source?.ToString() ?? string.Empty;
            webView.NavigationCompleted += (_, args) =>
            {
                if (!args.IsSuccess)
                {
                    ShowMessage($"The page couldn't be loaded ({args.WebErrorStatus})", keepBrowser: true);
                }
            };

            _webView = webView;
            BrowserMessage.Visibility = Visibility.Collapsed;
            Navigate("https://www.google.com/");
        }
        catch (Exception exception)
        {
            BrowserHost.Child = null;
            ShowMessage($"The browser couldn't start - the Microsoft Edge WebView2 runtime may be missing.\n{exception.Message}", keepBrowser: false);
        }
        finally
        {
            _initializing = false;
        }
    }

    private void ShowMessage(string message, bool keepBrowser)
    {
        BrowserMessage.Text = message;
        BrowserMessage.Visibility = keepBrowser ? Visibility.Collapsed : Visibility.Visible;

        (DataContext as MainViewModel)?.Notify(message, NotificationKind.Warning);
    }

    private void Navigate(string text)
    {
        if (_webView?.CoreWebView2 == null)
        {
            return;
        }

        string url = text.Trim();

        if (url.Length == 0)
        {
            return;
        }

        if (!url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) &&
            !url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
            url != "about:blank")
        {
            url = "https://" + url;
        }

        try
        {
            _webView.CoreWebView2.Navigate(url);
        }
        catch (ArgumentException)
        {
            (DataContext as MainViewModel)?.Notify($"'{text}' isn't a valid address", NotificationKind.Warning);
        }
    }

    private void BackButton_Click(object sender, RoutedEventArgs e)
    {
        if (_webView?.CanGoBack == true)
        {
            _webView.GoBack();
        }
    }

    private void ForwardButton_Click(object sender, RoutedEventArgs e)
    {
        if (_webView?.CanGoForward == true)
        {
            _webView.GoForward();
        }
    }

    private void ReloadButton_Click(object sender, RoutedEventArgs e) => _webView?.Reload();

    private void GoButton_Click(object sender, RoutedEventArgs e) => Navigate(AddressBox.Text);

    private void AddressBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            Navigate(AddressBox.Text);
        }
    }

    private void AddRoomButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is MainViewModel viewModel && _webView?.Source != null)
        {
            viewModel.FilterText = _webView.Source.ToString();
            viewModel.AddFromTextCommand.Execute(null);
        }
    }
}
