using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

//everything on stripchat's api hangs off the numeric model id, and the ways to get there keep changing:
//- /users/username/{name} is gone (404 on the mirror, blocked with http 418 on the main site), so the
//  id now comes from the site's own search, which answers for live rooms
//- /models/username/{name}/cam answers 404 everywhere now, so the cam is only asked for by id
//- /models/{id}/cam works on the main site and the mirror, but cloudflare bot management scores every
//  request on its own and hands out a 403 challenge page at random
//once an id is known it is kept (and stored with the room), so a room keeps working even when the
//search is unavailable later. when every way to the cam is blocked, the stream's own playlist on the
//edge cdn still says whether the room is live.
public sealed class StripchatProbe : SiteProbe
{
    private static readonly string[] Hosts = { "stripchat.com", "vr.stripchat.com" };

    private static readonly string[] Headers = { "Accept: application/json", "Referer: https://stripchat.com/" };

    //the search needs a category, and a room is only in one of them
    private static readonly string[] SearchTags = { "girls", "trans", "couples", "men" };

    private const string SuggestionUri = "https://stripchat.com/api/front/v4/models/search/suggestion?query={0}&limit=15&primaryTag={1}";
    private const string CamByIdUri = "https://{0}/api/front/v2/models/{1}/cam";

    //two different urls, for two different jobs:
    //- the master playlist on the edge cdn answers 200 while the room is live and 404 when it isn't, and
    //  lists the stream's resolution, so it tells us the status when the api is blocked. it must NOT be
    //  recorded from: its segments are scrambled (the #EXT-X-MOUFLON tags) and anything that can't
    //  unscramble them is served one and the same placeholder clip for every room
    //- the media cdn redirects to a signed playlist (pkey) whose segments are the room's real stream,
    //  which is what gets recorded
    private const string LivePlaylistUri = "https://edge-hls.doppiocdn.com/hls/{0}/master/{0}.m3u8";
    private const string RecordPlaylistUri = "https://media-hls.growcdnssedge.com/b-hls-{0:00}/{1}/{1}.m3u8";

    private const int Rounds = 2;

    public override ChatRoomWebsite Website => ChatRoomWebsite.Stripchat;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(context.Cache))
        {
            (string? id, bool searchWorked) = await SearchModelIdAsync(context, cancellationToken);

            if (string.IsNullOrEmpty(id))
            {
                if (!searchWorked)
                {
                    context.Error($"couldn't look up '{context.Name}' - stripchat blocked the search, so the room can't be checked yet");

                    return ProbeResult.Error;
                }

                //the search only lists rooms that are live, so this is the usual answer for a room
                //that isn't broadcasting - a wrong name looks the same until it does
                context.Info($"status - {ChatRoomStatus.Offline} ('{context.Name}' isn't listed as live)");

                return ProbeResult.Of(ChatRoomStatus.Offline);
            }

            context.Cache = id;
        }

        (HttpResult result, string url) = await GetCamAsync(context, cancellationToken);

        if (result.StatusCode == 404)
        {
            //the model was renamed or re-registered - the next check looks the id up again
            context.Warning($"model id {context.Cache} is stale (http 404) - it will be looked up again");
            context.Cache = null;

            return ProbeResult.Error;
        }

        if (result.StatusCode != 200)
        {
            context.Warning($"every way to the room's cam was blocked (last http {result.StatusCode} for {url}) - asking the cdn instead");

            return await ProbeWithoutCamAsync(context, cancellationToken);
        }

        JsonObject? root = Obj(JsonNode.Parse(result.Body));
        JsonObject? camUser = Obj(Obj(root?["user"])?["user"]);

        //a wrong id would quietly return another model's stream
        string? reportedName = Str(camUser?["username"]);

        if (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, context.Name, StringComparison.OrdinalIgnoreCase))
        {
            context.Error($"the api answered about '{reportedName}' instead of '{context.Name}' - the model id has been discarded");
            context.Cache = null;

            return ProbeResult.Error;
        }

        string? raw = Str(camUser?["status"]);

        ChatRoomStatus status = raw switch
        {
            "public" => ChatRoomStatus.Public,
            "virtualPrivate" or "private" or "p2p" or "p2pVoice" => ChatRoomStatus.Private,
            "groupShow" => ChatRoomStatus.Group,
            "idle" => ChatRoomStatus.Idle,
            "off" => ChatRoomStatus.Offline,
            "" => ChatRoomStatus.Hidden,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status} ('{raw}') via {url}");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        JsonObject? cam = Obj(root?["cam"]);
        string streamName = Str(cam?["streamName"]) ?? context.Cache ?? string.Empty;

        if (streamName.Length == 0)
        {
            context.Error("the room is public but the api didn't give a stream name");

            return ProbeResult.Error;
        }

        string playlistUrl = await RecordUrlAsync(streamName, context, cancellationToken);

        //only the source resolution is published nowadays (cam.broadcastConfig), older rooms still
        //carry cam.broadcastSettings
        JsonObject? config = Obj(cam?["broadcastConfig"]);
        JsonObject? settings = Obj(cam?["broadcastSettings"]);
        List<Resolution> resolutions = new();

        if (Int(config?["flashWidth"]) is int configWidth && Int(config?["flashHeight"]) is int configHeight)
        {
            resolutions.Add(new Resolution((short)configWidth, (short)configHeight));
        }
        else if (Int(settings?["width"]) is int settingsWidth && Int(settings?["height"]) is int settingsHeight)
        {
            resolutions.Add(new Resolution((short)settingsWidth, (short)settingsHeight));
        }

        if (resolutions.Count == 0)
        {
            resolutions.AddRange(await GetPlaylistResolutionsAsync(string.Format(LivePlaylistUri, streamName), cancellationToken));
        }

        return Finish(context, status, playlistUrl, resolutions, Target(playlistUrl));
    }

    //the cam api is unreachable: the room's own stream says whether it's live
    private async Task<ProbeResult> ProbeWithoutCamAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        (bool success, string playlist) = await PlaylistClient.GetAsync(string.Format(LivePlaylistUri, context.Cache), cancellationToken);

        if (success && playlist.Contains("#EXTM3U", StringComparison.Ordinal))
        {
            context.Info($"status - {ChatRoomStatus.Public} (the room's stream is running) via the cdn");

            //the status came from the edge cdn, but the recording still goes through the media cdn
            string playlistUrl = await RecordUrlAsync(context.Cache!, context, cancellationToken);

            return Finish(context, ChatRoomStatus.Public, playlistUrl, PlaylistClient.ParseResolutions(playlist), Target(playlistUrl));
        }

        //no stream at all - while the api is blocked there's no way to tell a private show from a
        //model who simply isn't broadcasting
        context.Info($"status - {ChatRoomStatus.Offline} (no stream on the cdn, and the api is blocked)");

        return ProbeResult.Of(ChatRoomStatus.Offline);
    }

    //the site's own search is what still maps a name to an id. searchWorked says whether any category
    //answered at all, so "not found" can be told apart from "couldn't ask"
    private async Task<(string? Id, bool SearchWorked)> SearchModelIdAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        bool searchWorked = false;

        foreach (string tag in SearchTags)
        {
            string url = string.Format(SuggestionUri, Uri.EscapeDataString(context.Name), tag);
            HttpResult result = await CurlClient.SendAsync(url, cancellationToken, Headers);

            if (result.StatusCode != 200)
            {
                continue;
            }

            searchWorked = true;

            JsonNode? match = (JsonNode.Parse(result.Body)?["models"] as JsonArray)?
                .FirstOrDefault(model => string.Equals(Str(Obj(model)?["username"]), context.Name, StringComparison.OrdinalIgnoreCase));

            if (Str(Obj(match)?["id"]) is { Length: > 0 } id)
            {
                context.Info($"model id of {context.Name} is {id} (found in the {tag} search)");

                return (id, true);
            }
        }

        return (null, searchWorked);
    }

    //the edge number only picks which mirror answers - it redirects to the signed playlist either way.
    //a mirror sometimes refuses, and a refused url means a recording that writes nothing, so the url is
    //tried before it is handed over and another mirror is used when one doesn't answer
    private static async Task<string> RecordUrlAsync(string streamName, ProbeContext context, CancellationToken cancellationToken)
    {
        string url = string.Empty;

        for (int attempt = 0; attempt < 3; attempt++)
        {
            url = string.Format(RecordPlaylistUri, Random.Shared.Next(1, 26), streamName);

            try
            {
                (bool success, string playlist) = await PlaylistClient.GetAsync(url, cancellationToken);

                if (success && playlist.Contains("#EXTM3U", StringComparison.Ordinal))
                {
                    return url;
                }
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                //try the next mirror
            }
        }

        context.Warning($"the stream's own cdn didn't answer on three mirrors - the recording may not start ({url})");

        return url;
    }

    //streamlink always takes the best stream here
    private static Func<int, RecordTarget> Target(string playlistUrl) =>
        _ => new RecordTarget(RecordMethod.Streamlink, playlistUrl, 0, "best");

    private static async Task<List<Resolution>> GetPlaylistResolutionsAsync(string playlistUrl, CancellationToken cancellationToken)
    {
        try
        {
            (bool success, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);

            return success ? PlaylistClient.ParseResolutions(playlist) : new List<Resolution>();
        }
        catch (Exception)
        {
            return new List<Resolution>();
        }
    }

    private async Task<(HttpResult Result, string Url)> GetCamAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        HttpResult result = new(0, string.Empty, string.Empty);
        string url = string.Empty;

        for (int round = 0; round < Rounds; round++)
        {
            if (round > 0)
            {
                await Task.Delay(Random.Shared.Next(1500, 3000), cancellationToken);
            }

            foreach (string host in Hosts)
            {
                url = string.Format(CamByIdUri, host, context.Cache);
                result = await CurlClient.SendAsync(url, cancellationToken, Headers);

                //a 200 is the answer, a 404 is an answer about the room that no other host will change
                if (result.StatusCode is 200 or 404)
                {
                    return (result, url);
                }
            }
        }

        return (result, url);
    }
}
