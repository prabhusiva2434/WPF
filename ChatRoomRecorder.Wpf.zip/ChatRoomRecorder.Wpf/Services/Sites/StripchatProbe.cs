using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

//stripchat's api sits behind cloudflare bot management, which blocks by path and scores every request
//on its own:
//- /models/username/{name}/cam and the username lookup answer http 418 on stripchat.com, always
//- the other ways to the cam (by numeric model id on stripchat.com or its vr mirror, or by username on
//  the mirror) each get a 403 challenge page now and then, at random - the same url that failed a
//  moment ago usually works on the next try, and in testing every room got through on at least one
//so a check walks through all the ways in turn, and once more after a short pause if none of them got through
public sealed class StripchatProbe : SiteProbe
{
    private static readonly string[] Hosts = { "stripchat.com", "vr.stripchat.com" };

    private static readonly string[] Headers = { "Accept: application/json", "Referer: https://stripchat.com/" };

    private const string UserUri = "https://{0}/api/front/v2/users/username/{1}";
    private const string CamByIdUri = "https://{0}/api/front/v2/models/{1}/cam";
    private const string CamByNameUri = "https://vr.stripchat.com/api/front/v2/models/username/{0}/cam";
    private const int Rounds = 2;

    public override ChatRoomWebsite Website => ChatRoomWebsite.Stripchat;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        //the id also survives a rename, but it's not required - the cam can be asked for by name too
        if (string.IsNullOrEmpty(context.Cache))
        {
            (string? resolvedId, bool notFound) = await ResolveModelIdAsync(context, cancellationToken);

            if (notFound)
            {
                context.Error($"there's no room called '{context.Name}' on stripchat");

                return ProbeResult.Error;
            }

            context.Cache = resolvedId;
        }

        (HttpResult result, string url, bool byName) = await GetCamAsync(context, cancellationToken);

        if (result.StatusCode == 404)
        {
            if (byName)
            {
                context.Error($"there's no room called '{context.Name}' on stripchat");
            }
            else
            {
                //the model was renamed or re-registered - the next check starts over from the username
                context.Warning($"model id {context.Cache} is stale (http 404) - it will be resolved again");
                context.Cache = null;
            }

            return ProbeResult.Error;
        }

        if (result.StatusCode != 200)
        {
            context.Error($"every way to the room's cam was blocked, last http {result.StatusCode} for {url}{CurlError(result)} - {Snippet(result.Body, 120)}");

            return ProbeResult.Error;
        }

        JsonNode root = JsonNode.Parse(result.Body)!;
        JsonNode? user = root["user"]?["user"];

        //a wrong id would quietly return another model's stream
        string? reportedName = Str(user?["username"]);

        if (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, context.Name, StringComparison.OrdinalIgnoreCase))
        {
            context.Error($"the api answered about '{reportedName}' instead of '{context.Name}' - the model id has been discarded");
            context.Cache = null;

            return ProbeResult.Error;
        }

        if (string.IsNullOrEmpty(context.Cache) && Str(user?["id"]) is { Length: > 0 } id)
        {
            context.Cache = id;
        }

        string? raw = Str(user?["status"]);

        ChatRoomStatus status = raw switch
        {
            "public" => ChatRoomStatus.Public,
            "virtualPrivate" or "private" or "p2p" or "p2pVoice" => ChatRoomStatus.Private,
            "groupShow" => ChatRoomStatus.Group,
            "idle" => ChatRoomStatus.Idle,
            "off" => ChatRoomStatus.Offline,
            "" => ChatRoomStatus.Hidden,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status} ('{raw}') via {url}");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        string? streamName = Str(root["cam"]?["streamName"]);

        if (string.IsNullOrEmpty(streamName))
        {
            context.Error("the room is public but the api didn't give a stream name");

            return ProbeResult.Error;
        }

        string playlistUrl = $"https://media-hls.growcdnssedge.com/b-hls-{Random.Shared.Next(1, 26):00}/{streamName}/{streamName}.m3u8";

        //only the source resolution is published nowadays (cam.broadcastConfig), older rooms still
        //carry cam.broadcastSettings
        JsonNode? config = root["cam"]?["broadcastConfig"];
        JsonNode? settings = root["cam"]?["broadcastSettings"];
        List<Resolution> resolutions = new();

        if (Int(config?["flashWidth"]) is int configWidth && Int(config?["flashHeight"]) is int configHeight)
        {
            resolutions.Add(new Resolution((short)configWidth, (short)configHeight));
        }
        else if (Int(settings?["width"]) is int settingsWidth && Int(settings?["height"]) is int settingsHeight)
        {
            resolutions.Add(new Resolution((short)settingsWidth, (short)settingsHeight));
        }

        //streamlink always takes the best stream here - the playlist only has the source anyway
        return Finish(context, status, playlistUrl, resolutions,
            _ => new RecordTarget(RecordMethod.Streamlink, playlistUrl, 0, "best"));
    }

    private async Task<(HttpResult Result, string Url, bool ByName)> GetCamAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        List<(string Url, bool ByName)> ways = new();

        if (!string.IsNullOrEmpty(context.Cache))
        {
            ways.AddRange(Hosts.Select(host => (string.Format(CamByIdUri, host, context.Cache), false)));
        }

        ways.Add((string.Format(CamByNameUri, Uri.EscapeDataString(context.Name)), true));

        HttpResult result = new(0, string.Empty, string.Empty);
        (string Url, bool ByName) last = ways[^1];

        for (int round = 0; round < Rounds; round++)
        {
            if (round > 0)
            {
                await Task.Delay(Random.Shared.Next(1500, 3000), cancellationToken);
            }

            foreach ((string url, bool byName) in ways)
            {
                result = await CurlClient.SendAsync(url, cancellationToken, Headers);
                last = (url, byName);

                //a 200 is the answer, a 404 is an answer about the room that no other way will change
                if (result.StatusCode is 200 or 404)
                {
                    return (result, url, byName);
                }
            }
        }

        return (result, last.Url, last.ByName);
    }

    //resolves the username to the numeric model id, checking the answer is about the room we asked for
    //NotFound means the website said the username doesn't exist - a blocked lookup only gives no id
    private async Task<(string? Id, bool NotFound)> ResolveModelIdAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        foreach (string host in Hosts)
        {
            string url = string.Format(UserUri, host, Uri.EscapeDataString(context.Name));
            HttpResult result = await CurlClient.SendAsync(url, cancellationToken, Headers);

            if (result.StatusCode == 404)
            {
                return (null, true);
            }

            if (result.StatusCode != 200)
            {
                continue;
            }

            JsonNode? item = JsonNode.Parse(result.Body)?["item"];
            string? id = Str(item?["id"]);
            string? reportedName = Str(item?["username"]);

            if (string.IsNullOrEmpty(id) ||
                (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, context.Name, StringComparison.OrdinalIgnoreCase)))
            {
                return (null, false);
            }

            context.Info($"model id of {context.Name} is {id}");

            return (id, false);
        }

        return (null, false);
    }
}
