using System.Net;
using System.Net.Http;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public enum RecordMethod
{
    //ffmpeg reads the hls playlist itself and picks the variant by program index
    FFmpeg,

    //streamlink reads the playlist and serves the stream to ffmpeg over a local http port
    Streamlink
}

public sealed record RecordTarget(RecordMethod Method, string PlaylistUrl, int ProgramIndex, string StreamName);

public sealed record ProbeResult(ChatRoomStatus Status, string PlaylistUrl, IReadOnlyList<Resolution> Resolutions, RecordTarget? Target)
{
    public static ProbeResult Error { get; } = Of(ChatRoomStatus.Error);

    public static ProbeResult Of(ChatRoomStatus status) => new(status, string.Empty, Array.Empty<Resolution>(), null);
}

//what a probe gets to know about the room, plus a per-room cache slot for data a website needs to
//carry between checks (stripchat's numeric model id)
public sealed class ProbeContext
{
    private readonly LogService _log;

    public ProbeContext(ChatRoomWebsite website, string name, Resolution preferredResolution, string? cache, LogService log)
    {
        Website = website;
        Name = name;
        PreferredResolution = preferredResolution;
        Cache = cache;
        _log = log;
    }

    public ChatRoomWebsite Website { get; }

    public string Name { get; }

    public Resolution PreferredResolution { get; }

    public string? Cache { get; set; }

    //the last problem reported during the probe, shown next to the room
    public string? LastError { get; private set; }

    public void Info(string message) => _log.Room(Website, Name, LogLevel.Info, message);

    public void Warning(string message)
    {
        LastError = message;
        _log.Room(Website, Name, LogLevel.Warning, message);
    }

    public void Error(string message)
    {
        LastError = message;
        _log.Room(Website, Name, LogLevel.Error, message);
    }
}

public interface ISiteProbe
{
    ChatRoomWebsite Website { get; }

    Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken);
}

public abstract class SiteProbe : ISiteProbe
{
    protected static readonly string[] XhrHeaders =
    {
        "Accept: application/json, text/plain, */*",
        "X-Requested-With: XMLHttpRequest"
    };

    public abstract ChatRoomWebsite Website { get; }

    public abstract Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken);

    public static IReadOnlyList<ISiteProbe> All { get; } = new ISiteProbe[]
    {
        new BongaCamsProbe(),
        new ChaturbateProbe(),
        new StripchatProbe(),
        new Flirt4FreeProbe(),
        new CamSodaProbe(),
        new Cam4Probe()
    };

    //requests an api url and returns the body, or null (with the reason logged) when the answer
    //isn't a usable json response
    protected static async Task<string?> GetApiAsync(
        ProbeContext context, string url, CancellationToken cancellationToken, IEnumerable<string>? headers = null, string? postData = null)
    {
        HttpResult result = await CurlClient.SendAsync(url, cancellationToken, headers ?? XhrHeaders, postData).ConfigureAwait(false);

        if (result.StatusCode != 200)
        {
            context.Error($"the api answered http {result.StatusCode} for {url}{CurlError(result)} - {Snippet(result.Body)}");

            return null;
        }

        if (result.Body.TrimStart().StartsWith('<'))
        {
            context.Error($"the api answered with an html page instead of json for {url} - most likely a block or challenge page - {Snippet(result.Body)}");

            return null;
        }

        return result.Body;
    }

    //finishes a probe: logs what was found and picks the stream closest to the preferred resolution
    protected static ProbeResult Finish(
        ProbeContext context, ChatRoomStatus status, string playlistUrl, IReadOnlyList<Resolution> resolutions, Func<int, RecordTarget> target)
    {
        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        context.Info($"playlist - {playlistUrl}");
        context.Info($"resolutions - {string.Join(", ", resolutions)}");

        int index = Resolution.FindClosest(context.PreferredResolution, resolutions);

        if (index == -1)
        {
            context.Error($"the room is public, but its playlist didn't list any stream - it may be empty or blocked ({playlistUrl})");

            return ProbeResult.Error;
        }

        return new ProbeResult(status, playlistUrl, resolutions, target(index));
    }

    //curl explains failures over several lines - the first one says what happened
    protected static string CurlError(HttpResult result) =>
        string.IsNullOrWhiteSpace(result.Error) ? string.Empty : $" - curl said: {result.Error.Split('\n')[0].Trim()}";

    //indexing a json value that isn't an object throws, and these payloads are not always shaped the
    //way they were yesterday - this keeps a surprise from turning into an exception
    protected static JsonObject? Obj(JsonNode? node) => node as JsonObject;

    protected static string? Str(JsonNode? node) =>
        node is JsonValue value && value.TryGetValue(out string? text) ? text : node?.ToString();

    protected static int? Int(JsonNode? node)
    {
        if (node is not JsonValue value)
        {
            return null;
        }

        if (value.TryGetValue(out int number))
        {
            return number;
        }

        if (value.TryGetValue(out double real))
        {
            return (int)real;
        }

        return value.TryGetValue(out string? text) && int.TryParse(text, out number) ? number : null;
    }

    public static string Snippet(string? text, int max = 300)
    {
        if (string.IsNullOrEmpty(text))
        {
            return "(empty body)";
        }

        string line = Regex.Replace(text, @"\s+", " ").Trim();

        return line.Length <= max ? line : $"{line[..max]}...({text.Length} chars)";
    }
}

//playlists live on the cdns, which don't fingerprint the client - a plain HttpClient is fine there
public static class PlaylistClient
{
    private static readonly HttpClient s_client = CreateClient();

    public static async Task<(bool Success, string Text)> GetAsync(string url, CancellationToken cancellationToken)
    {
        using HttpResponseMessage response = await s_client.GetAsync(url, cancellationToken).ConfigureAwait(false);
        string text = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

        return (response.IsSuccessStatusCode, text);
    }

    //one RESOLUTION attribute per variant, in playlist order - the index is ffmpeg's program index
    public static List<Resolution> ParseResolutions(string playlist) =>
        Regex.Matches(playlist, "RESOLUTION=([0-9]+x[0-9]+)", RegexOptions.IgnoreCase)
            .Select(match => Resolution.Parse(match.Groups[1].Value))
            .ToList();

    private static HttpClient CreateClient()
    {
        SocketsHttpHandler handler = new()
        {
            AutomaticDecompression = DecompressionMethods.All,
            ConnectTimeout = TimeSpan.FromSeconds(10),
            PooledConnectionLifetime = TimeSpan.FromMinutes(5)
        };

        HttpClient client = new(handler) { Timeout = TimeSpan.FromSeconds(20) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd(CurlClient.UserAgent);

        return client;
    }
}
