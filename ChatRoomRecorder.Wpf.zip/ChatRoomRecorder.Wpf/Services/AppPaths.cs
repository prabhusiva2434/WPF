using System.IO;

namespace ChatRoomRecorder.Wpf.Services;

//the app keeps its data next to its own executable, the way the classic app does - copy the folder
//somewhere else and the rooms, settings and thumbnails travel with it
public static class AppPaths
{
    public static string DataDirectory { get; } = ResolveDataDirectory();

    public static string DatabasePath => Path.Combine(DataDirectory, "ChatRoomRecorder.db");

    public static string ThumbnailsDirectory => Path.Combine(DataDirectory, "Thumbnails");

    public static string CrashLogPath => Path.Combine(DataDirectory, "errors.log");

    //earlier versions kept everything under %LocalAppData% instead
    public static string LegacyDataDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChatRoomRecorderWpf");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(DataDirectory);
        BringLegacyDataAlong();
        Directory.CreateDirectory(ThumbnailsDirectory);
    }

    private static string ResolveDataDirectory()
    {
        //ProcessPath is the exe itself; BaseDirectory covers being run through a host (dotnet run)
        string? executable = Environment.ProcessPath;

        return string.IsNullOrEmpty(executable)
            ? AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar)
            : Path.GetDirectoryName(executable)!;
    }

    //the first start after the move: take the old database and thumbnails with us, leaving the
    //originals untouched
    private static void BringLegacyDataAlong()
    {
        try
        {
            if (File.Exists(DatabasePath) || !Directory.Exists(LegacyDataDirectory))
            {
                return;
            }

            //the write-ahead files hold commits that aren't in the database file yet
            foreach (string suffix in new[] { string.Empty, "-wal", "-shm" })
            {
                string source = Path.Combine(LegacyDataDirectory, "ChatRoomRecorder.db" + suffix);

                if (File.Exists(source))
                {
                    File.Copy(source, DatabasePath + suffix, true);
                }
            }

            string legacyThumbnails = Path.Combine(LegacyDataDirectory, "Thumbnails");

            if (Directory.Exists(legacyThumbnails))
            {
                Directory.CreateDirectory(ThumbnailsDirectory);

                foreach (string thumbnail in Directory.EnumerateFiles(legacyThumbnails))
                {
                    string target = Path.Combine(ThumbnailsDirectory, Path.GetFileName(thumbnail));

                    if (!File.Exists(target))
                    {
                        File.Copy(thumbnail, target);
                    }
                }
            }
        }
        catch (Exception)
        {
            //nothing carried over - the app starts with a fresh database next to the executable
        }
    }
}
