using System.IO;
using System.Windows;
using System.Windows.Threading;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.ViewModels;
using ChatRoomRecorder.Wpf.Views;

namespace ChatRoomRecorder.Wpf;

public partial class App : Application
{
    private readonly LogService _log = new();
    private Mutex? _singleInstance;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        //two copies on the same data would record every room twice
        _singleInstance = new Mutex(true, "ChatRoomRecorderWpf.SingleInstance", out bool createdNew);

        if (!createdNew)
        {
            MessageBox.Show("ChatRoom Recorder Studio is already running.", "ChatRoom Recorder Studio", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();

            return;
        }

        //nothing unexpected takes the app down or leaves it frozen - it's logged and the app carries on
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Report("background task", args.Exception);
            args.SetObserved();
        };
        AppDomain.CurrentDomain.UnhandledException += (_, args) => Report("fatal", args.ExceptionObject as Exception);

        Views.MainWindow window = new(new MainViewModel(_log, new DialogService()));
        MainWindow = window;
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _singleInstance?.Dispose();

        base.OnExit(e);
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Report("ui", e.Exception);
        e.Handled = true;
    }

    private void Report(string source, Exception? exception)
    {
        if (exception == null)
        {
            return;
        }

        _log.Error(source, $"{exception.GetType().Name}: {exception.Message}");

        try
        {
            Directory.CreateDirectory(AppPaths.DataDirectory);
            File.AppendAllText(AppPaths.CrashLogPath, $"{DateTime.Now:O} [{source}] {exception}{Environment.NewLine}{Environment.NewLine}");
        }
        catch
        {
            //nowhere left to report to
        }
    }
}
