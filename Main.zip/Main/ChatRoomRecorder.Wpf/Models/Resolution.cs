using System.Text.RegularExpressions;

namespace ChatRoomRecorder.Wpf.Models;

public readonly record struct Resolution : IComparable<Resolution>
{
    public Resolution(short width, short height)
    {
        Width = width >= 0 && height >= 0 ? width : (short)0;
        Height = width >= 0 && height >= 0 ? height : (short)0;
    }

    public short Width { get; }

    public short Height { get; }

    public int TotalPixels => Width * Height;

    public bool IsBest => this == MaxValue;

    public static Resolution MinValue => new(0, 0);

    public static Resolution MaxValue => new(short.MaxValue, short.MaxValue);

    public static IReadOnlyList<Resolution> Common { get; } = new[]
    {
        new Resolution(640, 360),
        new Resolution(960, 540),
        new Resolution(1280, 720),
        new Resolution(1600, 900),
        new Resolution(1920, 1080),
        new Resolution(2560, 1440),
        new Resolution(3840, 2160)
    };

    //the choices offered in the ui - the common ladder plus "best", which always picks the largest stream
    public static IReadOnlyList<Resolution> Choices { get; } = Common.Append(MaxValue).ToArray();

    public int CompareTo(Resolution other) => TotalPixels.CompareTo(other.TotalPixels);

    public override string ToString() => IsBest ? "Best" : $"{Width}x{Height}";

    //same packing as the classic app, so the stored values are interchangeable
    public int ToInt32() => (Width << 16) | (ushort)Height;

    public static Resolution FromInt32(int value) => new((short)(value >> 16), (short)(value & 0xFFFF));

    public static Resolution Parse(string? text)
    {
        Match match = Regex.Match(text ?? string.Empty, "^([0-9]+)x([0-9]+)$", RegexOptions.IgnoreCase);

        return match.Success &&
            short.TryParse(match.Groups[1].Value, out short width) &&
            short.TryParse(match.Groups[2].Value, out short height)
            ? new Resolution(width, height)
            : MinValue;
    }

    public static int FindClosest(Resolution desired, IReadOnlyList<Resolution> available)
    {
        int index = -1;
        long difference = -1;

        for (int i = 0; i < available.Count; i++)
        {
            if (available[i] == MinValue)
            {
                continue;
            }

            long current = Math.Abs((long)desired.TotalPixels - available[i].TotalPixels);

            if (index == -1 || current < difference)
            {
                index = i;
                difference = current;
            }
        }

        return index;
    }
}
