using CommunityToolkit.Mvvm.ComponentModel;

namespace ChatRoomRecorder.Wpf.Models;

public sealed class AppSettings : ObservableObject
{
    private string _outputDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
    private string _ffmpegPath = $"{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)}\\Streamlink\\ffmpeg\\ffmpeg.exe";
    private string _streamlinkPath = $"{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)}\\Streamlink\\bin\\streamlink.exe";
    private int _chaturbateConcurrentUpdates = 5;
    private int _bongaCamsConcurrentUpdates = 5;
    private int _stripchatConcurrentUpdates = 5;
    private int _flirt4FreeConcurrentUpdates = 5;
    private int _camSodaConcurrentUpdates = 5;
    private int _cam4ConcurrentUpdates = 5;
    private int _updateDelay = 15;
    private int _updateInterval = 60;
    private ChatRoomAction _defaultAction = ChatRoomAction.Record;
    private Resolution _defaultResolution = new(1280, 720);
    private VideoEncoder _videoEncoder = VideoEncoder.Copy;
    private int _videoQuality = 28;
    private VideoPreset _videoPreset = VideoPreset.VeryFast;
    private int _audioBitrate;
    private int _maxVideoHeight;
    private bool _addFromClipboard = true;
    private int _logSize = 2000;

    public string OutputDirectory { get => _outputDirectory; set => SetProperty(ref _outputDirectory, value ?? string.Empty); }

    public string FFmpegPath { get => _ffmpegPath; set => SetProperty(ref _ffmpegPath, value ?? string.Empty); }

    public string StreamlinkPath { get => _streamlinkPath; set => SetProperty(ref _streamlinkPath, value ?? string.Empty); }

    public int ChaturbateConcurrentUpdates { get => _chaturbateConcurrentUpdates; set => SetProperty(ref _chaturbateConcurrentUpdates, Math.Max(1, value)); }

    public int BongaCamsConcurrentUpdates { get => _bongaCamsConcurrentUpdates; set => SetProperty(ref _bongaCamsConcurrentUpdates, Math.Max(1, value)); }

    public int StripchatConcurrentUpdates { get => _stripchatConcurrentUpdates; set => SetProperty(ref _stripchatConcurrentUpdates, Math.Max(1, value)); }

    public int Flirt4FreeConcurrentUpdates { get => _flirt4FreeConcurrentUpdates; set => SetProperty(ref _flirt4FreeConcurrentUpdates, Math.Max(1, value)); }

    public int CamSodaConcurrentUpdates { get => _camSodaConcurrentUpdates; set => SetProperty(ref _camSodaConcurrentUpdates, Math.Max(1, value)); }

    public int Cam4ConcurrentUpdates { get => _cam4ConcurrentUpdates; set => SetProperty(ref _cam4ConcurrentUpdates, Math.Max(1, value)); }

    //random delay (seconds) before each request, to spread the requests out
    public int UpdateDelay { get => _updateDelay; set => SetProperty(ref _updateDelay, Math.Max(0, value)); }

    //seconds between two checks of the same room
    public int UpdateInterval { get => _updateInterval; set => SetProperty(ref _updateInterval, Math.Max(1, value)); }

    public ChatRoomAction DefaultAction { get => _defaultAction; set => SetProperty(ref _defaultAction, value); }

    public Resolution DefaultResolution { get => _defaultResolution; set => SetProperty(ref _defaultResolution, value); }

    public VideoEncoder VideoEncoder { get => _videoEncoder; set => SetProperty(ref _videoEncoder, value); }

    public int VideoQuality { get => _videoQuality; set => SetProperty(ref _videoQuality, Math.Clamp(value, 0, 51)); }

    public VideoPreset VideoPreset { get => _videoPreset; set => SetProperty(ref _videoPreset, value); }

    public int AudioBitrate { get => _audioBitrate; set => SetProperty(ref _audioBitrate, Math.Max(0, value)); }

    public int MaxVideoHeight { get => _maxVideoHeight; set => SetProperty(ref _maxVideoHeight, Math.Max(0, value)); }

    public bool AddFromClipboard { get => _addFromClipboard; set => SetProperty(ref _addFromClipboard, value); }

    public int LogSize { get => _logSize; set => SetProperty(ref _logSize, Math.Max(0, value)); }

    public int ConcurrentUpdates(ChatRoomWebsite website) => website switch
    {
        ChatRoomWebsite.Chaturbate => ChaturbateConcurrentUpdates,
        ChatRoomWebsite.BongaCams => BongaCamsConcurrentUpdates,
        ChatRoomWebsite.Stripchat => StripchatConcurrentUpdates,
        ChatRoomWebsite.Flirt4Free => Flirt4FreeConcurrentUpdates,
        ChatRoomWebsite.CamSoda => CamSodaConcurrentUpdates,
        ChatRoomWebsite.Cam4 => Cam4ConcurrentUpdates,
        _ => 1
    };

    //a snapshot of the encoding settings, handed to a recording when it starts
    public RecordingOptions CreateRecordingOptions() => new(
        OutputDirectory, FFmpegPath, StreamlinkPath, VideoEncoder, VideoQuality, VideoPreset, AudioBitrate, MaxVideoHeight);
}

public sealed record RecordingOptions(
    string OutputDirectory,
    string FFmpegPath,
    string StreamlinkPath,
    VideoEncoder VideoEncoder,
    int VideoQuality,
    VideoPreset VideoPreset,
    int AudioBitrate,
    int MaxVideoHeight);
