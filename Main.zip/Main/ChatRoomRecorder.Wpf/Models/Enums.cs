namespace ChatRoomRecorder.Wpf.Models;

//the numeric values are stored in the database and match the classic app, so keep the order

public enum ChatRoomAction
{
    None,
    Monitor,
    Record
}

public enum ChatRoomStatus
{
    Unknown,
    Error,
    Offline,
    Idle,
    Away,
    Hidden,
    Group,
    Private,
    Public,
    Record
}

public enum ChatRoomWebsite
{
    BongaCams,
    Chaturbate,
    Stripchat,
    Flirt4Free,
    CamSoda,
    Cam4
}

public enum VideoEncoder
{
    Copy,
    H264,
    H265,
    H264_NVENC,
    H265_NVENC,
    H264_QSV,
    H265_QSV
}

public enum VideoPreset
{
    UltraFast,
    SuperFast,
    VeryFast,
    Faster,
    Fast,
    Medium,
    Slow
}
