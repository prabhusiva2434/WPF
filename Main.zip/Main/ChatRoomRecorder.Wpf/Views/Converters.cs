using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using ChatRoomRecorder.Wpf.Models;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Views;

public sealed class StatusBrushConverter : IValueConverter
{
    private static readonly Dictionary<ChatRoomStatus, Brush> Brushes = new()
    {
        [ChatRoomStatus.Record] = Freeze(Color.FromRgb(0xE5, 0x39, 0x35)),
        [ChatRoomStatus.Public] = Freeze(Color.FromRgb(0x2E, 0x9D, 0x57)),
        [ChatRoomStatus.Private] = Freeze(Color.FromRgb(0x8E, 0x5C, 0xD9)),
        [ChatRoomStatus.Group] = Freeze(Color.FromRgb(0x3F, 0x7F, 0xDB)),
        [ChatRoomStatus.Idle] = Freeze(Color.FromRgb(0xE0, 0x9A, 0x1A)),
        [ChatRoomStatus.Away] = Freeze(Color.FromRgb(0xE0, 0x9A, 0x1A)),
        [ChatRoomStatus.Hidden] = Freeze(Color.FromRgb(0x7A, 0x86, 0x94)),
        [ChatRoomStatus.Offline] = Freeze(Color.FromRgb(0x7A, 0x86, 0x94)),
        [ChatRoomStatus.Error] = Freeze(Color.FromRgb(0xC6, 0x28, 0x28)),
        [ChatRoomStatus.Unknown] = Freeze(Color.FromRgb(0xA0, 0xA8, 0xB0))
    };

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is ChatRoomStatus status ? Brushes[status] : Brushes[ChatRoomStatus.Unknown];

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;

    internal static Brush Freeze(Color color)
    {
        SolidColorBrush brush = new(color);
        brush.Freeze();

        return brush;
    }
}

public sealed class StatusTextConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        ChatRoomStatus.Record => "Recording",
        ChatRoomStatus.Unknown => "Not checked",
        ChatRoomStatus status => status.ToString(),
        _ => string.Empty
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class NotificationBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        NotificationKind.Success => StatusBrushConverter.Freeze(Color.FromRgb(0x2E, 0x9D, 0x57)),
        NotificationKind.Warning => StatusBrushConverter.Freeze(Color.FromRgb(0xE0, 0x9A, 0x1A)),
        NotificationKind.Error => StatusBrushConverter.Freeze(Color.FromRgb(0xC6, 0x28, 0x28)),
        _ => StatusBrushConverter.Freeze(Color.FromRgb(0x3F, 0x7F, 0xDB))
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class LogLevelBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        LogLevel.Error => StatusBrushConverter.Freeze(Color.FromRgb(0xC6, 0x28, 0x28)),
        LogLevel.Warning => StatusBrushConverter.Freeze(Color.FromRgb(0xE0, 0x9A, 0x1A)),
        _ => StatusBrushConverter.Freeze(Color.FromRgb(0x7A, 0x86, 0x94))
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class FriendlyTimeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        DateTime? time = value as DateTime?;

        if (time == null || time == DateTime.MinValue)
        {
            return "—";
        }

        return time.Value.Date == DateTime.Today ? time.Value.ToString("HH:mm:ss") : time.Value.ToString("yyyy-MM-dd HH:mm");
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class FileSizeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is long bytes ? FileService.FormatSize(bytes) : string.Empty;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

//true -> visible; ConverterParameter=Invert flips it
public sealed class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool visible = value is true;

        if (parameter as string == "Invert")
        {
            visible = !visible;
        }

        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

//null or empty -> collapsed; ConverterParameter=Invert flips it
public sealed class NullToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool visible = value is not null && value is not string { Length: 0 };

        if (parameter as string == "Invert")
        {
            visible = !visible;
        }

        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class JobStateTextConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        JobState.Queued => "Waiting",
        JobState.Running => "Running",
        JobState.Completed => "Done",
        JobState.Failed => "Failed",
        JobState.Cancelled => "Cancelled",
        _ => string.Empty
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}
