using System.Reflection;
using System.Windows.Controls;

namespace ChatRoomRecorder.Wpf.Views;

public partial class AboutView : UserControl
{
    public AboutView()
    {
        InitializeComponent();

        Assembly assembly = typeof(AboutView).Assembly;
        DescriptionText.Text = assembly.GetCustomAttribute<AssemblyDescriptionAttribute>()?.Description ?? string.Empty;
        CopyrightText.Text = assembly.GetCustomAttribute<AssemblyCopyrightAttribute>()?.Copyright ?? string.Empty;
    }
}
