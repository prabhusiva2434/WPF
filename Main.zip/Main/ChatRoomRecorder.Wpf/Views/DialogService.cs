using System.Windows;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.Views.Dialogs;
using Microsoft.Win32;

namespace ChatRoomRecorder.Wpf.Views;

public sealed class DialogService : IDialogService
{
    private static Window? Owner =>
        Application.Current?.Windows.OfType<Window>().FirstOrDefault(window => window.IsActive) ?? Application.Current?.MainWindow;

    public bool Confirm(string title, string message) =>
        (Owner is Window owner
            ? MessageBox.Show(owner, message, title, MessageBoxButton.OKCancel, MessageBoxImage.Question)
            : MessageBox.Show(message, title, MessageBoxButton.OKCancel, MessageBoxImage.Question)) == MessageBoxResult.OK;

    public void ShowError(string title, string message)
    {
        if (Owner is Window owner)
        {
            MessageBox.Show(owner, message, title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        else
        {
            MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    public string? Prompt(string title, string label, string initialValue) => TextPromptDialog.Ask(Owner, title, label, initialValue);

    public string? PickFolder(string title)
    {
        OpenFolderDialog dialog = new() { Title = title };

        return dialog.ShowDialog(Owner) == true ? dialog.FolderName : null;
    }

    public string? PickFile(string title, string filter)
    {
        OpenFileDialog dialog = new() { Title = title, Filter = filter, Multiselect = false };

        return dialog.ShowDialog(Owner) == true ? dialog.FileName : null;
    }

    public string? AskForUrls() => UrlsDialog.Ask(Owner);

    public IReadOnlyList<RecordingFileInfo>? OrderForMerge(IReadOnlyList<RecordingFileInfo> files) => MergeDialog.Ask(Owner, files);

    public (TimeSpan Start, TimeSpan End)? PickFragment(string file) => MediaPickerDialog.PickFragment(Owner, file);

    public TimeSpan? PickThumbnailPosition(string file) => MediaPickerDialog.PickPosition(Owner, file);
}
