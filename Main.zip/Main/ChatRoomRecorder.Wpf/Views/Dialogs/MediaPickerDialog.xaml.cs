using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;

namespace ChatRoomRecorder.Wpf.Views.Dialogs;

//previews a recording and lets the user pick a fragment (extract) or a single position (thumbnail).
//the times can also be typed, so the dialog stays usable when a file can't be previewed
public partial class MediaPickerDialog : Window
{
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(250) };
    private readonly bool _fragment;
    private bool _playing;
    private bool _syncingSlider;
    private TimeSpan? _duration;

    private MediaPickerDialog(string file, bool fragment)
    {
        InitializeComponent();

        _fragment = fragment;
        Title = fragment ? "Extract a fragment" : "Choose the thumbnail frame";
        FileText.Text = file;
        FragmentPanel.Visibility = fragment ? Visibility.Visible : Visibility.Collapsed;
        PositionPanel.Visibility = fragment ? Visibility.Collapsed : Visibility.Visible;
        StartBox.Text = "00:00:00";
        PositionBox.Text = "00:00:00";
        OkButton.Content = fragment ? "Extract" : "Use this frame";

        ErrorText.Visibility = Visibility.Collapsed;

        _timer.Tick += (_, _) => SyncSlider();
        Closed += (_, _) =>
        {
            _timer.Stop();
            Player.Close();
        };

        if (File.Exists(file))
        {
            Player.Source = new Uri(file);

            //playing and pausing right away loads the first frame
            Player.Play();
            Player.Pause();
        }
        else
        {
            PreviewMessage.Text = "The file isn't there anymore";
        }
    }

    public TimeSpan Start { get; private set; }

    public TimeSpan End { get; private set; }

    public TimeSpan Position { get; private set; }

    public static (TimeSpan Start, TimeSpan End)? PickFragment(Window? owner, string file)
    {
        MediaPickerDialog dialog = new(file, fragment: true) { Owner = owner };

        return dialog.ShowDialog() == true ? (dialog.Start, dialog.End) : null;
    }

    public static TimeSpan? PickPosition(Window? owner, string file)
    {
        MediaPickerDialog dialog = new(file, fragment: false) { Owner = owner };

        return dialog.ShowDialog() == true ? dialog.Position : null;
    }

    private void Player_MediaOpened(object sender, RoutedEventArgs e)
    {
        PreviewMessage.Visibility = Visibility.Collapsed;

        if (Player.NaturalDuration.HasTimeSpan)
        {
            _duration = Player.NaturalDuration.TimeSpan;
            PositionSlider.Maximum = Math.Max(1, _duration.Value.TotalSeconds);

            if (string.IsNullOrWhiteSpace(EndBox.Text))
            {
                EndBox.Text = Format(_duration.Value);
            }
        }

        _timer.Start();
        SyncSlider();
    }

    private void Player_MediaFailed(object? sender, ExceptionRoutedEventArgs e)
    {
        PreviewMessage.Text = $"This recording can't be previewed here ({e.ErrorException?.Message}).\nYou can still type the times below.";
        PreviewMessage.Visibility = Visibility.Visible;
        PlayButton.IsEnabled = false;
        PositionSlider.IsEnabled = false;
    }

    private void Player_MediaEnded(object sender, RoutedEventArgs e) => SetPlaying(false);

    private void PlayButton_Click(object sender, RoutedEventArgs e) => SetPlaying(!_playing);

    private void SetPlaying(bool playing)
    {
        _playing = playing;

        if (playing)
        {
            Player.Play();
        }
        else
        {
            Player.Pause();
        }

        PlayIcon.Text = playing ? "" : "";
    }

    private void PositionSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_syncingSlider)
        {
            Player.Position = TimeSpan.FromSeconds(e.NewValue);
            UpdateTimeText();
        }
    }

    private void SyncSlider()
    {
        _syncingSlider = true;
        PositionSlider.Value = Math.Min(PositionSlider.Maximum, Player.Position.TotalSeconds);
        _syncingSlider = false;
        UpdateTimeText();
    }

    private void UpdateTimeText() =>
        TimeText.Text = $"{Format(Player.Position)} / {(_duration is TimeSpan duration ? Format(duration) : "--:--:--")}";

    private void UseStartButton_Click(object sender, RoutedEventArgs e) => StartBox.Text = Format(Player.Position);

    private void UseEndButton_Click(object sender, RoutedEventArgs e) => EndBox.Text = Format(Player.Position);

    private void UsePositionButton_Click(object sender, RoutedEventArgs e) => PositionBox.Text = Format(Player.Position);

    private void OkButton_Click(object sender, RoutedEventArgs e)
    {
        if (_fragment)
        {
            if (!TryParse(StartBox.Text, out TimeSpan start) || !TryParse(EndBox.Text, out TimeSpan end))
            {
                ShowError("Type the start and the end as hh:mm:ss");

                return;
            }

            if (start >= end)
            {
                ShowError("The end has to come after the start");

                return;
            }

            Start = start;
            End = end;
        }
        else
        {
            if (!TryParse(PositionBox.Text, out TimeSpan position))
            {
                ShowError("Type the position as hh:mm:ss");

                return;
            }

            Position = position;
        }

        DialogResult = true;
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }

    private static bool TryParse(string text, out TimeSpan time) =>
        TimeSpan.TryParse(text.Trim(), CultureInfo.InvariantCulture, out time) && time >= TimeSpan.Zero;

    private static string Format(TimeSpan time) =>
        time.Milliseconds == 0
            ? $"{(int)time.TotalHours:00}:{time.Minutes:00}:{time.Seconds:00}"
            : $"{(int)time.TotalHours:00}:{time.Minutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
}
