using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using ChatRoomRecorder.Wpf.Services;

namespace ChatRoomRecorder.Wpf.Views.Dialogs;

public partial class MergeDialog : Window
{
    private readonly ObservableCollection<RecordingFileInfo> _files;
    private Point _dragStart;
    private RecordingFileInfo? _dragged;

    private MergeDialog(IReadOnlyList<RecordingFileInfo> files)
    {
        InitializeComponent();

        _files = new ObservableCollection<RecordingFileInfo>(files);
        FilesList.ItemsSource = _files;
        Closed += (_, _) => Player.Close();
    }

    public static IReadOnlyList<RecordingFileInfo>? Ask(Window? owner, IReadOnlyList<RecordingFileInfo> files)
    {
        MergeDialog dialog = new(files) { Owner = owner };

        return dialog.ShowDialog() == true ? dialog._files.ToList() : null;
    }

    private void MoveUpButton_Click(object sender, RoutedEventArgs e) => MoveSelected(-1);

    private void MoveDownButton_Click(object sender, RoutedEventArgs e) => MoveSelected(1);

    private void MoveSelected(int offset)
    {
        int index = FilesList.SelectedIndex;
        int target = index + offset;

        if (index >= 0 && target >= 0 && target < _files.Count)
        {
            _files.Move(index, target);
            FilesList.SelectedIndex = target;
        }
    }

    private void PreviewButton_Click(object sender, RoutedEventArgs e) => Preview();

    private void FilesList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => Preview();

    private void Preview()
    {
        if (FilesList.SelectedItem is RecordingFileInfo file)
        {
            PreviewMessage.Visibility = Visibility.Collapsed;
            Player.Source = new Uri(file.FullName);
            Player.Play();
        }
    }

    private void Player_MediaFailed(object? sender, ExceptionRoutedEventArgs e)
    {
        PreviewMessage.Text = $"This file can't be previewed here - {e.ErrorException?.Message}";
        PreviewMessage.Visibility = Visibility.Visible;
    }

    private void FilesList_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _dragStart = e.GetPosition(FilesList);
        _dragged = ItemAt(e.OriginalSource);
    }

    private void FilesList_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || _dragged == null)
        {
            return;
        }

        Vector moved = e.GetPosition(FilesList) - _dragStart;

        if (Math.Abs(moved.X) > SystemParameters.MinimumHorizontalDragDistance ||
            Math.Abs(moved.Y) > SystemParameters.MinimumVerticalDragDistance)
        {
            DragDrop.DoDragDrop(FilesList, _dragged, DragDropEffects.Move);
            _dragged = null;
        }
    }

    private void FilesList_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(typeof(RecordingFileInfo)) is RecordingFileInfo dropped && ItemAt(e.OriginalSource) is RecordingFileInfo target)
        {
            int from = _files.IndexOf(dropped);
            int to = _files.IndexOf(target);

            if (from >= 0 && to >= 0 && from != to)
            {
                _files.Move(from, to);
                FilesList.SelectedIndex = to;
            }
        }
    }

    private static RecordingFileInfo? ItemAt(object source)
    {
        for (DependencyObject? current = source as DependencyObject; current != null; current = VisualTreeHelper.GetParent(current))
        {
            if (current is ListBoxItem item)
            {
                return item.DataContext as RecordingFileInfo;
            }
        }

        return null;
    }

    private void MergeButton_Click(object sender, RoutedEventArgs e) => DialogResult = true;
}
