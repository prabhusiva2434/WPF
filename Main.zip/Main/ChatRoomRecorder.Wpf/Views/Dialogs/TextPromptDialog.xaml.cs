using System.Windows;

namespace ChatRoomRecorder.Wpf.Views.Dialogs;

public partial class TextPromptDialog : Window
{
    private TextPromptDialog(string title, string label, string initialValue)
    {
        InitializeComponent();

        Title = title;
        LabelText.Text = label;
        ValueBox.Text = initialValue;
        Loaded += (_, _) => ValueBox.SelectAll();
    }

    public static string? Ask(Window? owner, string title, string label, string initialValue)
    {
        TextPromptDialog dialog = new(title, label, initialValue) { Owner = owner };

        return dialog.ShowDialog() == true ? dialog.ValueBox.Text : null;
    }

    private void OkButton_Click(object sender, RoutedEventArgs e) => DialogResult = true;
}
