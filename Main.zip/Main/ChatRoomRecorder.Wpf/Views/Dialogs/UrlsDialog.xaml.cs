using System.Windows;

namespace ChatRoomRecorder.Wpf.Views.Dialogs;

public partial class UrlsDialog : Window
{
    private UrlsDialog()
    {
        InitializeComponent();
    }

    public static string? Ask(Window? owner)
    {
        UrlsDialog dialog = new() { Owner = owner };

        return dialog.ShowDialog() == true ? dialog.UrlsBox.Text : null;
    }

    private void AddButton_Click(object sender, RoutedEventArgs e) => DialogResult = true;
}
