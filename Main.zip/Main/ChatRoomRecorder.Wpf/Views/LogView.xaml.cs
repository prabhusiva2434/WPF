using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Views;

public partial class LogView : UserControl
{
    private MainViewModel? _subscribed;
    private bool _scrollQueued;

    public LogView()
    {
        InitializeComponent();

        DataContextChanged += OnDataContextChanged;
    }

    private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (_subscribed != null)
        {
            ((INotifyCollectionChanged)_subscribed.LogEntries).CollectionChanged -= OnEntriesChanged;
        }

        _subscribed = DataContext as MainViewModel;

        if (_subscribed != null)
        {
            ((INotifyCollectionChanged)_subscribed.LogEntries).CollectionChanged += OnEntriesChanged;
        }
    }

    //entries arrive in batches - scroll once per batch, and only while the page is shown
    private void OnEntriesChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.Action != NotifyCollectionChangedAction.Add || AutoScrollBox.IsChecked != true || !IsVisible || _scrollQueued)
        {
            return;
        }

        _scrollQueued = true;

        Dispatcher.BeginInvoke(() =>
        {
            _scrollQueued = false;

            if (LogList.Items.Count > 0)
            {
                LogList.ScrollIntoView(LogList.Items[^1]);
            }
        }, DispatcherPriority.Background);
    }
}
