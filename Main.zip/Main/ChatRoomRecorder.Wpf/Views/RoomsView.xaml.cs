using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Views;

public partial class RoomsView : UserControl
{
    private const string RoomsFormat = "ChatRoomRecorder.Rooms";
    private const string CategoryFormat = "ChatRoomRecorder.Category";

    private Point _dragStart;
    private bool _roomDragArmed;
    private CategoryViewModel? _draggedCategory;

    public RoomsView()
    {
        InitializeComponent();
    }

    private MainViewModel? ViewModel => DataContext as MainViewModel;

    #region Rooms

    private void RoomsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
        ViewModel?.UpdateSelectedRooms(RoomsGrid.SelectedItems);

    private void RoomsGrid_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (ViewModel == null || e.OriginalSource is ComboBox or TextBox)
        {
            return;
        }

        switch (e.Key)
        {
            case Key.Delete:
                ViewModel.RemoveRoomsCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.F5:
                ViewModel.CheckNowCommand.Execute(null);
                e.Handled = true;
                break;
        }
    }

    //dragging starts only from a row that is already selected (like the classic app), so a plain
    //press-and-drag still extends the selection
    private void RoomsGrid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        DataGridRow? row = FindAncestor<DataGridRow>(e.OriginalSource);

        _roomDragArmed = row is { IsSelected: true } &&
            FindAncestor<ComboBox>(e.OriginalSource) == null &&
            FindAncestor<ScrollBar>(e.OriginalSource) == null &&
            Keyboard.Modifiers == ModifierKeys.None;

        _dragStart = e.GetPosition(this);
    }

    private void RoomsGrid_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (!_roomDragArmed || e.LeftButton != MouseButtonState.Pressed || !MovedEnough(e.GetPosition(this)))
        {
            return;
        }

        _roomDragArmed = false;
        List<RoomViewModel> rooms = RoomsGrid.SelectedItems.OfType<RoomViewModel>().ToList();

        if (rooms.Count > 0)
        {
            DragDrop.DoDragDrop(RoomsGrid, new DataObject(RoomsFormat, rooms), DragDropEffects.Move);
        }
    }

    #endregion

    #region Categories

    private void CategoriesTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (ViewModel != null && e.NewValue is CategoryViewModel category)
        {
            ViewModel.SelectedCategory = category;
        }
    }

    private void CategoriesTree_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F2 && ViewModel != null)
        {
            ViewModel.RenameCategoryCommand.Execute(null);
            e.Handled = true;
        }
    }

    private void CategoriesTree_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _dragStart = e.GetPosition(this);
        _draggedCategory = FindAncestor<TreeViewItem>(e.OriginalSource)?.DataContext as CategoryViewModel;
    }

    private void CategoriesTree_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (_draggedCategory == null || _draggedCategory.IsRoot || e.LeftButton != MouseButtonState.Pressed || !MovedEnough(e.GetPosition(this)))
        {
            return;
        }

        CategoryViewModel category = _draggedCategory;
        _draggedCategory = null;
        DragDrop.DoDragDrop(CategoriesTree, new DataObject(CategoryFormat, category), DragDropEffects.Move);
    }

    private void CategoriesTree_DragOver(object sender, DragEventArgs e)
    {
        CategoryViewModel? target = FindAncestor<TreeViewItem>(e.OriginalSource)?.DataContext as CategoryViewModel;

        e.Effects = target != null && (e.Data.GetDataPresent(RoomsFormat) ||
            (e.Data.GetData(CategoryFormat) is CategoryViewModel category && category.Parent != target && !category.IsSelfOrAncestorOf(target)))
            ? DragDropEffects.Move
            : DragDropEffects.None;

        e.Handled = true;
    }

    private void CategoriesTree_Drop(object sender, DragEventArgs e)
    {
        if (ViewModel == null || FindAncestor<TreeViewItem>(e.OriginalSource)?.DataContext is not CategoryViewModel target)
        {
            return;
        }

        if (e.Data.GetData(RoomsFormat) is List<RoomViewModel> rooms)
        {
            ViewModel.MoveRooms(rooms, target);
        }
        else if (e.Data.GetData(CategoryFormat) is CategoryViewModel category)
        {
            ViewModel.MoveCategory(category, target);
        }

        e.Handled = true;
    }

    #endregion

    #region Files

    private void FilesList_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
        ViewModel?.UpdateSelectedFiles(FilesList.SelectedItems);

    private void FilesList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (FindAncestor<ListViewItem>(e.OriginalSource) != null)
        {
            ViewModel?.OpenFileCommand.Execute(null);
        }
    }

    private void FilesList_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (ViewModel == null)
        {
            return;
        }

        switch (e.Key)
        {
            case Key.Enter:
                ViewModel.OpenFileCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Delete:
                ViewModel.RemoveFilesCommand.Execute(null);
                e.Handled = true;
                break;
        }
    }

    #endregion

    private bool MovedEnough(Point position)
    {
        Vector moved = position - _dragStart;

        return Math.Abs(moved.X) > SystemParameters.MinimumHorizontalDragDistance ||
            Math.Abs(moved.Y) > SystemParameters.MinimumVerticalDragDistance;
    }

    private static T? FindAncestor<T>(object source) where T : DependencyObject
    {
        for (DependencyObject? current = source as DependencyObject; current != null;
            current = current is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(current) : LogicalTreeHelper.GetParent(current))
        {
            if (current is T match)
            {
                return match;
            }
        }

        return null;
    }
}
