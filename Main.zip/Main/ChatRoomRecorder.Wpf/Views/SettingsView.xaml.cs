using System.Windows.Controls;

namespace ChatRoomRecorder.Wpf.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
    }
}
