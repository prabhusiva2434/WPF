using System.Windows.Controls;

namespace ChatRoomRecorder.Wpf.Views;

public partial class TasksView : UserControl
{
    public TasksView()
    {
        InitializeComponent();
    }
}
