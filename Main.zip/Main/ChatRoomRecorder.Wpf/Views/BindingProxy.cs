using System.Windows;

namespace ChatRoomRecorder.Wpf.Views;

//context menus and data grid columns live outside the visual tree, so they can't find the view model
//by walking up to it - a freezable in the resources inherits the data context and hands it over
public sealed class BindingProxy : Freezable
{
    public static readonly DependencyProperty DataProperty =
        DependencyProperty.Register(nameof(Data), typeof(object), typeof(BindingProxy));

    public object? Data
    {
        get => GetValue(DataProperty);
        set => SetValue(DataProperty, value);
    }

    protected override Freezable CreateInstanceCore() => new BindingProxy();
}
