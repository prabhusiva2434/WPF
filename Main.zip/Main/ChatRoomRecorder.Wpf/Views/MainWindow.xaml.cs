using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ChatRoomRecorder.Wpf.Services;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Views;

public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;
    private readonly ClipboardWatcher _clipboard = new();
    private bool _closingStarted;
    private bool _canClose;

    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();

        DataContext = _viewModel = viewModel;

        Loaded += OnLoaded;
        Closing += OnClosing;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        _clipboard.Attach(this);
        _clipboard.TextCopied += _viewModel.OnTextCopied;

        await _viewModel.InitializeAsync();
    }

    //the window stays open (showing progress) while checks, recordings and tasks are stopped
    private async void OnClosing(object? sender, CancelEventArgs e)
    {
        if (_canClose)
        {
            return;
        }

        e.Cancel = true;

        if (_closingStarted)
        {
            return;
        }

        _closingStarted = true;
        _clipboard.Dispose();

        try
        {
            //every step of the shutdown is bounded already - this is the last line of defence
            await Task.WhenAny(_viewModel.ShutdownAsync(), Task.Delay(ShutdownLimit));
        }
        finally
        {
            _canClose = true;

            //the shutdown may finish before this handler returns, and a window can't be closed from
            //inside its own Closing event - so the final close is posted
            _ = Dispatcher.BeginInvoke(Close, DispatcherPriority.Background);
        }
    }

    private static readonly TimeSpan ShutdownLimit = TimeSpan.FromSeconds(45);

    private void Nav_Checked(object sender, RoutedEventArgs e)
    {
        if (sender is not RadioButton { Tag: string page } || RoomsPage == null)
        {
            return;
        }

        RoomsPage.Visibility = Visible(page == "Rooms");
        TasksPage.Visibility = Visible(page == "Tasks");
        LogPage.Visibility = Visible(page == "Log");
        BrowserPage.Visibility = Visible(page == "Browser");
        SettingsPage.Visibility = Visible(page == "Settings");
        AboutPage.Visibility = Visible(page == "About");

        if (page == "Browser")
        {
            BrowserPage.EnsureInitialized();
        }
    }

    private static Visibility Visible(bool visible) => visible ? Visibility.Visible : Visibility.Collapsed;
}
