using System.IO;

namespace ChatRoomRecorder.Wpf.Services;

//the app keeps its own data, apart from the classic app's, so both can be used side by side
public static class AppPaths
{
    public static string DataDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChatRoomRecorderWpf");

    public static string DatabasePath => Path.Combine(DataDirectory, "ChatRoomRecorder.db");

    public static string ThumbnailsDirectory => Path.Combine(DataDirectory, "Thumbnails");

    public static string CrashLogPath => Path.Combine(DataDirectory, "errors.log");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(DataDirectory);
        Directory.CreateDirectory(ThumbnailsDirectory);
    }
}
