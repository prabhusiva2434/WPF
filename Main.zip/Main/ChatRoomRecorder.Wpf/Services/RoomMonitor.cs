using System.Collections.Concurrent;
using ChatRoomRecorder.Wpf.Models;
using ChatRoomRecorder.Wpf.Services.Sites;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Services;

//checks the rooms and starts / stops their recordings. everything runs on the thread pool: a one
//second tick hands due rooms to independent tasks (limited per website), every network call and
//process has a timeout, and results are posted to the ui - nothing here can freeze the window
public sealed class RoomMonitor
{
    private static readonly TimeSpan ProbeTimeout = TimeSpan.FromSeconds(90);
    private const int MinimumIntervalSeconds = 10;

    private readonly ConcurrentDictionary<RoomViewModel, DateTime> _rooms = new();
    private readonly ConcurrentDictionary<RoomViewModel, byte> _forced = new();
    private readonly ConcurrentDictionary<Task, byte> _running = new();
    private readonly int[] _inFlight = new int[Enum.GetValues<ChatRoomWebsite>().Length];
    private readonly Dictionary<ChatRoomWebsite, ISiteProbe> _probes = SiteProbe.All.ToDictionary(probe => probe.Website);
    private readonly CancellationTokenSource _stopping = new();
    private readonly AppSettings _settings;
    private readonly Database _database;
    private readonly LogService _log;
    private Task? _loop;

    public RoomMonitor(AppSettings settings, Database database, LogService log)
    {
        _settings = settings;
        _database = database;
        _log = log;
    }

    public int ActiveChecks => _inFlight.Sum();

    public void Start() => _loop ??= Task.Run(() => LoopAsync(_stopping.Token));

    public void Add(RoomViewModel room) => _rooms.TryAdd(room, room.LastUpdated);

    //checks the room on the next tick, skipping the interval and the random delay
    public void CheckNow(RoomViewModel room) => _forced.TryAdd(room, 0);

    public async Task RemoveAsync(RoomViewModel room)
    {
        _rooms.TryRemove(room, out _);
        _forced.TryRemove(room, out _);

        //take the room over from a check that may still be running, then stop its recording
        for (int attempt = 0; attempt < 300 && !room.TryBeginCheck(); attempt++)
        {
            await Task.Delay(200).ConfigureAwait(false);
        }

        try
        {
            await StopRecordingAsync(room, "the room has been removed").ConfigureAwait(false);
        }
        finally
        {
            room.EndCheck();
        }
    }

    //stops checking, waits a bounded time for running checks, then stops every recording
    public async Task StopAsync(TimeSpan timeout)
    {
        _stopping.Cancel();

        try
        {
            if (_loop != null)
            {
                await _loop.ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
            //expected
        }

        await Task.WhenAny(Task.WhenAll(_running.Keys), Task.Delay(timeout)).ConfigureAwait(false);

        await Task.WhenAll(_rooms.Keys
            .Select(room => room.Recording)
            .OfType<RecordingSession>()
            .Select(session => session.StopAsync())).ConfigureAwait(false);
    }

    private async Task LoopAsync(CancellationToken cancellationToken)
    {
        using PeriodicTimer timer = new(TimeSpan.FromSeconds(1));

        while (await timer.WaitForNextTickAsync(cancellationToken).ConfigureAwait(false))
        {
            try
            {
                Dispatch(cancellationToken);
            }
            catch (Exception exception)
            {
                _log.Error("monitor", $"{exception.GetType().Name}: {exception.Message}");
            }
        }
    }

    private void Dispatch(CancellationToken cancellationToken)
    {
        DateTime now = DateTime.Now;
        TimeSpan interval = TimeSpan.FromSeconds(Math.Max(MinimumIntervalSeconds, _settings.UpdateInterval));

        IEnumerable<RoomViewModel> due = _rooms
            .Where(pair => !pair.Key.IsCheckRunning && IsDue(pair.Key, pair.Value, now, interval))
            .OrderBy(pair => pair.Value)
            .Select(pair => pair.Key);

        foreach (RoomViewModel room in due)
        {
            //turning a room off only stops things locally, so it doesn't count against the website's limit
            bool counts = room.Action != ChatRoomAction.None;
            int site = (int)room.Website;

            if (counts && Volatile.Read(ref _inFlight[site]) >= _settings.ConcurrentUpdates(room.Website))
            {
                continue;
            }

            if (!room.TryBeginCheck())
            {
                continue;
            }

            if (counts)
            {
                Interlocked.Increment(ref _inFlight[site]);
            }

            Task task = RunCheckAsync(room, counts, cancellationToken);
            _running.TryAdd(task, 0);
            task.ContinueWith(completed => _running.TryRemove(completed, out _), TaskScheduler.Default);
        }
    }

    private bool IsDue(RoomViewModel room, DateTime lastChecked, DateTime now, TimeSpan interval)
    {
        if (_forced.ContainsKey(room))
        {
            return true;
        }

        if (room.Action == ChatRoomAction.None)
        {
            return room.Recording != null || room.Status != ChatRoomStatus.Unknown;
        }

        //a recording that died is restarted right away instead of waiting for the next interval
        if (room.Recording?.HasExited == true)
        {
            return true;
        }

        return now - lastChecked >= interval;
    }

    private async Task RunCheckAsync(RoomViewModel room, bool counted, CancellationToken cancellationToken)
    {
        bool forced = _forced.TryRemove(room, out _);
        DateTime started = DateTime.Now;

        if (_rooms.ContainsKey(room))
        {
            _rooms[room] = started;
        }

        Ui.Post(() =>
        {
            room.IsChecking = true;
            room.LastUpdated = started;
        });

        try
        {
            await CheckAsync(room, forced, started, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            //shutting down
        }
        catch (Exception exception)
        {
            _log.Room(room.Website, room.Name, LogLevel.Error, $"{exception.GetType().Name}: {exception.Message}");

            Ui.Post(() =>
            {
                room.Status = ChatRoomStatus.Error;
                room.LastMessage = exception.Message;
            });
        }
        finally
        {
            try
            {
                if (!_rooms.ContainsKey(room))
                {
                    await StopRecordingAsync(room, "the room has been removed").ConfigureAwait(false);
                }
            }
            finally
            {
                room.EndCheck();

                if (counted)
                {
                    Interlocked.Decrement(ref _inFlight[(int)room.Website]);
                }

                Ui.Post(() => room.IsChecking = false);
            }
        }
    }

    private async Task CheckAsync(RoomViewModel room, bool forced, DateTime now, CancellationToken cancellationToken)
    {
        ChatRoomAction action = room.Action;
        RecordingSession? recording = room.Recording;

        //recording and still wanted: leave it alone as long as the file keeps growing
        if (recording != null && action == ChatRoomAction.Record && !forced && recording.IsHealthy())
        {
            long size = recording.CurrentSize;

            Ui.Post(() =>
            {
                room.Status = ChatRoomStatus.Record;
                room.RecordingSize = size;
                room.LastSeen = now;
            });

            Persist(room, action, now, now);

            return;
        }

        if (recording != null)
        {
            string reason =
                action != ChatRoomAction.Record ? "recording isn't wanted anymore" :
                recording.HasExited ? "the recording processes exited" :
                forced ? "restarting the recording on request" :
                "the recording stalled (the file stopped growing)";

            await StopRecordingAsync(room, reason).ConfigureAwait(false);
        }

        if (action == ChatRoomAction.None)
        {
            Ui.Post(() =>
            {
                room.Status = ChatRoomStatus.Unknown;
                room.PlaylistUrl = string.Empty;
                room.Resolutions = string.Empty;
                room.LastMessage = string.Empty;
            });

            return;
        }

        //spreads the requests out, so a website doesn't see a burst from one address
        if (!forced && _settings.UpdateDelay > 0)
        {
            await Task.Delay(Random.Shared.Next(0, _settings.UpdateDelay * 1000), cancellationToken).ConfigureAwait(false);
        }

        ProbeContext context = new(room.Website, room.Name, room.PreferredResolution, room.SiteCache, _log);
        ProbeResult result;

        using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
        {
            timeout.CancelAfter(ProbeTimeout);

            try
            {
                result = await _probes[room.Website].ProbeAsync(context, timeout.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                context.Error($"the check didn't finish within {ProbeTimeout.TotalSeconds:0} seconds");
                result = ProbeResult.Error;
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                context.Error($"{exception.GetType().Name}: {exception.Message}");
                result = ProbeResult.Error;
            }
        }

        room.SiteCache = context.Cache;

        ChatRoomStatus status = result.Status;
        string message = status == ChatRoomStatus.Error ? context.LastError ?? "the check failed - see the log" : string.Empty;
        RecordingSession? started = null;

        //the action is read again - it may have been changed while the website was answering
        if (status == ChatRoomStatus.Public && room.Action == ChatRoomAction.Record && result.Target != null && _rooms.ContainsKey(room))
        {
            try
            {
                started = RecordingSession.Start(room.Website, room.Name, result.Target, _settings.CreateRecordingOptions(), _log);
                room.Recording = started;
                status = ChatRoomStatus.Record;
            }
            catch (Exception exception)
            {
                _log.Room(room.Website, room.Name, LogLevel.Error, $"the recording couldn't start - {exception.Message}");
                status = ChatRoomStatus.Error;
                message = exception.Message;
            }
        }

        bool seen = status is not (ChatRoomStatus.Offline or ChatRoomStatus.Error or ChatRoomStatus.Unknown);
        DateTime lastSeen = seen ? now : room.LastSeen;

        Ui.Post(() =>
        {
            room.Status = status;
            room.PlaylistUrl = result.PlaylistUrl;
            room.Resolutions = string.Join(", ", result.Resolutions);
            room.LastSeen = lastSeen;
            room.LastMessage = message;

            if (started != null)
            {
                room.RecordingFile = started.FileName;
                room.RecordingStarted = started.StartedAt;
                room.RecordingSize = 0;
            }
        });

        Persist(room, action, now, lastSeen);
    }

    private async Task StopRecordingAsync(RoomViewModel room, string reason)
    {
        RecordingSession? recording = room.Recording;

        if (recording == null)
        {
            return;
        }

        room.Recording = null;
        _log.Room(room.Website, room.Name, LogLevel.Info, $"stopping the recording - {reason}");

        await recording.StopAsync().ConfigureAwait(false);

        Ui.Post(() =>
        {
            room.RecordingFile = null;
            room.RecordingStarted = null;
            room.RecordingSize = 0;
        });
    }

    private void Persist(RoomViewModel room, ChatRoomAction action, DateTime updated, DateTime seen)
    {
        if (room.Id > 0 && _rooms.ContainsKey(room))
        {
            _ = _database.UpdateRoomAsync(room.Id, action, room.PreferredResolution, updated, seen)
                .ContinueWith(task => _ = task.Exception, TaskContinuationOptions.OnlyOnFaulted);
        }
    }
}
