using System.IO;

namespace ChatRoomRecorder.Wpf.Services;

public sealed record HttpResult(int StatusCode, string Body, string Error)
{
    public bool IsSuccess => StatusCode is >= 200 and < 300;
}

//the websites sit behind cloudflare, which fingerprints the client: every .net http stack gets a
//challenge page on the api paths, while windows' own curl with a browser user agent gets through.
//so all api requests are made with curl, asynchronously and with a hard timeout.
public static class CurlClient
{
    //plain desktop chrome user agent - bump the version from time to time to keep it current
    public const string UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

    public static string CurlPath { get; } = Path.Combine(Environment.SystemDirectory, "curl.exe");

    public static async Task<HttpResult> SendAsync(
        string url,
        CancellationToken cancellationToken,
        IEnumerable<string>? headers = null,
        string? postData = null,
        int timeoutSeconds = 20)
    {
        if (!File.Exists(CurlPath))
        {
            return new HttpResult(0, string.Empty, $"{CurlPath} isn't there - the websites can't be polled without it");
        }

        List<string> arguments = new()
        {
            "-s", "-S", "-L",
            "--max-time", timeoutSeconds.ToString(),
            "-A", UserAgent,
            "-w", "\\n%{http_code}"
        };

        foreach (string header in headers ?? Enumerable.Empty<string>())
        {
            arguments.Add("-H");
            arguments.Add(header);
        }

        if (postData != null)
        {
            arguments.Add("-X");
            arguments.Add("POST");
            arguments.Add("--data");
            arguments.Add(postData);
        }

        arguments.Add(url);

        //curl enforces --max-time itself, the process timeout is only a safety net
        ProcessResult result = await ProcessRunner.RunAsync(CurlPath, arguments, TimeSpan.FromSeconds(timeoutSeconds + 10), cancellationToken).ConfigureAwait(false);

        if (result.TimedOut)
        {
            return new HttpResult(0, string.Empty, "curl didn't finish in time");
        }

        //curl writes the body and then the status code on a line of its own
        string output = result.StandardOutput;
        int separator = output.LastIndexOf('\n');
        string body = separator >= 0 ? output[..separator].TrimEnd() : string.Empty;

        if (!int.TryParse((separator >= 0 ? output[(separator + 1)..] : output).Trim(), out int statusCode))
        {
            statusCode = 0;
        }

        return new HttpResult(statusCode, body, result.StandardError.Trim());
    }
}
