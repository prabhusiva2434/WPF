using System.Collections.Concurrent;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services;

public enum LogLevel
{
    Info,
    Warning,
    Error
}

public sealed record LogEntry(DateTime Time, LogLevel Level, string Source, string Message)
{
    public override string ToString() => $"{Time:yyyy/MM/dd HH:mm:ss.fff} - {Level.ToString().ToLowerInvariant()} - {Source} - {Message}";
}

//thread safe sink for log messages. background work only enqueues, the ui drains the queue in
//batches on a timer, so logging never touches the ui thread directly
public sealed class LogService
{
    private readonly ConcurrentQueue<LogEntry> _pending = new();

    public void Info(string source, string message) => Add(LogLevel.Info, source, message);

    public void Warning(string source, string message) => Add(LogLevel.Warning, source, message);

    public void Error(string source, string message) => Add(LogLevel.Error, source, message);

    public void Room(ChatRoomWebsite website, string name, LogLevel level, string message) =>
        Add(level, $"{website.ToString().ToLowerInvariant()} - {name}", message);

    public List<LogEntry> Drain(int max)
    {
        List<LogEntry> entries = new();

        while (entries.Count < max && _pending.TryDequeue(out LogEntry? entry))
        {
            entries.Add(entry);
        }

        return entries;
    }

    private void Add(LogLevel level, string source, string message) =>
        _pending.Enqueue(new LogEntry(DateTime.Now, level, source, message));
}
