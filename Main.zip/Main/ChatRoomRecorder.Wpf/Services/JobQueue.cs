using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using ChatRoomRecorder.Wpf.ViewModels;

namespace ChatRoomRecorder.Wpf.Services;

//ffmpeg jobs (merge, extract, convert, thumbnails) run in the background with progress and cancel,
//instead of a modal window that blocks the app until the process ends
public sealed class JobQueue
{
    private readonly SemaphoreSlim _slots = new(2, 2);
    private readonly LogService _log;

    public JobQueue(LogService log)
    {
        _log = log;
    }

    //ui thread only
    public ObservableCollection<JobViewModel> Jobs { get; } = new();

    public JobViewModel Enqueue(string title, string ffmpegPath, IReadOnlyList<string> arguments, string? outputPath, string? temporaryFile = null)
    {
        JobViewModel job = new(title, outputPath);
        Jobs.Insert(0, job);

        _ = Task.Run(() => RunAsync(job, ffmpegPath, arguments, temporaryFile));

        return job;
    }

    public void ClearFinished()
    {
        foreach (JobViewModel job in Jobs.Where(job => !job.IsActive).ToList())
        {
            Jobs.Remove(job);
        }
    }

    private async Task RunAsync(JobViewModel job, string ffmpegPath, IReadOnlyList<string> arguments, string? temporaryFile)
    {
        bool success = false;

        try
        {
            await _slots.WaitAsync(job.CancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            Ui.Post(() => job.State = JobState.Cancelled);
            job.Complete(false);
            DeleteQuietly(temporaryFile);

            return;
        }

        try
        {
            if (!File.Exists(ffmpegPath))
            {
                throw new FileNotFoundException($"ffmpeg isn't there: {ffmpegPath}");
            }

            Ui.Post(() => job.State = JobState.Running);

            //-progress writes machine readable progress to stdout, the input duration comes from stderr
            ProcessStartInfo psi = ProcessRunner.CreateStartInfo(ffmpegPath,
                new[] { "-hide_banner", "-nostdin", "-nostats", "-progress", "pipe:1" }.Concat(arguments));
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            _log.Info("tasks", $"{job.Title} - {ProcessRunner.Describe(psi)}");

            using Process process = new() { StartInfo = psi, EnableRaisingEvents = true };
            double duration = 0;
            Queue<string> lastErrors = new();

            process.ErrorDataReceived += (_, e) =>
            {
                if (e.Data == null)
                {
                    return;
                }

                Match match = Regex.Match(e.Data, @"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)");

                if (duration == 0 && match.Success)
                {
                    duration = int.Parse(match.Groups[1].Value) * 3600 + int.Parse(match.Groups[2].Value) * 60 +
                        double.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture);
                }

                lock (lastErrors)
                {
                    lastErrors.Enqueue(e.Data);

                    while (lastErrors.Count > 5)
                    {
                        lastErrors.Dequeue();
                    }
                }
            };

            process.OutputDataReceived += (_, e) =>
            {
                if (e.Data == null || !e.Data.StartsWith("out_time_us=", StringComparison.Ordinal) || duration <= 0)
                {
                    return;
                }

                if (long.TryParse(e.Data["out_time_us=".Length..], out long microseconds))
                {
                    double progress = Math.Clamp(microseconds / 1_000_000d / duration, 0, 1);

                    Ui.Post(() =>
                    {
                        job.IsIndeterminate = false;
                        job.Progress = progress;
                        job.Detail = $"{progress:P0}";
                    });
                }
            };

            process.Start();
            process.BeginErrorReadLine();
            process.BeginOutputReadLine();

            try
            {
                await process.WaitForExitAsync(job.CancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                ProcessRunner.Kill(process);
                await process.WaitForExitAsync(CancellationToken.None).WaitAsync(TimeSpan.FromSeconds(5)).ConfigureAwait(false);
                DeleteQuietly(job.OutputPath);

                Ui.Post(() =>
                {
                    job.State = JobState.Cancelled;
                    job.Detail = "cancelled";
                });

                return;
            }

            success = process.ExitCode == 0;

            string errors;

            lock (lastErrors)
            {
                errors = string.Join(" | ", lastErrors);
            }

            if (!success)
            {
                _log.Error("tasks", $"{job.Title} failed with exit code {process.ExitCode} - {errors}");
            }

            Ui.Post(() =>
            {
                job.State = success ? JobState.Completed : JobState.Failed;
                job.IsIndeterminate = false;
                job.Progress = success ? 1 : job.Progress;
                job.Detail = success ? "done" : $"ffmpeg exit code {process.ExitCode} - {errors}";
            });
        }
        catch (Exception exception)
        {
            _log.Error("tasks", $"{job.Title} - {exception.Message}");

            Ui.Post(() =>
            {
                job.State = JobState.Failed;
                job.IsIndeterminate = false;
                job.Detail = exception.Message;
            });
        }
        finally
        {
            _slots.Release();
            DeleteQuietly(temporaryFile);
            job.Complete(success);
        }
    }

    private static void DeleteQuietly(string? path)
    {
        try
        {
            if (path != null && File.Exists(path))
            {
                File.Delete(path);
            }
        }
        catch
        {
            //best effort
        }
    }
}
