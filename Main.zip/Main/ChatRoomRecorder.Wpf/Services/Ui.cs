using System.Windows;
using System.Windows.Threading;

namespace ChatRoomRecorder.Wpf.Services;

//background work never blocks on the ui thread: state changes are posted and the caller moves on
public static class Ui
{
    public static void Post(Action action, DispatcherPriority priority = DispatcherPriority.Background)
    {
        Dispatcher? dispatcher = Application.Current?.Dispatcher;

        if (dispatcher == null || dispatcher.CheckAccess())
        {
            action();
        }
        else if (!dispatcher.HasShutdownStarted)
        {
            dispatcher.BeginInvoke(action, priority);
        }
    }

    public static Task InvokeAsync(Action action)
    {
        Dispatcher? dispatcher = Application.Current?.Dispatcher;

        if (dispatcher == null || dispatcher.CheckAccess())
        {
            action();

            return Task.CompletedTask;
        }

        return dispatcher.HasShutdownStarted ? Task.CompletedTask : dispatcher.InvokeAsync(action).Task;
    }
}
