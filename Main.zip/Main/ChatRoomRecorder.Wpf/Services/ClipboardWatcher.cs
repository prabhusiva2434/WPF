using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Threading;

namespace ChatRoomRecorder.Wpf.Services;

//raises TextCopied with the clipboard text whenever something is copied in any application
public sealed class ClipboardWatcher : IDisposable
{
    private const int WM_CLIPBOARDUPDATE = 0x031D;
    private const int ClipboardLengthLimit = 65536;

    private HwndSource? _source;

    public event Action<string>? TextCopied;

    public void Attach(Window window)
    {
        IntPtr handle = new WindowInteropHelper(window).EnsureHandle();
        _source = HwndSource.FromHwnd(handle);
        _source.AddHook(WndProc);
        AddClipboardFormatListener(handle);
    }

    public void Dispose()
    {
        if (_source != null)
        {
            RemoveClipboardFormatListener(_source.Handle);
            _source.RemoveHook(WndProc);
            _source = null;
        }
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WM_CLIPBOARDUPDATE)
        {
            //the copying application may still hold the clipboard - read it a moment later, outside the hook
            Dispatcher.CurrentDispatcher.BeginInvoke(ReadClipboard, DispatcherPriority.Background);
        }

        return IntPtr.Zero;
    }

    private void ReadClipboard()
    {
        string text;

        try
        {
            text = Clipboard.ContainsText() ? Clipboard.GetText() : string.Empty;
        }
        catch (Exception)
        {
            //locked by another application
            return;
        }

        if (text.Length > 0 && text.Length <= ClipboardLengthLimit)
        {
            TextCopied?.Invoke(text);
        }
    }

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool AddClipboardFormatListener(IntPtr hwnd);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RemoveClipboardFormatListener(IntPtr hwnd);
}
