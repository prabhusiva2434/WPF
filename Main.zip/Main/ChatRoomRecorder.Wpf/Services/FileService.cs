using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services;

public sealed record RecordingFileInfo(string FullName, string Name, long Length, DateTime LastWriteTime, ChatRoomWebsite Website, string Room)
{
    public string Directory => Path.GetDirectoryName(FullName) ?? string.Empty;
}

//all file system work runs on the thread pool and returns plain data to the ui
public static class FileService
{
    public static Task<List<RecordingFileInfo>> ListRecordingsAsync(string outputDirectory, IReadOnlyList<(ChatRoomWebsite Website, string Name)> rooms, CancellationToken cancellationToken) =>
        Task.Run(() =>
        {
            List<RecordingFileInfo> files = new();

            foreach ((ChatRoomWebsite website, string name) in rooms)
            {
                cancellationToken.ThrowIfCancellationRequested();

                DirectoryInfo directory = new(Path.Combine(outputDirectory, $"{website} {name}".ToLowerInvariant()));

                if (!directory.Exists)
                {
                    continue;
                }

                try
                {
                    foreach (FileInfo file in directory.EnumerateFiles($"{website} {name} *.ts".ToLowerInvariant()))
                    {
                        files.Add(new RecordingFileInfo(file.FullName, file.Name, file.Length, file.LastWriteTime, website, name));
                    }
                }
                catch (IOException)
                {
                    //the directory went away while listing
                }
                catch (UnauthorizedAccessException)
                {
                    //not ours to read
                }
            }

            return files.OrderByDescending(file => file.LastWriteTime).ToList();
        }, cancellationToken);

    //recordings of old versions were written straight into the output directory - move them into
    //the per-room directories, like the classic app does on startup
    public static Task MoveLooseRecordingsAsync(string outputDirectory, LogService log) => Task.Run(() =>
    {
        try
        {
            if (!Directory.Exists(outputDirectory))
            {
                return;
            }

            foreach (FileInfo file in new DirectoryInfo(outputDirectory).EnumerateFiles())
            {
                Match match = Regex.Match(file.Name, "^([^ ]+ [^ ]+) (.*.ts)$");

                if (match.Success)
                {
                    string directory = Path.Combine(outputDirectory, match.Groups[1].Value);
                    Directory.CreateDirectory(directory);
                    file.MoveTo(Path.Combine(directory, file.Name));
                }
            }
        }
        catch (Exception exception)
        {
            log.Warning("files", $"couldn't tidy up the output directory - {exception.Message}");
        }
    });

    public static string ThumbnailPath(ChatRoomWebsite website, string name) =>
        Path.Combine(AppPaths.ThumbnailsDirectory, $"{website} {name}.jpg");

    //grabs a frame of a recording as the room's thumbnail (time: hh:mm:ss.fff into the file)
    public static async Task<bool> CreateThumbnailAsync(string ffmpegPath, string sourceFile, string thumbnailPath, string time, CancellationToken cancellationToken)
    {
        if (!File.Exists(ffmpegPath) || !File.Exists(sourceFile))
        {
            return false;
        }

        Directory.CreateDirectory(Path.GetDirectoryName(thumbnailPath)!);

        ProcessResult result = await ProcessRunner.RunAsync(ffmpegPath,
            new[] { "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", time, "-i", sourceFile, "-frames:v", "1", "-update", "1", "-q:v", "1", "-vf", "scale=320:-1", "-y", thumbnailPath },
            TimeSpan.FromSeconds(60), cancellationToken).ConfigureAwait(false);

        return !result.TimedOut && result.ExitCode == 0 && File.Exists(thumbnailPath);
    }

    //loaded fully into memory and frozen, so the file isn't locked and the image can cross threads
    public static Task<BitmapImage?> LoadImageAsync(string path) => Task.Run(() =>
    {
        try
        {
            if (!File.Exists(path))
            {
                return null;
            }

            byte[] bytes = File.ReadAllBytes(path);
            BitmapImage image = new();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = new MemoryStream(bytes);
            image.EndInit();
            image.Freeze();

            return image;
        }
        catch
        {
            return (BitmapImage?)null;
        }
    });

    public static Task<int> ImportThumbnailsAsync(string classicThumbnailsDirectory) => Task.Run(() =>
    {
        if (!Directory.Exists(classicThumbnailsDirectory))
        {
            return 0;
        }

        Directory.CreateDirectory(AppPaths.ThumbnailsDirectory);
        int copied = 0;

        foreach (string file in Directory.EnumerateFiles(classicThumbnailsDirectory, "*.jpg"))
        {
            string target = Path.Combine(AppPaths.ThumbnailsDirectory, Path.GetFileName(file));

            if (!File.Exists(target))
            {
                File.Copy(file, target);
                copied++;
            }
        }

        return copied;
    });

    public static Task DeleteFilesAsync(IEnumerable<string> paths) => Task.Run(() =>
    {
        List<string> failed = new();

        foreach (string path in paths)
        {
            try
            {
                File.Delete(path);
            }
            catch
            {
                failed.Add(Path.GetFileName(path));
            }
        }

        if (failed.Count > 0)
        {
            throw new IOException($"these files couldn't be removed (they may still be recording or open): {string.Join(", ", failed)}");
        }
    });

    public static string FormatSize(long bytes)
    {
        string[] units = { "B", "KB", "MB", "GB", "TB" };
        double size = bytes;
        int unit = 0;

        while (size >= 1024 && unit < units.Length - 1)
        {
            size /= 1024;
            unit++;
        }

        return unit == 0 ? $"{bytes} B" : $"{size:0.##} {units[unit]}";
    }
}
