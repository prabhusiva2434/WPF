using System.IO;
using System.Threading.Channels;
using ChatRoomRecorder.Wpf.Models;
using Microsoft.Data.Sqlite;

namespace ChatRoomRecorder.Wpf.Services;

public sealed record StoredCategory(int Id, string Name, int ParentId);

public sealed record StoredRoom(int Id, string Url, ChatRoomAction Action, Resolution Resolution, DateTime Updated, DateTime Seen, int CategoryId);

public sealed record StoredData(AppSettings Settings, List<StoredCategory> Categories, List<StoredRoom> Rooms);

//the same schema as the classic app (so its database can be imported as is), but every statement is
//parameterized and runs on one background worker - the ui thread never waits for the disk
public sealed class Database : IAsyncDisposable
{
    public const int RootCategoryId = 1;
    public const string RootCategoryName = "All chat rooms";

    private readonly Channel<Func<SqliteConnection, Task>> _queue =
        Channel.CreateUnbounded<Func<SqliteConnection, Task>>(new UnboundedChannelOptions { SingleReader = true });

    private readonly SqliteConnection _connection;
    private readonly Task _worker;
    private readonly LogService _log;

    private Database(SqliteConnection connection, LogService log)
    {
        _connection = connection;
        _log = log;
        _worker = Task.Run(ProcessQueueAsync);
    }

    public static async Task<Database> OpenAsync(string path, LogService log)
    {
        SqliteConnection connection = await Task.Run(async () =>
        {
            SqliteConnection c = new($"Data Source={path}");
            await c.OpenAsync();
            await ExecuteAsync(c, "pragma foreign_keys = 1; pragma journal_mode = wal;");
            await MigrateAsync(c);

            return c;
        });

        return new Database(connection, log);
    }

    //copies the classic app's database into this one, using sqlite's online backup - the classic file is
    //opened read-only, so the classic app keeps working even if it's running
    public static async Task ImportClassicAsync(string classicPath, string targetPath)
    {
        await Task.Run(() =>
        {
            SqliteConnection.ClearAllPools();

            using SqliteConnection source = new($"Data Source={classicPath};Mode=ReadOnly");
            using SqliteConnection target = new($"Data Source={targetPath}");
            source.Open();
            target.Open();
            source.BackupDatabase(target);
        });
    }

    public Task<StoredData> LoadAsync() => EnqueueAsync(async c =>
    {
        AppSettings settings = new();

        await using (SqliteDataReader reader = await Command(c, "select * from Settings limit 1;").ExecuteReaderAsync())
        {
            if (await reader.ReadAsync())
            {
                ReadSettings(reader, settings);
            }
        }

        List<StoredCategory> categories = new();

        await using (SqliteDataReader reader = await Command(c, "select ID, Name, Category from Categories;").ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                categories.Add(new StoredCategory(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    reader.IsDBNull(2) ? 0 : reader.GetInt32(2)));
            }
        }

        List<StoredRoom> rooms = new();

        await using (SqliteDataReader reader = await Command(c, "select ID, URL, Action, Resolution, Updated, Seen, Category from ChatRooms;").ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                rooms.Add(new StoredRoom(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    (ChatRoomAction)(reader.IsDBNull(2) ? 0 : reader.GetInt32(2)),
                    reader.IsDBNull(3) ? Resolution.MaxValue : Resolution.FromInt32(reader.GetInt32(3)),
                    Ticks(reader, 4),
                    Ticks(reader, 5),
                    reader.IsDBNull(6) ? RootCategoryId : reader.GetInt32(6)));
            }
        }

        return new StoredData(settings, categories, rooms);
    });

    public Task SaveSettingsAsync(AppSettings s)
    {
        //the values are captured now, on the caller's thread
        (string, object)[] values =
        {
            ("OutputDirectory", s.OutputDirectory),
            ("FFmpegPath", s.FFmpegPath),
            ("StreamlinkPath", s.StreamlinkPath),
            ("ChaturbateConcurrentUpdates", s.ChaturbateConcurrentUpdates),
            ("BongaCamsConcurrentUpdates", s.BongaCamsConcurrentUpdates),
            ("StripchatConcurrentUpdates", s.StripchatConcurrentUpdates),
            ("Flirt4FreeConcurrentUpdates", s.Flirt4FreeConcurrentUpdates),
            ("CamSodaConcurrentUpdates", s.CamSodaConcurrentUpdates),
            ("Cam4ConcurrentUpdates", s.Cam4ConcurrentUpdates),
            ("UpdateDelay", s.UpdateDelay),
            ("UpdateInterval", s.UpdateInterval),
            ("DefaultAction", (int)s.DefaultAction),
            ("DefaultResolution", s.DefaultResolution.ToInt32()),
            ("VideoEncoder", (int)s.VideoEncoder),
            ("VideoQuality", s.VideoQuality),
            ("VideoPreset", (int)s.VideoPreset),
            ("AudioBitrate", s.AudioBitrate),
            ("MaxVideoHeight", s.MaxVideoHeight),
            ("AddFromClipboard", s.AddFromClipboard ? 1 : 0),
            ("LogSize", s.LogSize)
        };

        return EnqueueAsync(async c =>
        {
            string columns = string.Join(", ", values.Select(v => v.Item1));
            string parameters = string.Join(", ", values.Select(v => "$" + v.Item1));
            SqliteCommand command = Command(c, $"delete from Settings; insert into Settings ({columns}) values ({parameters});");

            foreach ((string name, object value) in values)
            {
                command.Parameters.AddWithValue("$" + name, value);
            }

            await command.ExecuteNonQueryAsync();

            return true;
        });
    }

    public Task<int> InsertRoomAsync(string url, ChatRoomAction action, Resolution resolution, int categoryId) => EnqueueAsync(async c =>
    {
        SqliteCommand command = Command(c,
            "insert into ChatRooms (URL, Action, Resolution, Updated, Seen, Category) values ($url, $action, $resolution, 0, 0, $category); select last_insert_rowid();",
            ("$url", url), ("$action", (int)action), ("$resolution", resolution.ToInt32()), ("$category", categoryId));

        return Convert.ToInt32(await command.ExecuteScalarAsync());
    });

    public Task UpdateRoomAsync(int id, ChatRoomAction action, Resolution resolution, DateTime updated, DateTime seen) => ExecuteQueuedAsync(
        "update ChatRooms set Action = $action, Resolution = $resolution, Updated = $updated, Seen = $seen where ID = $id;",
        ("$action", (int)action), ("$resolution", resolution.ToInt32()), ("$updated", updated.Ticks), ("$seen", seen.Ticks), ("$id", id));

    public Task MoveRoomAsync(int id, int categoryId) =>
        ExecuteQueuedAsync("update ChatRooms set Category = $category where ID = $id;", ("$category", categoryId), ("$id", id));

    public Task DeleteRoomAsync(int id) =>
        ExecuteQueuedAsync("delete from ChatRooms where ID = $id;", ("$id", id));

    public Task<int> InsertCategoryAsync(string name, int parentId) => EnqueueAsync(async c =>
    {
        SqliteCommand command = Command(c,
            "insert into Categories (Name, Category) values ($name, $parent); select last_insert_rowid();",
            ("$name", name), ("$parent", parentId));

        return Convert.ToInt32(await command.ExecuteScalarAsync());
    });

    public Task RenameCategoryAsync(int id, string name) =>
        ExecuteQueuedAsync("update Categories set Name = $name where ID = $id;", ("$name", name), ("$id", id));

    public Task MoveCategoryAsync(int id, int parentId) =>
        ExecuteQueuedAsync("update Categories set Category = $parent where ID = $id;", ("$parent", parentId), ("$id", id));

    public Task DeleteCategoryAsync(int id) =>
        ExecuteQueuedAsync("delete from Categories where ID = $id;", ("$id", id));

    public async ValueTask DisposeAsync()
    {
        _queue.Writer.TryComplete();

        try
        {
            await _worker.WaitAsync(TimeSpan.FromSeconds(10));
        }
        catch
        {
            //the pending writes are lost, the database itself stays consistent
        }

        await _connection.DisposeAsync();
        SqliteConnection.ClearAllPools();
    }

    private Task ExecuteQueuedAsync(string sql, params (string Name, object Value)[] parameters) => EnqueueAsync(async c =>
    {
        await Command(c, sql, parameters).ExecuteNonQueryAsync();

        return true;
    });

    private Task<T> EnqueueAsync<T>(Func<SqliteConnection, Task<T>> operation)
    {
        TaskCompletionSource<T> completion = new(TaskCreationOptions.RunContinuationsAsynchronously);

        bool queued = _queue.Writer.TryWrite(async connection =>
        {
            try
            {
                completion.TrySetResult(await operation(connection));
            }
            catch (Exception exception)
            {
                _log.Error("database", $"{exception.GetType().Name}: {exception.Message}");
                completion.TrySetException(exception);
            }
        });

        if (!queued)
        {
            completion.TrySetCanceled();
        }

        return completion.Task;
    }

    private async Task ProcessQueueAsync()
    {
        await foreach (Func<SqliteConnection, Task> operation in _queue.Reader.ReadAllAsync())
        {
            await operation(_connection);
        }
    }

    private static SqliteCommand Command(SqliteConnection connection, string sql, params (string Name, object Value)[] parameters)
    {
        SqliteCommand command = connection.CreateCommand();
        command.CommandText = sql;

        foreach ((string name, object value) in parameters)
        {
            command.Parameters.AddWithValue(name, value);
        }

        return command;
    }

    private static async Task ExecuteAsync(SqliteConnection connection, string sql, params (string Name, object Value)[] parameters) =>
        await Command(connection, sql, parameters).ExecuteNonQueryAsync();

    private static DateTime Ticks(SqliteDataReader reader, int ordinal)
    {
        if (reader.IsDBNull(ordinal))
        {
            return DateTime.MinValue;
        }

        long ticks = reader.GetInt64(ordinal);

        return ticks > 0 && ticks <= DateTime.MaxValue.Ticks ? new DateTime(ticks) : DateTime.MinValue;
    }

    private static void ReadSettings(SqliteDataReader reader, AppSettings settings)
    {
        string? Text(string column) => Has(column) ? reader.GetString(reader.GetOrdinal(column)) : null;
        int? Number(string column) => Has(column) ? reader.GetInt32(reader.GetOrdinal(column)) : null;

        bool Has(string column)
        {
            try
            {
                return !reader.IsDBNull(reader.GetOrdinal(column));
            }
            catch (ArgumentOutOfRangeException)
            {
                return false;
            }
        }

        settings.OutputDirectory = Text("OutputDirectory") ?? settings.OutputDirectory;
        settings.FFmpegPath = Text("FFmpegPath") ?? settings.FFmpegPath;
        settings.StreamlinkPath = Text("StreamlinkPath") ?? settings.StreamlinkPath;
        settings.ChaturbateConcurrentUpdates = Number("ChaturbateConcurrentUpdates") ?? settings.ChaturbateConcurrentUpdates;
        settings.BongaCamsConcurrentUpdates = Number("BongaCamsConcurrentUpdates") ?? settings.BongaCamsConcurrentUpdates;
        settings.StripchatConcurrentUpdates = Number("StripchatConcurrentUpdates") ?? settings.StripchatConcurrentUpdates;
        settings.Flirt4FreeConcurrentUpdates = Number("Flirt4FreeConcurrentUpdates") ?? settings.Flirt4FreeConcurrentUpdates;
        settings.CamSodaConcurrentUpdates = Number("CamSodaConcurrentUpdates") ?? settings.CamSodaConcurrentUpdates;
        settings.Cam4ConcurrentUpdates = Number("Cam4ConcurrentUpdates") ?? settings.Cam4ConcurrentUpdates;
        settings.UpdateDelay = Number("UpdateDelay") ?? settings.UpdateDelay;
        settings.UpdateInterval = Number("UpdateInterval") ?? settings.UpdateInterval;
        settings.DefaultAction = (ChatRoomAction)(Number("DefaultAction") ?? (int)settings.DefaultAction);
        settings.DefaultResolution = Number("DefaultResolution") is int resolution ? Resolution.FromInt32(resolution) : settings.DefaultResolution;
        settings.VideoEncoder = (VideoEncoder)(Number("VideoEncoder") ?? (int)settings.VideoEncoder);
        settings.VideoQuality = Number("VideoQuality") ?? settings.VideoQuality;
        settings.VideoPreset = (VideoPreset)(Number("VideoPreset") ?? (int)settings.VideoPreset);
        settings.AudioBitrate = Number("AudioBitrate") ?? settings.AudioBitrate;
        settings.MaxVideoHeight = Number("MaxVideoHeight") ?? settings.MaxVideoHeight;
        settings.AddFromClipboard = (Number("AddFromClipboard") ?? (settings.AddFromClipboard ? 1 : 0)) != 0;
        settings.LogSize = Number("LogSize") ?? settings.LogSize;
    }

    //the classic app's schema history, step by step, so a database of any age ends up current
    private static async Task MigrateAsync(SqliteConnection c)
    {
        AppSettings defaults = new();

        while (true)
        {
            int version = Convert.ToInt32(await Command(c, "pragma user_version;").ExecuteScalarAsync());

            string? sql = version switch
            {
                0 => "create table Settings (OutputDirectory text, FFmpegPath text, ChaturbateConcurrentUpdates integer, BongaCamsConcurrentUpdates integer, StripchatConcurrentUpdates integer, UpdateInterval integer, DefaultAction integer, DefaultResolution integer);" +
                     "create table ChatRooms (URL text primary key, Action integer, Resolution integer, Updated integer, Seen integer);" +
                     "pragma user_version = 1;",
                1 => "alter table Settings add StreamlinkPath text; pragma user_version = 2;",
                2 => $"create table Categories (ID integer primary key autoincrement, Name text, Category integer, foreign key (Category) references Categories (ID));" +
                     $"insert into Categories (Name) values ('{RootCategoryName}');" +
                     "create temporary table temp as select URL, Action, Resolution, Updated, Seen from ChatRooms;" +
                     "drop table ChatRooms;" +
                     "create table ChatRooms (ID integer primary key autoincrement, URL text, Action integer, Resolution integer, Updated integer, Seen integer, Category integer, foreign key (Category) references Categories (ID));" +
                     "insert into ChatRooms (URL, Action, Resolution, Updated, Seen) select URL, Action, Resolution, Updated, Seen from temp;" +
                     "update ChatRooms set Category = 1;" +
                     "drop table temp;" +
                     "pragma user_version = 3;",
                3 => "alter table Settings add Flirt4FreeConcurrentUpdates integer; alter table Settings add UpdateDelay integer; pragma user_version = 4;",
                4 => "alter table Settings add CamSodaConcurrentUpdates integer; alter table Settings add LogSize integer; pragma user_version = 5;",
                5 => "alter table Settings add Cam4ConcurrentUpdates integer; pragma user_version = 6;",
                6 => $"alter table Settings add VideoEncoder integer default {(int)defaults.VideoEncoder};" +
                     $"alter table Settings add VideoQuality integer default {defaults.VideoQuality};" +
                     $"alter table Settings add VideoPreset integer default {(int)defaults.VideoPreset};" +
                     $"alter table Settings add AudioBitrate integer default {defaults.AudioBitrate};" +
                     $"alter table Settings add MaxVideoHeight integer default {defaults.MaxVideoHeight};" +
                     "pragma user_version = 7;",
                7 => $"alter table Settings add AddFromClipboard integer default {(defaults.AddFromClipboard ? 1 : 0)}; pragma user_version = 8;",
                _ => null
            };

            if (sql == null)
            {
                break;
            }

            await ExecuteAsync(c, sql);
        }

        //a database that lost its root category (it's what every other category hangs off)
        if (Convert.ToInt32(await Command(c, "select count(*) from Categories where ID = 1;").ExecuteScalarAsync()) == 0)
        {
            await ExecuteAsync(c, "insert into Categories (ID, Name) values (1, $name);", ("$name", RootCategoryName));
        }
    }
}
