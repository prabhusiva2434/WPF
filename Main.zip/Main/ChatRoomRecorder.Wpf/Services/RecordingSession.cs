using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using ChatRoomRecorder.Wpf.Models;
using ChatRoomRecorder.Wpf.Services.Sites;

namespace ChatRoomRecorder.Wpf.Services;

//one running recording of a room: the external processes, the output file and its growth
public sealed class RecordingSession
{
    private readonly List<Process> _processes;
    private long _lastSize;

    private RecordingSession(string fileName, List<Process> processes)
    {
        FileName = fileName;
        _processes = processes;
        StartedAt = DateTime.Now;
    }

    public string FileName { get; }

    public DateTime StartedAt { get; }

    public bool HasExited => _processes.Any(process =>
    {
        try
        {
            return process.HasExited;
        }
        catch
        {
            return true;
        }
    });

    public long CurrentSize
    {
        get
        {
            try
            {
                FileInfo file = new(FileName);

                return file.Exists ? file.Length : 0;
            }
            catch
            {
                return 0;
            }
        }
    }

    //the stream is healthy while every process runs and the file keeps growing between two checks
    public bool IsHealthy()
    {
        if (HasExited)
        {
            return false;
        }

        long size = CurrentSize;

        if (size > _lastSize)
        {
            _lastSize = size;

            return true;
        }

        return false;
    }

    public static RecordingSession Start(ChatRoomWebsite website, string name, RecordTarget target, RecordingOptions options, LogService log)
    {
        if (!File.Exists(options.FFmpegPath))
        {
            throw new FileNotFoundException($"ffmpeg isn't there: {options.FFmpegPath} - set its path in the settings");
        }

        if (target.Method == RecordMethod.Streamlink && !File.Exists(options.StreamlinkPath))
        {
            throw new FileNotFoundException($"streamlink isn't there: {options.StreamlinkPath} - set its path in the settings");
        }

        string directory = Path.Combine(options.OutputDirectory, $"{website} {name}".ToLowerInvariant());
        Directory.CreateDirectory(directory);

        //the same naming as the classic app, so both list each other's recordings
        string fileName = Path.Combine(directory, $"{website} {name} {DateTime.Now:yyyy-MM-dd HH-mm-ss}.ts".ToLowerInvariant());

        List<ProcessStartInfo> startInfos = new();
        List<string> output = BuildOutputArguments(options);

        if (target.Method == RecordMethod.FFmpeg)
        {
            startInfos.Add(ProcessRunner.CreateStartInfo(options.FFmpegPath,
                new[] { "-nostdin", "-analyzeduration", "16M", "-i", target.PlaylistUrl, "-map", $"0:p:{target.ProgramIndex}" }
                    .Concat(output).Append(fileName)));
        }
        else
        {
            int port = GetFreePort();

            startInfos.Add(ProcessRunner.CreateStartInfo(options.StreamlinkPath, new[]
            {
                "--player-external-http",
                "--player-external-http-continuous", "false",
                "--player-external-http-interface", "127.0.0.1",
                "--player-external-http-port", port.ToString(),
                "--default-stream", target.StreamName,
                "--stream-segment-timeout", "60",
                "--stream-timeout", "60",
                "--http-timeout", "60",
                "--hls-segment-queue-threshold", "99",
                target.PlaylistUrl
            }));

            startInfos.Add(ProcessRunner.CreateStartInfo(options.FFmpegPath,
                new[]
                {
                    "-nostdin",
                    "-reconnect", "1", "-reconnect_at_eof", "1", "-reconnect_on_network_error", "1",
                    "-reconnect_on_http_error", "1", "-reconnect_streamed", "1",
                    "-i", $"http://127.0.0.1:{port}"
                }.Concat(output).Append(fileName)));
        }

        List<Process> processes = new();

        try
        {
            foreach (ProcessStartInfo psi in startInfos)
            {
                processes.Add(Process.Start(psi) ?? throw new InvalidOperationException($"{psi.FileName} didn't start"));
                log.Room(website, name, LogLevel.Info, $"recording - {ProcessRunner.Describe(psi)}");
            }
        }
        catch
        {
            processes.ForEach(ProcessRunner.Kill);

            throw;
        }

        return new RecordingSession(fileName, processes);
    }

    //stops the processes off the calling thread and waits a bounded time for them to go away
    public async Task StopAsync()
    {
        await Task.Run(async () =>
        {
            foreach (Process process in _processes)
            {
                ProcessRunner.Kill(process);
            }

            foreach (Process process in _processes)
            {
                try
                {
                    using CancellationTokenSource timeout = new(TimeSpan.FromSeconds(5));
                    await process.WaitForExitAsync(timeout.Token);
                }
                catch
                {
                    //gave up waiting - the kill has been requested anyway
                }
                finally
                {
                    process.Dispose();
                }
            }

            //a recording that never received a byte (the stream's cdn refused, say) leaves an empty
            //file behind - there's nothing in it to keep
            try
            {
                FileInfo file = new(FileName);

                if (file.Exists && file.Length == 0)
                {
                    file.Delete();
                }
            }
            catch
            {
                //it stays then
            }
        }).ConfigureAwait(false);
    }

    private static List<string> BuildOutputArguments(RecordingOptions options)
    {
        if (options.VideoEncoder == VideoEncoder.Copy)
        {
            return new List<string> { "-c", "copy" };
        }

        List<string> arguments = new();

        if (options.MaxVideoHeight > 0)
        {
            //the height is only ever reduced, and the width is kept even to stay encoder friendly
            arguments.AddRange(new[] { "-vf", $"scale=-2:'min({options.MaxVideoHeight},ih)'" });
        }

        string quality = options.VideoQuality.ToString();

        arguments.AddRange(options.VideoEncoder switch
        {
            VideoEncoder.H264 => new[] { "-c:v", "libx264", "-preset", SoftwarePreset(options.VideoPreset), "-crf", quality },
            VideoEncoder.H265 => new[] { "-c:v", "libx265", "-preset", SoftwarePreset(options.VideoPreset), "-crf", quality },
            VideoEncoder.H264_NVENC => new[] { "-c:v", "h264_nvenc", "-preset", NvencPreset(options.VideoPreset), "-rc", "vbr", "-cq", quality, "-b:v", "0" },
            VideoEncoder.H265_NVENC => new[] { "-c:v", "hevc_nvenc", "-preset", NvencPreset(options.VideoPreset), "-rc", "vbr", "-cq", quality, "-b:v", "0" },
            VideoEncoder.H264_QSV => new[] { "-c:v", "h264_qsv", "-preset", QsvPreset(options.VideoPreset), "-global_quality", quality },
            VideoEncoder.H265_QSV => new[] { "-c:v", "hevc_qsv", "-preset", QsvPreset(options.VideoPreset), "-global_quality", quality },
            _ => Array.Empty<string>()
        });

        arguments.AddRange(options.AudioBitrate > 0
            ? new[] { "-c:a", "aac", "-b:a", $"{options.AudioBitrate}k" }
            : new[] { "-c:a", "copy" });

        return arguments;
    }

    private static string SoftwarePreset(VideoPreset preset) => preset switch
    {
        VideoPreset.UltraFast => "ultrafast",
        VideoPreset.SuperFast => "superfast",
        VideoPreset.VeryFast => "veryfast",
        VideoPreset.Faster => "faster",
        VideoPreset.Fast => "fast",
        VideoPreset.Medium => "medium",
        _ => "slow"
    };

    //p1 is the fastest and p7 the slowest nvenc preset
    private static string NvencPreset(VideoPreset preset) => $"p{(int)preset + 1}";

    //qsv doesn't support the two fastest presets
    private static string QsvPreset(VideoPreset preset) => preset switch
    {
        VideoPreset.UltraFast or VideoPreset.SuperFast or VideoPreset.VeryFast => "veryfast",
        VideoPreset.Faster => "faster",
        VideoPreset.Fast => "fast",
        VideoPreset.Medium => "medium",
        _ => "slow"
    };

    //asks the os for a free port instead of guessing one, so two recordings can't collide
    private static int GetFreePort()
    {
        using TcpListener listener = new(IPAddress.Loopback, 0);
        listener.Start();

        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }
}
