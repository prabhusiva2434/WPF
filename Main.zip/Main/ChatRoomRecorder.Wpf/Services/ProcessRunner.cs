using System.Diagnostics;
using System.Text;

namespace ChatRoomRecorder.Wpf.Services;

public sealed record ProcessResult(int ExitCode, string StandardOutput, string StandardError, bool TimedOut);

//every external process goes through here: arguments are passed as a list (no hand-made quoting),
//output is drained asynchronously and a hard timeout kills the whole process tree, so a stuck
//curl / ffmpeg can never block the caller
public static class ProcessRunner
{
    public static async Task<ProcessResult> RunAsync(string fileName, IEnumerable<string> arguments, TimeSpan timeout, CancellationToken cancellationToken)
    {
        ProcessStartInfo psi = CreateStartInfo(fileName, arguments);
        psi.RedirectStandardOutput = true;
        psi.RedirectStandardError = true;
        psi.StandardOutputEncoding = Encoding.UTF8;
        psi.StandardErrorEncoding = Encoding.UTF8;

        using Process process = new() { StartInfo = psi };
        process.Start();

        Task<string> output = process.StandardOutput.ReadToEndAsync(CancellationToken.None);
        Task<string> error = process.StandardError.ReadToEndAsync(CancellationToken.None);

        using CancellationTokenSource timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutSource.CancelAfter(timeout);

        try
        {
            await process.WaitForExitAsync(timeoutSource.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            Kill(process);

            cancellationToken.ThrowIfCancellationRequested();

            return new ProcessResult(-1, string.Empty, "timed out", true);
        }

        return new ProcessResult(process.ExitCode, await output.ConfigureAwait(false), await error.ConfigureAwait(false), false);
    }

    public static ProcessStartInfo CreateStartInfo(string fileName, IEnumerable<string> arguments)
    {
        ProcessStartInfo psi = new(fileName)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            LoadUserProfile = false
        };

        foreach (string argument in arguments)
        {
            psi.ArgumentList.Add(argument);
        }

        return psi;
    }

    public static string Describe(ProcessStartInfo psi) =>
        $"{psi.FileName} {string.Join(' ', psi.ArgumentList.Select(a => a.Contains(' ') ? $"\"{a}\"" : a))}";

    public static void Kill(Process process)
    {
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
            }
        }
        catch
        {
            //already gone
        }
    }
}
