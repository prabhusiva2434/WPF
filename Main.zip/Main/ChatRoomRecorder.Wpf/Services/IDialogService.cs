namespace ChatRoomRecorder.Wpf.Services;

public interface IDialogService
{
    bool Confirm(string title, string message);

    void ShowError(string title, string message);

    string? Prompt(string title, string label, string initialValue);

    string? PickFolder(string title);

    string? PickFile(string title, string filter);

    //returns the pasted links, one per line
    string? AskForUrls();

    //lets the user put the files in merge order, null when cancelled
    IReadOnlyList<RecordingFileInfo>? OrderForMerge(IReadOnlyList<RecordingFileInfo> files);

    (TimeSpan Start, TimeSpan End)? PickFragment(string file);

    TimeSpan? PickThumbnailPosition(string file);
}
