using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public sealed class BongaCamsProbe : SiteProbe
{
    private static readonly string[] Headers =
    {
        "Accept: application/json, text/plain, */*",
        "Content-Type: application/x-www-form-urlencoded",
        "X-Requested-With: XMLHttpRequest"
    };

    public override ChatRoomWebsite Website => ChatRoomWebsite.BongaCams;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        string? body = await GetApiAsync(context, "https://bongacams.com/tools/listing_v3.php", cancellationToken,
            Headers, "model_search[display_name]=" + Uri.EscapeDataString(context.Name));

        if (body == null)
        {
            return ProbeResult.Error;
        }

        //the search only lists live models, so a room that isn't in the answer is offline
        JsonNode? model = (JsonNode.Parse(body)?["models"] as JsonArray)?
            .FirstOrDefault(node => string.Equals(Str(node?["username"]), context.Name, StringComparison.OrdinalIgnoreCase));

        string? esid = Str(model?["esid"]);

        if (model == null || string.IsNullOrEmpty(esid))
        {
            context.Info($"status - {ChatRoomStatus.Offline}");

            return ProbeResult.Of(ChatRoomStatus.Offline);
        }

        string playlistUrl = $"https://{esid}.bcvcdn.com/hls/stream_{Str(model["username"])}/playlist.m3u8";
        (bool success, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);

        ChatRoomStatus status = success ? ChatRoomStatus.Public : ChatRoomStatus.Offline;

        context.Info($"status - {status}");

        return Finish(context, status, playlistUrl, PlaylistClient.ParseResolutions(playlist),
            index => new RecordTarget(RecordMethod.FFmpeg, playlistUrl, index, string.Empty));
    }
}
