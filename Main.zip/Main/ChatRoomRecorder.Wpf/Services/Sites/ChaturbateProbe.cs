using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public sealed class ChaturbateProbe : SiteProbe
{
    public override ChatRoomWebsite Website => ChatRoomWebsite.Chaturbate;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        string? body = await GetApiAsync(context, $"https://chaturbate.com/api/chatvideocontext/{context.Name}/", cancellationToken);

        if (body == null)
        {
            return ProbeResult.Error;
        }

        JsonNode root = JsonNode.Parse(body)!;
        string? raw = Str(root["room_status"]);

        ChatRoomStatus status = raw switch
        {
            "public" => ChatRoomStatus.Public,
            "private" or "password protected" => ChatRoomStatus.Private,
            "hidden" => ChatRoomStatus.Hidden,
            "away" => ChatRoomStatus.Away,
            "offline" => ChatRoomStatus.Offline,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status} ('{raw}')");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        string? playlistUrl = Str(root["hls_source"]);

        if (string.IsNullOrEmpty(playlistUrl))
        {
            context.Error("the room is public but the api didn't give a playlist");

            return ProbeResult.Error;
        }

        (_, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);

        return Finish(context, status, playlistUrl, PlaylistClient.ParseResolutions(playlist),
            index => new RecordTarget(RecordMethod.FFmpeg, playlistUrl, index, string.Empty));
    }
}
