using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public sealed class Cam4Probe : SiteProbe
{
    public override ChatRoomWebsite Website => ChatRoomWebsite.Cam4;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        string? body = await GetApiAsync(context,
            $"https://cam4.com/directoryCams?directoryJson=true&online=true&username={Uri.EscapeDataString(context.Name)}", cancellationToken);

        if (body == null)
        {
            return ProbeResult.Error;
        }

        JsonArray rooms = JsonNode.Parse(body) as JsonArray ?? new JsonArray();

        if (rooms.Count == 0)
        {
            context.Info($"status - {ChatRoomStatus.Offline}");

            return ProbeResult.Of(ChatRoomStatus.Offline);
        }

        JsonNode room = rooms[0]!;
        string? playlistUrl = Str(room["hlsPreviewUrl"]);

        ChatRoomStatus status = Str(room["showType"]) switch
        {
            "NORMAL" => string.IsNullOrEmpty(playlistUrl) ? ChatRoomStatus.Private : ChatRoomStatus.Public,
            "PRIVATE_SHOW" => ChatRoomStatus.Private,
            "GROUP_SHOW" => ChatRoomStatus.Group,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status}");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        (_, string playlist) = await PlaylistClient.GetAsync(playlistUrl!, cancellationToken);

        return Finish(context, status, playlistUrl!, PlaylistClient.ParseResolutions(playlist),
            index => new RecordTarget(RecordMethod.FFmpeg, playlistUrl!, index, string.Empty));
    }
}
