using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public sealed class Flirt4FreeProbe : SiteProbe
{
    public override ChatRoomWebsite Website => ChatRoomWebsite.Flirt4Free;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        string? body = await GetApiAsync(context, "https://www.flirt4free.com/?tpl=index2&model=json", cancellationToken);

        if (body == null)
        {
            return ProbeResult.Error;
        }

        //the answer is one big blob of every online model - cut out the object around the room's name
        JsonNode model = JsonNode.Parse(FindModelObject(body, context.Name) ?? "{\"room_status_char\":\"\"}")!;
        string? raw = Str(model["room_status_char"]);

        ChatRoomStatus status = raw switch
        {
            "O" => ChatRoomStatus.Public,
            "P" or "F" => ChatRoomStatus.Private,
            "" => ChatRoomStatus.Offline,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status} ('{raw}')");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        int modelId = Int(model["model_id"]) ?? throw new InvalidOperationException("the api didn't give the model id");

        (_, string streamInfo) = await PlaylistClient.GetAsync(
            $"https://www.flirt4free.com/ws/chat/get-stream-urls.php?model_id={modelId}", cancellationToken);

        string playlistUrl = "https:" + Str(JsonNode.Parse(streamInfo)?["data"]?["hls"]?[0]?["url"]);
        (_, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);

        return Finish(context, status, playlistUrl, PlaylistClient.ParseResolutions(playlist),
            index => new RecordTarget(RecordMethod.FFmpeg, playlistUrl, index, string.Empty));
    }

    private static string? FindModelObject(string text, string name)
    {
        string quoted = $"\"{name}\"";
        int position = text.IndexOf(quoted, StringComparison.Ordinal);

        if (position == -1)
        {
            return null;
        }

        int first = -1;
        int last = -1;
        int depth = 0;

        for (int i = position - 1; i >= 0 && first == -1; i--)
        {
            switch (text[i])
            {
                case '{': if (depth == 0) first = i; else depth--; break;
                case '}': depth++; break;
            }
        }

        for (int i = position + quoted.Length; i < text.Length && first != -1 && last == -1; i++)
        {
            switch (text[i])
            {
                case '}': if (depth == 0) last = i; else depth--; break;
                case '{': depth++; break;
            }
        }

        return first != -1 && last != -1 ? text.Substring(first, last - first + 1) : null;
    }
}
