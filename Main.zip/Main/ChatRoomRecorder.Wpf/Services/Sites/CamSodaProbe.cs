using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

public sealed class CamSodaProbe : SiteProbe
{
    public override ChatRoomWebsite Website => ChatRoomWebsite.CamSoda;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        string? body = await GetApiAsync(context, $"https://www.camsoda.com/api/v1/video/vtoken/{context.Name}", cancellationToken);

        if (body == null)
        {
            return ProbeResult.Error;
        }

        JsonNode root = JsonNode.Parse(body)!;
        JsonArray servers = root["edge_servers"] as JsonArray ?? new JsonArray();
        string streamName = Str(root["stream_name"]) ?? string.Empty;

        ChatRoomStatus status =
            streamName.Length == 0 ? ChatRoomStatus.Offline :
            servers.Count == 0 ? ChatRoomStatus.Private :
            ChatRoomStatus.Public;

        context.Info($"status - {status}");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        string playlistUrl = $"https://{Str(servers[0])}/{streamName}_v1/playlist.m3u8";
        (_, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);
        List<Resolution> resolutions = PlaylistClient.ParseResolutions(playlist);

        return Finish(context, status, playlistUrl, resolutions,
            index => new RecordTarget(RecordMethod.Streamlink, playlistUrl, index, $"{resolutions[index].Height}p"));
    }
}
