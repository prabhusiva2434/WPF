using System.Text.Json.Nodes;
using ChatRoomRecorder.Wpf.Models;

namespace ChatRoomRecorder.Wpf.Services.Sites;

//stripchat's api sits behind cloudflare bot management, which blocks by path and scores every request
//on its own:
//- /models/username/{name}/cam and the username lookup answer http 418 on stripchat.com, always
//- the other ways to the cam (by numeric model id on stripchat.com or its vr mirror, or by username on
//  the mirror) each get a 403 challenge page at random, and on a bad day all of them do
//so a check walks through every way in turn, twice, and when they are all blocked it falls back to two
//things that aren't behind the bot protection: the username lookup on the mirror (which says whether the
//model is online) and the stream's own playlist on the cdn (which exists only while the room is live)
public sealed class StripchatProbe : SiteProbe
{
    private static readonly string[] Hosts = { "stripchat.com", "vr.stripchat.com" };

    private static readonly string[] Headers = { "Accept: application/json", "Referer: https://stripchat.com/" };

    private const string UserUri = "https://{0}/api/front/v2/users/username/{1}";
    private const string CamByIdUri = "https://{0}/api/front/v2/models/{1}/cam";
    private const string CamByNameUri = "https://vr.stripchat.com/api/front/v2/models/username/{0}/cam";

    //two different urls, for two different jobs:
    //- the master playlist on the edge cdn answers 200 while the room is live and 404 when it isn't, and
    //  lists the stream's resolution, so it tells us the status when the api is blocked. it must NOT be
    //  recorded from: its segments are scrambled (the #EXT-X-MOUFLON tags) and anything that can't
    //  unscramble them is served one and the same placeholder clip for every room
    //- the media cdn redirects to a signed playlist (pkey) whose segments are the room's real stream,
    //  which is what gets recorded
    private const string LivePlaylistUri = "https://edge-hls.doppiocdn.com/hls/{0}/master/{0}.m3u8";
    private const string RecordPlaylistUri = "https://media-hls.growcdnssedge.com/b-hls-{0:00}/{1}/{1}.m3u8";

    private const int Rounds = 2;

    public override ChatRoomWebsite Website => ChatRoomWebsite.Stripchat;

    public override async Task<ProbeResult> ProbeAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        StripchatUser user = new(null, null);

        //the id also survives a rename, but it's not required - the cam can be asked for by name too
        if (string.IsNullOrEmpty(context.Cache))
        {
            user = await GetUserAsync(context, cancellationToken);

            if (user.NotFound)
            {
                context.Error($"there's no room called '{context.Name}' on stripchat");

                return ProbeResult.Error;
            }

            context.Cache = user.Id;
        }

        (HttpResult result, string url, bool byName) = await GetCamAsync(context, cancellationToken);

        if (result.StatusCode == 404)
        {
            if (byName)
            {
                context.Error($"there's no room called '{context.Name}' on stripchat");
            }
            else
            {
                //the model was renamed or re-registered - the next check starts over from the username
                context.Warning($"model id {context.Cache} is stale (http 404) - it will be resolved again");
                context.Cache = null;
            }

            return ProbeResult.Error;
        }

        if (result.StatusCode != 200)
        {
            context.Warning($"every way to the room's cam was blocked (last http {result.StatusCode} for {url}) - asking the cdn instead");

            return await ProbeWithoutCamAsync(context, user, cancellationToken);
        }

        JsonNode root = JsonNode.Parse(result.Body)!;
        JsonNode? camUser = root["user"]?["user"];

        //a wrong id would quietly return another model's stream
        string? reportedName = Str(camUser?["username"]);

        if (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, context.Name, StringComparison.OrdinalIgnoreCase))
        {
            context.Error($"the api answered about '{reportedName}' instead of '{context.Name}' - the model id has been discarded");
            context.Cache = null;

            return ProbeResult.Error;
        }

        if (string.IsNullOrEmpty(context.Cache) && Str(camUser?["id"]) is { Length: > 0 } camId)
        {
            context.Cache = camId;
        }

        string? raw = Str(camUser?["status"]);

        ChatRoomStatus status = raw switch
        {
            "public" => ChatRoomStatus.Public,
            "virtualPrivate" or "private" or "p2p" or "p2pVoice" => ChatRoomStatus.Private,
            "groupShow" => ChatRoomStatus.Group,
            "idle" => ChatRoomStatus.Idle,
            "off" => ChatRoomStatus.Offline,
            "" => ChatRoomStatus.Hidden,
            _ => ChatRoomStatus.Unknown
        };

        context.Info($"status - {status} ('{raw}') via {url}");

        if (status != ChatRoomStatus.Public)
        {
            return ProbeResult.Of(status);
        }

        string streamName = Str(root["cam"]?["streamName"]) ?? context.Cache ?? string.Empty;

        if (streamName.Length == 0)
        {
            context.Error("the room is public but the api didn't give a stream name");

            return ProbeResult.Error;
        }

        string playlistUrl = await RecordUrlAsync(streamName, context, cancellationToken);

        //only the source resolution is published nowadays (cam.broadcastConfig), older rooms still
        //carry cam.broadcastSettings
        JsonNode? config = root["cam"]?["broadcastConfig"];
        JsonNode? settings = root["cam"]?["broadcastSettings"];
        List<Resolution> resolutions = new();

        if (Int(config?["flashWidth"]) is int configWidth && Int(config?["flashHeight"]) is int configHeight)
        {
            resolutions.Add(new Resolution((short)configWidth, (short)configHeight));
        }
        else if (Int(settings?["width"]) is int settingsWidth && Int(settings?["height"]) is int settingsHeight)
        {
            resolutions.Add(new Resolution((short)settingsWidth, (short)settingsHeight));
        }

        if (resolutions.Count == 0)
        {
            resolutions.AddRange(await GetPlaylistResolutionsAsync(string.Format(LivePlaylistUri, streamName), cancellationToken));
        }

        return Finish(context, status, playlistUrl, resolutions, Target(playlistUrl));
    }

    //the cam api is unreachable: the room's own stream says whether it's live, the lookup says whether
    //the model is online at all
    private async Task<ProbeResult> ProbeWithoutCamAsync(ProbeContext context, StripchatUser user, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(context.Cache))
        {
            context.Error($"couldn't resolve the model id of '{context.Name}', so the stream can't be found either");

            return ProbeResult.Error;
        }

        //a cached id was used above, so the online flag may not have been fetched yet
        if (user.IsOnline == null)
        {
            user = await GetUserAsync(context, cancellationToken);
        }

        (bool success, string playlist) = await PlaylistClient.GetAsync(string.Format(LivePlaylistUri, context.Cache), cancellationToken);

        if (success && playlist.Contains("#EXTM3U", StringComparison.Ordinal))
        {
            context.Info($"status - {ChatRoomStatus.Public} (the room's stream is running) via the cdn");

            //the status came from the edge cdn, but the recording still goes through the media cdn
            string playlistUrl = await RecordUrlAsync(context.Cache, context, cancellationToken);

            return Finish(context, ChatRoomStatus.Public, playlistUrl, PlaylistClient.ParseResolutions(playlist), Target(playlistUrl));
        }

        //no stream: either the model is away, or online but not showing publicly (private or group)
        ChatRoomStatus status = user.IsOnline == false ? ChatRoomStatus.Offline : ChatRoomStatus.Private;

        context.Info($"status - {status} (no stream on the cdn, the model is {(user.IsOnline == false ? "offline" : "online")})");

        return ProbeResult.Of(status);
    }

    //the edge number only picks which mirror answers - it redirects to the signed playlist either way.
    //a mirror sometimes refuses, and a refused url means a recording that writes nothing, so the url is
    //tried before it is handed over and another mirror is used when one doesn't answer
    private static async Task<string> RecordUrlAsync(string streamName, ProbeContext context, CancellationToken cancellationToken)
    {
        string url = string.Empty;

        for (int attempt = 0; attempt < 3; attempt++)
        {
            url = string.Format(RecordPlaylistUri, Random.Shared.Next(1, 26), streamName);

            try
            {
                (bool success, string playlist) = await PlaylistClient.GetAsync(url, cancellationToken);

                if (success && playlist.Contains("#EXTM3U", StringComparison.Ordinal))
                {
                    return url;
                }
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                //try the next mirror
            }
        }

        context.Warning($"the stream's own cdn didn't answer on three mirrors - the recording may not start ({url})");

        return url;
    }

    //streamlink always takes the best stream here
    private static Func<int, RecordTarget> Target(string playlistUrl) =>
        _ => new RecordTarget(RecordMethod.Streamlink, playlistUrl, 0, "best");

    private static async Task<List<Resolution>> GetPlaylistResolutionsAsync(string playlistUrl, CancellationToken cancellationToken)
    {
        try
        {
            (bool success, string playlist) = await PlaylistClient.GetAsync(playlistUrl, cancellationToken);

            return success ? PlaylistClient.ParseResolutions(playlist) : new List<Resolution>();
        }
        catch (Exception)
        {
            return new List<Resolution>();
        }
    }

    private async Task<(HttpResult Result, string Url, bool ByName)> GetCamAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        List<(string Url, bool ByName)> ways = new();

        if (!string.IsNullOrEmpty(context.Cache))
        {
            ways.AddRange(Hosts.Select(host => (string.Format(CamByIdUri, host, context.Cache), false)));
        }

        ways.Add((string.Format(CamByNameUri, Uri.EscapeDataString(context.Name)), true));

        HttpResult result = new(0, string.Empty, string.Empty);
        (string Url, bool ByName) last = ways[^1];

        for (int round = 0; round < Rounds; round++)
        {
            if (round > 0)
            {
                await Task.Delay(Random.Shared.Next(1500, 3000), cancellationToken);
            }

            foreach ((string url, bool byName) in ways)
            {
                result = await CurlClient.SendAsync(url, cancellationToken, Headers);
                last = (url, byName);

                //a 200 is the answer, a 404 is an answer about the room that no other way will change
                if (result.StatusCode is 200 or 404)
                {
                    return (result, url, byName);
                }
            }
        }

        return (result, last.Url, last.ByName);
    }

    //looks the username up: the numeric model id and whether the model is online. NotFound means the
    //website said the username doesn't exist - a blocked lookup just leaves both unknown
    private async Task<StripchatUser> GetUserAsync(ProbeContext context, CancellationToken cancellationToken)
    {
        foreach (string host in Hosts)
        {
            string url = string.Format(UserUri, host, Uri.EscapeDataString(context.Name));
            HttpResult result = await CurlClient.SendAsync(url, cancellationToken, Headers);

            if (result.StatusCode == 404)
            {
                return new StripchatUser(null, null) { NotFound = true };
            }

            if (result.StatusCode != 200)
            {
                continue;
            }

            JsonNode? item = JsonNode.Parse(result.Body)?["item"];
            string? id = Str(item?["id"]);
            string? reportedName = Str(item?["username"]);
            bool? isOnline = item?["isOnline"] is JsonValue online && online.TryGetValue(out bool value) ? value : null;

            if (string.IsNullOrEmpty(id) ||
                (!string.IsNullOrEmpty(reportedName) && !string.Equals(reportedName, context.Name, StringComparison.OrdinalIgnoreCase)))
            {
                return new StripchatUser(null, isOnline);
            }

            context.Info($"model id of {context.Name} is {id}, online {isOnline?.ToString() ?? "unknown"}");

            return new StripchatUser(id, isOnline);
        }

        return new StripchatUser(null, null);
    }

    private readonly record struct StripchatUser(string? Id, bool? IsOnline)
    {
        public bool NotFound { get; init; }
    }
}
