using ChatRoomRecorder.Wpf.Models;
using ChatRoomRecorder.Wpf.Services;
using CommunityToolkit.Mvvm.ComponentModel;

namespace ChatRoomRecorder.Wpf.ViewModels;

public sealed class RoomViewModel : ObservableObject
{
    private int _checkRunning;
    private ChatRoomAction _action;
    private Resolution _preferredResolution;
    private ChatRoomStatus _status = ChatRoomStatus.Unknown;
    private DateTime _lastUpdated;
    private DateTime _lastSeen;
    private string _playlistUrl = string.Empty;
    private string _resolutions = string.Empty;
    private bool _isChecking;
    private string? _recordingFile;
    private long _recordingSize;
    private DateTime? _recordingStarted;
    private string _lastMessage = string.Empty;

    public RoomViewModel(RoomUrl url)
    {
        Website = url.Website;
        Name = url.Name;
        Url = url.Url;
    }

    public int Id { get; set; }

    public ChatRoomWebsite Website { get; }

    public string Name { get; }

    public string Url { get; }

    public CategoryViewModel? Category { get; set; }

    public ChatRoomAction Action { get => _action; set => SetProperty(ref _action, value); }

    public Resolution PreferredResolution { get => _preferredResolution; set => SetProperty(ref _preferredResolution, value); }

    public ChatRoomStatus Status
    {
        get => _status;
        set
        {
            if (SetProperty(ref _status, value))
            {
                OnPropertyChanged(nameof(IsOnline));
            }
        }
    }

    public bool IsOnline => Status is ChatRoomStatus.Public or ChatRoomStatus.Record or ChatRoomStatus.Private or ChatRoomStatus.Group;

    public DateTime LastUpdated { get => _lastUpdated; set => SetProperty(ref _lastUpdated, value); }

    public DateTime LastSeen { get => _lastSeen; set => SetProperty(ref _lastSeen, value); }

    public string PlaylistUrl { get => _playlistUrl; set => SetProperty(ref _playlistUrl, value); }

    public string Resolutions { get => _resolutions; set => SetProperty(ref _resolutions, value); }

    public bool IsChecking { get => _isChecking; set => SetProperty(ref _isChecking, value); }

    public string? RecordingFile
    {
        get => _recordingFile;
        set
        {
            if (SetProperty(ref _recordingFile, value))
            {
                OnPropertyChanged(nameof(IsRecording));
            }
        }
    }

    public bool IsRecording => RecordingFile != null;

    public long RecordingSize { get => _recordingSize; set => SetProperty(ref _recordingSize, value); }

    public DateTime? RecordingStarted { get => _recordingStarted; set => SetProperty(ref _recordingStarted, value); }

    public string LastMessage { get => _lastMessage; set => SetProperty(ref _lastMessage, value); }

    //runtime state owned by the monitor - only touched by the check that holds the room
    internal RecordingSession? Recording { get; set; }

    internal string? SiteCache { get; set; }

    //a room is checked by one task at a time
    internal bool TryBeginCheck() => Interlocked.CompareExchange(ref _checkRunning, 1, 0) == 0;

    internal void EndCheck() => Interlocked.Exchange(ref _checkRunning, 0);

    internal bool IsCheckRunning => Volatile.Read(ref _checkRunning) == 1;

    public bool Matches(string filter)
    {
        if (string.IsNullOrWhiteSpace(filter))
        {
            return true;
        }

        //a filter that parses as a room link matches by website and name, anything else by url text
        RoomUrl? parsed = RoomUrl.Parse(filter);

        return parsed != null
            ? Website == parsed.Website && Name.Contains(parsed.Name, StringComparison.OrdinalIgnoreCase)
            : Url.Contains(filter.Trim(), StringComparison.OrdinalIgnoreCase) || Name.Contains(filter.Trim(), StringComparison.OrdinalIgnoreCase);
    }
}
