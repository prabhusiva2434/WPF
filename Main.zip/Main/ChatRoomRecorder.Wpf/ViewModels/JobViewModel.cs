using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace ChatRoomRecorder.Wpf.ViewModels;

public enum JobState
{
    Queued,
    Running,
    Completed,
    Failed,
    Cancelled
}

public sealed class JobViewModel : ObservableObject
{
    private readonly CancellationTokenSource _cancellation = new();
    private readonly TaskCompletionSource<bool> _completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private JobState _state = JobState.Queued;
    private double _progress;
    private bool _isIndeterminate = true;
    private string _detail = string.Empty;

    public JobViewModel(string title, string? outputPath)
    {
        Title = title;
        OutputPath = outputPath;
        Created = DateTime.Now;
        CancelCommand = new RelayCommand(Cancel, () => IsActive);
    }

    public string Title { get; }

    public string? OutputPath { get; }

    public DateTime Created { get; }

    public JobState State
    {
        get => _state;
        set
        {
            if (SetProperty(ref _state, value))
            {
                OnPropertyChanged(nameof(IsActive));
                CancelCommand.NotifyCanExecuteChanged();
            }
        }
    }

    public bool IsActive => State is JobState.Queued or JobState.Running;

    public double Progress { get => _progress; set => SetProperty(ref _progress, value); }

    public bool IsIndeterminate { get => _isIndeterminate; set => SetProperty(ref _isIndeterminate, value); }

    public string Detail { get => _detail; set => SetProperty(ref _detail, value); }

    public RelayCommand CancelCommand { get; }

    public CancellationToken CancellationToken => _cancellation.Token;

    //completes with true when the job succeeded
    public Task<bool> Completion => _completion.Task;

    internal void Complete(bool success) => _completion.TrySetResult(success);

    private void Cancel() => _cancellation.Cancel();
}
