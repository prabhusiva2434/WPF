using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using ChatRoomRecorder.Wpf.Models;
using ChatRoomRecorder.Wpf.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace ChatRoomRecorder.Wpf.ViewModels;

public enum NotificationKind
{
    Info,
    Success,
    Warning,
    Error
}

public sealed record CategoryChoice(CategoryViewModel Category, string Path);

public sealed class MainViewModel : ObservableObject
{
    private readonly IDialogService _dialogs;
    private readonly DispatcherTimer _tick;
    private readonly DispatcherTimer _settingsSave;
    private readonly DispatcherTimer _filterDelay;
    private readonly DispatcherTimer _selectionDelay;
    private readonly DispatcherTimer _notificationClear;
    private readonly HashSet<(ChatRoomWebsite, string)> _roomKeys = new();
    private Database? _database;
    private RoomMonitor? _monitor;
    private CancellationTokenSource? _filesLoading;
    private bool _loading;
    private bool _shutDown;
    private int _tickCount;

    private CategoryViewModel? _selectedCategory;
    private bool _includeSubcategories = true;
    private string _filterText = string.Empty;
    private IReadOnlyList<RoomViewModel> _selectedRooms = Array.Empty<RoomViewModel>();
    private IReadOnlyList<RecordingFileInfo> _selectedFiles = Array.Empty<RecordingFileInfo>();
    private ObservableCollection<RecordingFileInfo> _files = new();
    private string _filesSummary = string.Empty;
    private bool _isLoadingFiles;
    private BitmapImage? _thumbnail;
    private string _logFilterText = string.Empty;
    private bool _errorsOnly;
    private bool _isBusy;
    private string _busyText = string.Empty;
    private string _notificationText = string.Empty;
    private NotificationKind _notificationKind;
    private int _selectedPageIndex;
    private int _roomCount;
    private int _onlineCount;
    private int _recordingCount;
    private int _errorCount;
    private int _activeChecks;

    public MainViewModel(LogService log, IDialogService dialogs)
    {
        Log = log;
        _dialogs = dialogs;
        Jobs = new JobQueue(log);

        RoomsView = new ListCollectionView(AllRooms) { Filter = FilterRoom };
        LogView = new ListCollectionView(LogEntries) { Filter = FilterLog };

        _tick = CreateTimer(TimeSpan.FromSeconds(1), OnTick, repeat: true);
        _settingsSave = CreateTimer(TimeSpan.FromMilliseconds(700), SaveSettingsNow);
        _filterDelay = CreateTimer(TimeSpan.FromMilliseconds(250), ApplyFilter);
        _selectionDelay = CreateTimer(TimeSpan.FromMilliseconds(150), () => Fire(Guard(LoadFilesAsync)));
        _notificationClear = CreateTimer(TimeSpan.FromSeconds(7), () => NotificationText = string.Empty);

        Settings.PropertyChanged += (_, _) =>
        {
            if (!_loading)
            {
                Restart(_settingsSave);
            }
        };

        AddFromTextCommand = Command(AddFromTextAsync);
        AddFromListCommand = Command(AddFromListAsync);
        AddFromFolderCommand = Command(AddFromFolderAsync);
        RemoveRoomsCommand = new RelayCommand(RemoveRooms, () => HasRoomSelection);
        CopyUrlsCommand = new RelayCommand(CopyUrls, () => HasRoomSelection);
        OpenRoomPageCommand = new RelayCommand(OpenRoomPages, () => HasRoomSelection);
        OpenRoomFolderCommand = new RelayCommand(OpenRoomFolder, () => SelectedRoom != null);
        CheckNowCommand = new RelayCommand(CheckNow, () => HasRoomSelection);
        SetActionCommand = new RelayCommand<ChatRoomAction>(SetAction, _ => HasRoomSelection);
        SetResolutionCommand = new RelayCommand<Resolution>(SetResolution, _ => HasRoomSelection);
        MoveRoomsCommand = new RelayCommand<CategoryChoice>(choice => MoveRooms(SelectedRooms, choice?.Category), _ => HasRoomSelection);

        AddCategoryCommand = Command(AddCategoryAsync);
        RenameCategoryCommand = Command(RenameCategoryAsync);
        RemoveCategoryCommand = Command(RemoveCategoryAsync);

        OpenFileCommand = new RelayCommand(OpenFile, () => SelectedFiles.Count == 1);
        RemoveFilesCommand = Command(RemoveFilesAsync);
        ExtractFragmentCommand = new RelayCommand(ExtractFragment, () => SelectedFiles.Count == 1);
        MergeFilesCommand = new RelayCommand(MergeFiles, () => SelectedFiles.Count > 1);
        ConvertToMp4Command = new RelayCommand(ConvertToMp4, () => SelectedFiles.Count > 0);
        ShowInExplorerCommand = new RelayCommand(ShowInExplorer, () => SelectedFiles.Count == 1);
        ChangeThumbnailCommand = Command(ChangeThumbnailAsync);
        RefreshFilesCommand = Command(LoadFilesAsync);

        BrowseOutputDirectoryCommand = new RelayCommand(BrowseOutputDirectory);
        BrowseFFmpegCommand = new RelayCommand(() => BrowseExecutable("ffmpeg.exe", path => Settings.FFmpegPath = path));
        BrowseStreamlinkCommand = new RelayCommand(() => BrowseExecutable("streamlink.exe", path => Settings.StreamlinkPath = path));
        ImportClassicCommand = Command(ImportClassicAsync);
        OpenDataFolderCommand = new RelayCommand(() => ShellOpen(AppPaths.DataDirectory));

        CopyLogCommand = new RelayCommand<IList>(CopyLog);
        ClearLogCommand = new RelayCommand(LogEntries.Clear);
        ClearFinishedJobsCommand = new RelayCommand(Jobs.ClearFinished);
        DismissNotificationCommand = new RelayCommand(() => NotificationText = string.Empty);
    }

    #region Properties

    public string Title { get; } = $"ChatRoom Recorder Studio {Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3)}";

    public LogService Log { get; }

    public JobQueue Jobs { get; }

    public AppSettings Settings { get; } = new();

    public ObservableCollection<CategoryViewModel> Categories { get; } = new();

    public ObservableCollection<RoomViewModel> AllRooms { get; } = new();

    public ListCollectionView RoomsView { get; }

    public ObservableCollection<LogEntry> LogEntries { get; } = new();

    public ListCollectionView LogView { get; }

    public IReadOnlyList<ChatRoomAction> ActionChoices { get; } = Enum.GetValues<ChatRoomAction>();

    public IReadOnlyList<Resolution> ResolutionChoices { get; } = Resolution.Choices;

    public IReadOnlyList<VideoEncoder> EncoderChoices { get; } = Enum.GetValues<VideoEncoder>();

    public IReadOnlyList<VideoPreset> PresetChoices { get; } = Enum.GetValues<VideoPreset>();

    public IEnumerable<CategoryChoice> MoveTargets => Categories
        .SelectMany(category => category.SelfAndDescendants())
        .Select(category => new CategoryChoice(category, CategoryPath(category)));

    public CategoryViewModel? SelectedCategory
    {
        get => _selectedCategory;
        set
        {
            if (SetProperty(ref _selectedCategory, value))
            {
                RoomsView.Refresh();
            }
        }
    }

    public bool IncludeSubcategories
    {
        get => _includeSubcategories;
        set
        {
            if (SetProperty(ref _includeSubcategories, value))
            {
                RoomsView.Refresh();
            }
        }
    }

    public string FilterText
    {
        get => _filterText;
        set
        {
            if (SetProperty(ref _filterText, value ?? string.Empty))
            {
                Restart(_filterDelay);
            }
        }
    }

    public bool IsSearching => !string.IsNullOrWhiteSpace(FilterText);

    public IReadOnlyList<RoomViewModel> SelectedRooms
    {
        get => _selectedRooms;
        private set
        {
            if (SetProperty(ref _selectedRooms, value))
            {
                OnPropertyChanged(nameof(SelectedRoom));
                OnPropertyChanged(nameof(HasRoomSelection));
                OnPropertyChanged(nameof(SelectionSummary));
                NotifyCommands();
            }
        }
    }

    public RoomViewModel? SelectedRoom => SelectedRooms.Count == 1 ? SelectedRooms[0] : null;

    public bool HasRoomSelection => SelectedRooms.Count > 0;

    public string SelectionSummary => SelectedRooms.Count switch
    {
        0 => "No room selected",
        1 => $"{SelectedRooms[0].Website} · {SelectedRooms[0].Name}",
        _ => $"{SelectedRooms.Count} rooms selected"
    };

    public IReadOnlyList<RecordingFileInfo> SelectedFiles
    {
        get => _selectedFiles;
        private set
        {
            if (SetProperty(ref _selectedFiles, value))
            {
                NotifyCommands();
            }
        }
    }

    public ObservableCollection<RecordingFileInfo> Files { get => _files; private set => SetProperty(ref _files, value); }

    public string FilesSummary { get => _filesSummary; private set => SetProperty(ref _filesSummary, value); }

    public bool IsLoadingFiles { get => _isLoadingFiles; private set => SetProperty(ref _isLoadingFiles, value); }

    public BitmapImage? Thumbnail { get => _thumbnail; private set => SetProperty(ref _thumbnail, value); }

    public string LogFilterText
    {
        get => _logFilterText;
        set
        {
            if (SetProperty(ref _logFilterText, value ?? string.Empty))
            {
                LogView.Refresh();
            }
        }
    }

    public bool ErrorsOnly
    {
        get => _errorsOnly;
        set
        {
            if (SetProperty(ref _errorsOnly, value))
            {
                LogView.Refresh();
            }
        }
    }

    public bool IsBusy { get => _isBusy; private set => SetProperty(ref _isBusy, value); }

    public string BusyText { get => _busyText; private set => SetProperty(ref _busyText, value); }

    public string NotificationText
    {
        get => _notificationText;
        private set
        {
            if (SetProperty(ref _notificationText, value))
            {
                OnPropertyChanged(nameof(HasNotification));
            }
        }
    }

    public bool HasNotification => NotificationText.Length > 0;

    public NotificationKind NotificationKind { get => _notificationKind; private set => SetProperty(ref _notificationKind, value); }

    public int SelectedPageIndex { get => _selectedPageIndex; set => SetProperty(ref _selectedPageIndex, value); }

    public int RoomCount { get => _roomCount; private set => SetProperty(ref _roomCount, value); }

    public int OnlineCount { get => _onlineCount; private set => SetProperty(ref _onlineCount, value); }

    public int RecordingCount { get => _recordingCount; private set => SetProperty(ref _recordingCount, value); }

    public int ErrorCount { get => _errorCount; private set => SetProperty(ref _errorCount, value); }

    public int ActiveChecks { get => _activeChecks; private set => SetProperty(ref _activeChecks, value); }

    public IAsyncRelayCommand AddFromTextCommand { get; }
    public IAsyncRelayCommand AddFromListCommand { get; }
    public IAsyncRelayCommand AddFromFolderCommand { get; }
    public RelayCommand RemoveRoomsCommand { get; }
    public RelayCommand CopyUrlsCommand { get; }
    public RelayCommand OpenRoomPageCommand { get; }
    public RelayCommand OpenRoomFolderCommand { get; }
    public RelayCommand CheckNowCommand { get; }
    public RelayCommand<ChatRoomAction> SetActionCommand { get; }
    public RelayCommand<Resolution> SetResolutionCommand { get; }
    public RelayCommand<CategoryChoice> MoveRoomsCommand { get; }
    public IAsyncRelayCommand AddCategoryCommand { get; }
    public IAsyncRelayCommand RenameCategoryCommand { get; }
    public IAsyncRelayCommand RemoveCategoryCommand { get; }
    public RelayCommand OpenFileCommand { get; }
    public IAsyncRelayCommand RemoveFilesCommand { get; }
    public RelayCommand ExtractFragmentCommand { get; }
    public RelayCommand MergeFilesCommand { get; }
    public RelayCommand ConvertToMp4Command { get; }
    public RelayCommand ShowInExplorerCommand { get; }
    public IAsyncRelayCommand ChangeThumbnailCommand { get; }
    public IAsyncRelayCommand RefreshFilesCommand { get; }
    public RelayCommand BrowseOutputDirectoryCommand { get; }
    public RelayCommand BrowseFFmpegCommand { get; }
    public RelayCommand BrowseStreamlinkCommand { get; }
    public IAsyncRelayCommand ImportClassicCommand { get; }
    public RelayCommand OpenDataFolderCommand { get; }
    public RelayCommand<IList> CopyLogCommand { get; }
    public RelayCommand ClearLogCommand { get; }
    public RelayCommand ClearFinishedJobsCommand { get; }
    public RelayCommand DismissNotificationCommand { get; }

    #endregion

    #region Lifetime

    public async Task InitializeAsync()
    {
        SetBusy("Loading rooms…");

        try
        {
            await Guard(async () =>
            {
                AppPaths.EnsureCreated();
                await LoadBackendAsync();
            });
        }
        finally
        {
            _tick.Start();
            ClearBusy();
        }
    }

    //stops checks, recordings and jobs within bounded time - the window stays responsive meanwhile
    public async Task ShutdownAsync()
    {
        if (_shutDown)
        {
            return;
        }

        _shutDown = true;
        SetBusy("Stopping checks, recordings and tasks…");
        _tick.Stop();

        if (_settingsSave.IsEnabled && _database != null)
        {
            _settingsSave.Stop();
            await Quietly(_database.SaveSettingsAsync(Settings));
        }

        List<JobViewModel> activeJobs = Jobs.Jobs.Where(job => job.IsActive).ToList();
        activeJobs.ForEach(job => job.CancelCommand.Execute(null));
        await Task.WhenAny(Task.WhenAll(activeJobs.Select(job => job.Completion)), Task.Delay(TimeSpan.FromSeconds(8)));

        await StopBackendAsync();
    }

    private async Task LoadBackendAsync()
    {
        _loading = true;

        try
        {
            _database = await Database.OpenAsync(AppPaths.DatabasePath, Log);
            StoredData data = await _database.LoadAsync();

            foreach (PropertyInfo property in typeof(AppSettings).GetProperties().Where(p => p.CanRead && p.CanWrite))
            {
                property.SetValue(Settings, property.GetValue(data.Settings));
            }

            _monitor = new RoomMonitor(Settings, _database, Log);

            foreach (RoomViewModel room in AllRooms)
            {
                room.PropertyChanged -= Room_PropertyChanged;
            }

            AllRooms.Clear();
            _roomKeys.Clear();
            Categories.Clear();

            //categories: create them all, then hang each under its parent (without ever forming a cycle)
            StoredCategory? storedRoot = data.Categories.FirstOrDefault(category => category.Id == Database.RootCategoryId);
            CategoryViewModel root = new(Database.RootCategoryId, storedRoot?.Name ?? Database.RootCategoryName, null);
            Dictionary<int, CategoryViewModel> byId = new() { [root.Id] = root };

            foreach (StoredCategory stored in data.Categories.Where(category => category.Id != root.Id))
            {
                byId[stored.Id] = new CategoryViewModel(stored.Id, stored.Name, null);
            }

            foreach (StoredCategory stored in data.Categories.Where(category => category.Id != root.Id))
            {
                CategoryViewModel category = byId[stored.Id];
                CategoryViewModel parent = byId.TryGetValue(stored.ParentId, out CategoryViewModel? found) && !category.IsSelfOrAncestorOf(found)
                    ? found
                    : root;

                category.Parent = parent;
                parent.Children.Add(category);
            }

            foreach (CategoryViewModel category in byId.Values)
            {
                category.SortChildren();
            }

            Categories.Add(root);

            foreach (StoredRoom stored in data.Rooms)
            {
                RoomUrl? url = RoomUrl.Parse(stored.Url);

                if (url == null || !_roomKeys.Add((url.Website, url.Name)))
                {
                    Log.Warning("app", $"skipped the stored room '{stored.Url}' - it's unrecognized or a duplicate");

                    continue;
                }

                RoomViewModel room = new(url)
                {
                    Id = stored.Id,
                    Action = stored.Action,
                    PreferredResolution = stored.Resolution,
                    LastUpdated = stored.Updated,
                    LastSeen = stored.Seen
                };

                Attach(room, byId.GetValueOrDefault(stored.CategoryId) ?? root);
            }

            root.IsSelected = true;
            SelectedCategory = root;
            RoomsView.Refresh();
            RefreshCategoryCounts();
            OnPropertyChanged(nameof(MoveTargets));

            Fire(FileService.MoveLooseRecordingsAsync(Settings.OutputDirectory, Log));

            _monitor.Start();

            Log.Info("app", $"loaded {AllRooms.Count} rooms in {byId.Count} categories from {AppPaths.DatabasePath}");
        }
        finally
        {
            _loading = false;
        }
    }

    private async Task StopBackendAsync()
    {
        if (_monitor != null)
        {
            RoomMonitor monitor = _monitor;
            _monitor = null;
            await Quietly(monitor.StopAsync(TimeSpan.FromSeconds(10)));
        }

        if (_database != null)
        {
            Database database = _database;
            _database = null;
            await Quietly(database.DisposeAsync().AsTask());
        }
    }

    private void OnTick()
    {
        _tickCount++;

        List<LogEntry> entries = Log.Drain(1000);

        if (Settings.LogSize > 0)
        {
            foreach (LogEntry entry in entries)
            {
                LogEntries.Add(entry);
            }

            if (LogEntries.Count > Settings.LogSize + 200)
            {
                while (LogEntries.Count > Settings.LogSize)
                {
                    LogEntries.RemoveAt(0);
                }
            }
        }
        else if (LogEntries.Count > 0)
        {
            LogEntries.Clear();
        }

        RoomCount = AllRooms.Count;
        OnlineCount = AllRooms.Count(room => room.IsOnline);
        RecordingCount = AllRooms.Count(room => room.Status == ChatRoomStatus.Record);
        ErrorCount = AllRooms.Count(room => room.Status == ChatRoomStatus.Error);
        ActiveChecks = _monitor?.ActiveChecks ?? 0;

        if (_tickCount % 5 == 0)
        {
            RefreshCategoryCounts();
        }
    }

    #endregion

    #region Rooms

    public void UpdateSelectedRooms(IEnumerable selected)
    {
        SelectedRooms = selected.OfType<RoomViewModel>().ToList();
        Restart(_selectionDelay);
    }

    public void OnTextCopied(string text)
    {
        if (_shutDown || _database == null || !Settings.AddFromClipboard)
        {
            return;
        }

        Fire(Guard(async () =>
        {
            List<RoomUrl> links = text
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(RoomUrl.ParseLink)
                .OfType<RoomUrl>()
                .Where(url => !_roomKeys.Contains((url.Website, url.Name)))
                .ToList();

            int added = await AddRoomsAsync(links);

            if (added > 0)
            {
                Notify(added == 1 ? $"Added {links[0].Name} ({links[0].Website}) from the clipboard" : $"Added {added} rooms from the clipboard", NotificationKind.Success);
            }
        }));
    }

    private async Task AddFromTextAsync()
    {
        RoomUrl? url = RoomUrl.Parse(FilterText);

        if (url == null)
        {
            Notify("That isn't a supported room link. Paste a link from Chaturbate, BongaCams, Stripchat, Flirt4Free, CamSoda or Cam4.", NotificationKind.Warning);

            return;
        }

        if (_roomKeys.Contains((url.Website, url.Name)))
        {
            Notify($"{url.Name} ({url.Website}) is already in the list", NotificationKind.Info);

            return;
        }

        await AddRoomsAsync(new[] { url });
        FilterText = string.Empty;
        Notify($"Added {url.Name} ({url.Website})", NotificationKind.Success);
    }

    private async Task AddFromListAsync()
    {
        string? text = _dialogs.AskForUrls();

        if (text == null)
        {
            return;
        }

        await AddParsedAsync(text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(line => RoomUrl.Parse(line) ?? RoomUrl.ParseLink(line)).ToList());
    }

    private async Task AddFromFolderAsync()
    {
        string? folder = _dialogs.PickFolder("Choose a folder whose subfolders are named like \"stripchat name\"");

        if (folder == null)
        {
            return;
        }

        List<string> names = await Task.Run(() => Directory.EnumerateDirectories(folder).Select(Path.GetFileName).OfType<string>().ToList());

        await AddParsedAsync(names.Select(RoomUrl.Parse).ToList());
    }

    private async Task AddParsedAsync(List<RoomUrl?> parsed)
    {
        int unrecognized = parsed.Count(url => url == null);
        List<RoomUrl> candidates = parsed.OfType<RoomUrl>().DistinctBy(url => (url.Website, url.Name)).ToList();
        int existing = candidates.Count(url => _roomKeys.Contains((url.Website, url.Name)));
        int added = await AddRoomsAsync(candidates);

        Notify($"Added {added} rooms · {existing} already in the list · {unrecognized} not recognized",
            added > 0 ? NotificationKind.Success : NotificationKind.Info);
    }

    private async Task<int> AddRoomsAsync(IEnumerable<RoomUrl> urls)
    {
        if (_database == null)
        {
            return 0;
        }

        CategoryViewModel category = SelectedCategory ?? Categories[0];
        int added = 0;

        foreach (RoomUrl url in urls)
        {
            if (!_roomKeys.Add((url.Website, url.Name)))
            {
                continue;
            }

            try
            {
                RoomViewModel room = new(url)
                {
                    Action = Settings.DefaultAction,
                    PreferredResolution = Settings.DefaultResolution
                };

                room.Id = await _database.InsertRoomAsync(url.Url, room.Action, room.PreferredResolution, category.Id);
                Attach(room, category);
                Log.Room(url.Website, url.Name, LogLevel.Info, $"added to '{category.Name}'");
                added++;
            }
            catch
            {
                _roomKeys.Remove((url.Website, url.Name));

                throw;
            }
        }

        RefreshCategoryCounts();

        return added;
    }

    private void Attach(RoomViewModel room, CategoryViewModel category)
    {
        room.Category = category;
        category.Rooms.Add(room);
        AllRooms.Add(room);
        room.PropertyChanged += Room_PropertyChanged;
        _monitor?.Add(room);
    }

    private void Room_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (_loading || sender is not RoomViewModel room || _database == null)
        {
            return;
        }

        if (e.PropertyName is nameof(RoomViewModel.Action) or nameof(RoomViewModel.PreferredResolution))
        {
            Fire(_database.UpdateRoomAsync(room.Id, room.Action, room.PreferredResolution, room.LastUpdated, room.LastSeen));

            //react right away instead of waiting for the next interval
            _monitor?.CheckNow(room);
        }
    }

    private void RemoveRooms()
    {
        List<RoomViewModel> rooms = SelectedRooms.ToList();

        if (rooms.Count == 0 || !_dialogs.Confirm("Remove rooms",
            rooms.Count == 1 ? $"Remove {rooms[0].Name} ({rooms[0].Website})? Its recordings stay on disk." : $"Remove the {rooms.Count} selected rooms? Their recordings stay on disk."))
        {
            return;
        }

        foreach (RoomViewModel room in rooms)
        {
            room.PropertyChanged -= Room_PropertyChanged;
            room.Category?.Rooms.Remove(room);
            AllRooms.Remove(room);
            _roomKeys.Remove((room.Website, room.Name));

            if (_monitor != null)
            {
                Fire(_monitor.RemoveAsync(room));
            }

            if (_database != null)
            {
                Fire(_database.DeleteRoomAsync(room.Id));
            }

            Log.Room(room.Website, room.Name, LogLevel.Info, "removed");
        }

        RefreshCategoryCounts();
    }

    private void CopyUrls() => SetClipboard(string.Join(Environment.NewLine, SelectedRooms.Select(room => room.Url)));

    private void OpenRoomPages()
    {
        foreach (RoomViewModel room in SelectedRooms.Take(10))
        {
            //stripchat rooms are stored with the lemoncam mirror url, but the site itself is the useful page
            ShellOpen(room.Website == ChatRoomWebsite.Stripchat ? $"https://stripchat.com/{room.Name}" : room.Url);
        }
    }

    private void OpenRoomFolder()
    {
        if (SelectedRoom is RoomViewModel room)
        {
            string folder = Path.Combine(Settings.OutputDirectory, $"{room.Website} {room.Name}".ToLowerInvariant());
            ShellOpen(Directory.Exists(folder) ? folder : Settings.OutputDirectory);
        }
    }

    private void CheckNow()
    {
        foreach (RoomViewModel room in SelectedRooms)
        {
            _monitor?.CheckNow(room);
        }
    }

    private void SetAction(ChatRoomAction action)
    {
        foreach (RoomViewModel room in SelectedRooms)
        {
            room.Action = action;
        }
    }

    private void SetResolution(Resolution resolution)
    {
        foreach (RoomViewModel room in SelectedRooms)
        {
            room.PreferredResolution = resolution;
        }
    }

    public void MoveRooms(IEnumerable<RoomViewModel> rooms, CategoryViewModel? target)
    {
        if (target == null)
        {
            return;
        }

        int moved = 0;

        foreach (RoomViewModel room in rooms.ToList())
        {
            if (room.Category == target)
            {
                continue;
            }

            room.Category?.Rooms.Remove(room);
            room.Category = target;
            target.Rooms.Add(room);

            if (_database != null)
            {
                Fire(_database.MoveRoomAsync(room.Id, target.Id));
            }

            moved++;
        }

        if (moved > 0)
        {
            RoomsView.Refresh();
            RefreshCategoryCounts();
            Notify($"Moved {moved} room{(moved == 1 ? string.Empty : "s")} to '{target.Name}'", NotificationKind.Success);
        }
    }

    private bool FilterRoom(object item)
    {
        if (item is not RoomViewModel room)
        {
            return false;
        }

        //a search looks through every category
        if (IsSearching)
        {
            return room.Matches(FilterText);
        }

        if (SelectedCategory == null || room.Category == null)
        {
            return true;
        }

        return IncludeSubcategories ? SelectedCategory.IsSelfOrAncestorOf(room.Category) : room.Category == SelectedCategory;
    }

    private void ApplyFilter()
    {
        OnPropertyChanged(nameof(IsSearching));
        RoomsView.Refresh();
        RefreshCategoryCounts();
    }

    #endregion

    #region Categories

    private async Task AddCategoryAsync()
    {
        CategoryViewModel parent = SelectedCategory ?? Categories.FirstOrDefault()!;
        string? name = _dialogs.Prompt("New category", $"Name of the new category in '{parent.Name}'", "New category")?.Trim();

        if (string.IsNullOrEmpty(name) || _database == null)
        {
            return;
        }

        int id = await _database.InsertCategoryAsync(name, parent.Id);
        CategoryViewModel category = new(id, name, parent);
        parent.Children.Add(category);
        parent.SortChildren();
        parent.IsExpanded = true;
        category.IsSelected = true;
        SelectedCategory = category;
        OnPropertyChanged(nameof(MoveTargets));
    }

    private async Task RenameCategoryAsync()
    {
        CategoryViewModel? category = SelectedCategory;

        if (category == null || _database == null)
        {
            return;
        }

        string? name = _dialogs.Prompt("Rename category", "New name", category.Name)?.Trim();

        if (string.IsNullOrEmpty(name) || name == category.Name)
        {
            return;
        }

        await _database.RenameCategoryAsync(category.Id, name);
        category.Name = name;
        category.Parent?.SortChildren();
        OnPropertyChanged(nameof(MoveTargets));
    }

    private async Task RemoveCategoryAsync()
    {
        CategoryViewModel? category = SelectedCategory;

        if (category == null || category.IsRoot || category.Parent == null || _database == null)
        {
            Notify("The top category can't be removed", NotificationKind.Warning);

            return;
        }

        if (category.Children.Count > 0 || category.Rooms.Count > 0)
        {
            Notify($"'{category.Name}' isn't empty - move its rooms and subcategories out first", NotificationKind.Warning);

            return;
        }

        if (!_dialogs.Confirm("Remove category", $"Remove the category '{category.Name}'?"))
        {
            return;
        }

        await _database.DeleteCategoryAsync(category.Id);

        CategoryViewModel parent = category.Parent;
        parent.Children.Remove(category);
        parent.IsSelected = true;
        SelectedCategory = parent;
        OnPropertyChanged(nameof(MoveTargets));
    }

    public void MoveCategory(CategoryViewModel category, CategoryViewModel target)
    {
        if (category.IsRoot || category.Parent == null || category.Parent == target || category.IsSelfOrAncestorOf(target))
        {
            return;
        }

        category.Parent.Children.Remove(category);
        category.Parent = target;
        target.Children.Add(category);
        target.SortChildren();
        target.IsExpanded = true;

        if (_database != null)
        {
            Fire(_database.MoveCategoryAsync(category.Id, target.Id));
        }

        RoomsView.Refresh();
        RefreshCategoryCounts();
        OnPropertyChanged(nameof(MoveTargets));
    }

    private void RefreshCategoryCounts()
    {
        foreach (CategoryViewModel category in Categories)
        {
            category.RefreshCounts(FilterText);
        }
    }

    private static string CategoryPath(CategoryViewModel category)
    {
        List<string> names = new();

        for (CategoryViewModel? current = category; current != null; current = current.Parent)
        {
            names.Insert(0, current.Name);
        }

        return string.Join(" › ", names);
    }

    #endregion

    #region Files

    public void UpdateSelectedFiles(IEnumerable selected) => SelectedFiles = selected.OfType<RecordingFileInfo>().ToList();

    private async Task LoadFilesAsync()
    {
        _filesLoading?.Cancel();
        CancellationTokenSource loading = new();
        _filesLoading = loading;

        List<(ChatRoomWebsite, string)> rooms = SelectedRooms.Select(room => (room.Website, room.Name)).ToList();
        RoomViewModel? single = SelectedRoom;

        if (rooms.Count == 0)
        {
            Files = new ObservableCollection<RecordingFileInfo>();
            FilesSummary = string.Empty;
            Thumbnail = null;

            return;
        }

        IsLoadingFiles = true;

        try
        {
            List<RecordingFileInfo> files = await FileService.ListRecordingsAsync(Settings.OutputDirectory, rooms, loading.Token);

            if (loading.IsCancellationRequested)
            {
                return;
            }

            Files = new ObservableCollection<RecordingFileInfo>(files);
            FilesSummary = files.Count == 0 ? "No recordings yet" : $"{files.Count} recordings · {FileService.FormatSize(files.Sum(file => file.Length))}";

            await LoadThumbnailAsync(single, files, loading.Token);
        }
        catch (OperationCanceledException)
        {
            //a newer selection took over
        }
        finally
        {
            if (_filesLoading == loading)
            {
                IsLoadingFiles = false;
            }
        }
    }

    private async Task LoadThumbnailAsync(RoomViewModel? room, List<RecordingFileInfo> files, CancellationToken cancellationToken)
    {
        if (room == null)
        {
            Thumbnail = null;

            return;
        }

        string path = FileService.ThumbnailPath(room.Website, room.Name);

        if (files.Count > 0 && !await Task.Run(() => File.Exists(path), cancellationToken))
        {
            RecordingFileInfo file = files[Random.Shared.Next(files.Count)];
            await FileService.CreateThumbnailAsync(Settings.FFmpegPath, file.FullName, path, "00:00:00", cancellationToken);
        }

        BitmapImage? image = await FileService.LoadImageAsync(path);

        if (!cancellationToken.IsCancellationRequested && SelectedRoom == room)
        {
            Thumbnail = image;
        }
    }

    private void OpenFile()
    {
        if (SelectedFiles.Count == 1)
        {
            ShellOpen(SelectedFiles[0].FullName);
        }
    }

    private async Task RemoveFilesAsync()
    {
        List<RecordingFileInfo> files = SelectedFiles.ToList();
        HashSet<string> recording = AllRooms.Select(room => room.RecordingFile).OfType<string>().ToHashSet(StringComparer.OrdinalIgnoreCase);
        List<RecordingFileInfo> removable = files.Where(file => !recording.Contains(file.FullName)).ToList();

        if (removable.Count == 0)
        {
            Notify("The selected file is still being recorded", NotificationKind.Warning);

            return;
        }

        string message = removable.Count == 1 ? $"Delete {removable[0].Name} from disk?" : $"Delete the {removable.Count} selected files from disk?";

        if (removable.Count < files.Count)
        {
            message += $"\n\n{files.Count - removable.Count} file(s) still being recorded will be kept.";
        }

        if (!_dialogs.Confirm("Delete recordings", message))
        {
            return;
        }

        try
        {
            await FileService.DeleteFilesAsync(removable.Select(file => file.FullName));
        }
        finally
        {
            await LoadFilesAsync();
        }
    }

    private void ExtractFragment()
    {
        if (SelectedFiles.Count != 1)
        {
            return;
        }

        RecordingFileInfo source = SelectedFiles[0];

        if (_dialogs.PickFragment(source.FullName) is not (TimeSpan start, TimeSpan end))
        {
            return;
        }

        string target = UniquePath(Path.Combine(source.Directory, $"{Path.GetFileNameWithoutExtension(source.Name)} extracted {DateTime.Now:yyyy-MM-dd HH-mm-ss}.ts"));

        RunJob($"Extract {FfmpegTime(start)}–{FfmpegTime(end)} of {source.Name}",
            new[] { "-i", source.FullName, "-ss", FfmpegTime(start), "-to", FfmpegTime(end), "-c", "copy", target }, target);
    }

    private void MergeFiles()
    {
        if (SelectedFiles.Count < 2 || _dialogs.OrderForMerge(SelectedFiles.OrderBy(file => file.Name).ToList()) is not { Count: > 1 } ordered)
        {
            return;
        }

        string target = UniquePath(Path.Combine(ordered[0].Directory, $"{Path.GetFileNameWithoutExtension(ordered[0].Name)} merged {DateTime.Now:yyyy-MM-dd HH-mm-ss}.ts"));
        string list = Path.Combine(Path.GetTempPath(), $"ChatRoomRecorderWpf_{Guid.NewGuid()}.txt");

        File.WriteAllLines(list, ordered.Select(file => $"file '{file.FullName.Replace("'", "'\\''")}'"));

        RunJob($"Merge {ordered.Count} files into {Path.GetFileName(target)}",
            new[] { "-f", "concat", "-safe", "0", "-i", list, "-c", "copy", target }, target, list);
    }

    private void ConvertToMp4()
    {
        string? folder = _dialogs.PickFolder("Choose where the MP4 files go");

        if (folder == null)
        {
            return;
        }

        foreach (RecordingFileInfo file in SelectedFiles)
        {
            string target = UniquePath(Path.Combine(folder, Path.GetFileNameWithoutExtension(file.Name) + ".mp4"));
            RunJob($"Convert {file.Name} to MP4", new[] { "-i", file.FullName, "-c", "copy", target }, target);
        }
    }

    private void ShowInExplorer()
    {
        if (SelectedFiles.Count == 1)
        {
            try
            {
                Process.Start(new ProcessStartInfo("explorer.exe") { UseShellExecute = true, Arguments = $"/select,\"{SelectedFiles[0].FullName}\"" });
            }
            catch (Exception exception)
            {
                Notify($"The file can't be shown - {exception.Message}", NotificationKind.Error);
            }
        }
    }

    private async Task ChangeThumbnailAsync()
    {
        if (SelectedRoom is not RoomViewModel room || SelectedFiles.Count != 1)
        {
            Notify("Select one room and one of its recordings to pick a thumbnail from", NotificationKind.Info);

            return;
        }

        RecordingFileInfo file = SelectedFiles[0];

        if (_dialogs.PickThumbnailPosition(file.FullName) is not TimeSpan position)
        {
            return;
        }

        string path = FileService.ThumbnailPath(room.Website, room.Name);

        if (await FileService.CreateThumbnailAsync(Settings.FFmpegPath, file.FullName, path, FfmpegTime(position), CancellationToken.None))
        {
            Thumbnail = await FileService.LoadImageAsync(path);
            Notify("Thumbnail updated", NotificationKind.Success);
        }
        else
        {
            Notify("The thumbnail couldn't be created - check the ffmpeg path in the settings", NotificationKind.Error);
        }
    }

    private void RunJob(string title, IReadOnlyList<string> arguments, string output, string? temporaryFile = null)
    {
        JobViewModel job = Jobs.Enqueue(title, Settings.FFmpegPath, arguments, output, temporaryFile);
        Notify($"{title} - running in the background (see Tasks)", NotificationKind.Info);

        Fire(job.Completion.ContinueWith(task => Ui.Post(() =>
        {
            if (task.Result)
            {
                Notify($"{title} - done", NotificationKind.Success);
                Fire(Guard(LoadFilesAsync));
            }
            else if (job.State == JobState.Failed)
            {
                Notify($"{title} - failed: {job.Detail}", NotificationKind.Error);
            }
        }), TaskScheduler.Default));
    }

    #endregion

    #region Settings and log

    private void SaveSettingsNow()
    {
        if (_database != null)
        {
            Fire(_database.SaveSettingsAsync(Settings));
        }
    }

    private void BrowseOutputDirectory()
    {
        if (_dialogs.PickFolder("Choose where recordings are saved") is string folder)
        {
            Settings.OutputDirectory = folder;
        }
    }

    private void BrowseExecutable(string name, Action<string> apply)
    {
        if (_dialogs.PickFile($"Locate {name}", $"{name}|{name}") is string path)
        {
            apply(path);
        }
    }

    private async Task ImportClassicAsync()
    {
        string? path = _dialogs.PickFile(
            "Choose the classic app's database (ChatRoomRecorder.db, next to ChatRoomRecorder.exe)", "ChatRoomRecorder database|*.db");

        if (path == null || !_dialogs.Confirm("Import from the classic app",
            $"The rooms, categories and settings of this app will be replaced with the ones in\n{path}\n\n" +
            "Checks and recordings of this app are stopped first and a backup of its current data is kept. " +
            "The classic app and its database aren't changed.\n\nContinue?"))
        {
            return;
        }

        SetBusy("Importing from the classic app…");
        _tick.Stop();
        string backup = $"{AppPaths.DatabasePath}.{DateTime.Now:yyyyMMdd-HHmmss}.bak";

        try
        {
            await StopBackendAsync();
            await Task.Run(() =>
            {
                if (File.Exists(AppPaths.DatabasePath))
                {
                    File.Copy(AppPaths.DatabasePath, backup, true);
                }
            });

            try
            {
                await Database.ImportClassicAsync(path, AppPaths.DatabasePath);
                await LoadBackendAsync();
            }
            catch
            {
                //put the previous data back, so a bad file doesn't leave the app empty
                await StopBackendAsync();

                if (File.Exists(backup))
                {
                    await Task.Run(() => File.Copy(backup, AppPaths.DatabasePath, true));
                }

                await LoadBackendAsync();

                throw;
            }

            int thumbnails = await FileService.ImportThumbnailsAsync(Path.Combine(Path.GetDirectoryName(path)!, "Thumbnails"));
            Notify($"Imported {AllRooms.Count} rooms and {thumbnails} thumbnails from the classic app", NotificationKind.Success);
        }
        finally
        {
            _tick.Start();
            ClearBusy();
        }
    }

    private bool FilterLog(object item) =>
        item is LogEntry entry &&
        (!ErrorsOnly || entry.Level != LogLevel.Info) &&
        (LogFilterText.Length == 0 || entry.ToString().Contains(LogFilterText, StringComparison.OrdinalIgnoreCase));

    private void CopyLog(IList? selected)
    {
        IEnumerable<LogEntry> entries = selected is { Count: > 0 } ? selected.OfType<LogEntry>() : LogView.OfType<LogEntry>();
        SetClipboard(string.Join(Environment.NewLine, entries));
    }

    #endregion

    #region Helpers

    public void Notify(string message, NotificationKind kind = NotificationKind.Info)
    {
        NotificationKind = kind;
        NotificationText = message;
        Restart(_notificationClear);
    }

    private void SetBusy(string text)
    {
        BusyText = text;
        IsBusy = true;
    }

    private void ClearBusy() => IsBusy = false;

    private void NotifyCommands()
    {
        foreach (IRelayCommand command in new IRelayCommand[]
        {
            RemoveRoomsCommand, CopyUrlsCommand, OpenRoomPageCommand, OpenRoomFolderCommand, CheckNowCommand, SetActionCommand,
            SetResolutionCommand, MoveRoomsCommand, OpenFileCommand, ExtractFragmentCommand, MergeFilesCommand, ConvertToMp4Command,
            ShowInExplorerCommand
        })
        {
            command.NotifyCanExecuteChanged();
        }
    }

    private IAsyncRelayCommand Command(Func<Task> action) => new AsyncRelayCommand(() => Guard(action));

    //commands and background continuations report failures instead of crashing or going silent
    private async Task Guard(Func<Task> action)
    {
        try
        {
            await action();
        }
        catch (Exception exception)
        {
            Log.Error("app", $"{exception.GetType().Name}: {exception.Message}");
            Notify(exception.Message, NotificationKind.Error);
        }
    }

    private static async Task Quietly(Task task)
    {
        try
        {
            await task;
        }
        catch
        {
            //shutting down - nothing sensible left to do with the error
        }
    }

    private static void Fire(Task? task) =>
        task?.ContinueWith(completed => _ = completed.Exception, TaskContinuationOptions.OnlyOnFaulted);

    //a one-shot timer works as a debounce: Restart it on every change, the action runs once things settle
    private static DispatcherTimer CreateTimer(TimeSpan interval, Action action, bool repeat = false)
    {
        DispatcherTimer timer = new(DispatcherPriority.Background) { Interval = interval };
        timer.Tick += (sender, _) =>
        {
            if (!repeat)
            {
                ((DispatcherTimer)sender!).Stop();
            }

            action();
        };

        return timer;
    }

    private static void Restart(DispatcherTimer timer)
    {
        timer.Stop();
        timer.Start();
    }

    private void ShellOpen(string target)
    {
        try
        {
            Process.Start(new ProcessStartInfo(target) { UseShellExecute = true });
        }
        catch (Exception exception)
        {
            Notify($"Couldn't open {target} - {exception.Message}", NotificationKind.Error);
        }
    }

    private void SetClipboard(string text)
    {
        try
        {
            Clipboard.SetText(text);
            Notify("Copied to the clipboard", NotificationKind.Success);
        }
        catch (Exception)
        {
            Notify("The clipboard is busy - try again", NotificationKind.Warning);
        }
    }

    private static string FfmpegTime(TimeSpan time) =>
        $"{(int)time.TotalHours:00}:{time.Minutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";

    private static string UniquePath(string path)
    {
        string directory = Path.GetDirectoryName(path)!;
        string name = Path.GetFileNameWithoutExtension(path);
        string extension = Path.GetExtension(path);

        for (int i = 2; File.Exists(path); i++)
        {
            path = Path.Combine(directory, $"{name} ({i}){extension}");
        }

        return path;
    }

    #endregion
}
