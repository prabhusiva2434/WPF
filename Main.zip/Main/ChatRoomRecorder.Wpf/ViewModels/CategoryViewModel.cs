using System.Collections.ObjectModel;
using ChatRoomRecorder.Wpf.Services;
using CommunityToolkit.Mvvm.ComponentModel;

namespace ChatRoomRecorder.Wpf.ViewModels;

public sealed class CategoryViewModel : ObservableObject
{
    private string _name;
    private bool _isExpanded = true;
    private bool _isSelected;
    private bool _isEditing;
    private int _totalRooms;
    private int _liveRooms;
    private bool _hasFilterMatches = true;

    public CategoryViewModel(int id, string name, CategoryViewModel? parent)
    {
        Id = id;
        _name = name;
        Parent = parent;
    }

    public int Id { get; set; }

    public string Name { get => _name; set => SetProperty(ref _name, value); }

    public CategoryViewModel? Parent { get; set; }

    public bool IsRoot => Id == Database.RootCategoryId;

    public ObservableCollection<CategoryViewModel> Children { get; } = new();

    public ObservableCollection<RoomViewModel> Rooms { get; } = new();

    public bool IsExpanded { get => _isExpanded; set => SetProperty(ref _isExpanded, value); }

    public bool IsSelected { get => _isSelected; set => SetProperty(ref _isSelected, value); }

    public bool IsEditing { get => _isEditing; set => SetProperty(ref _isEditing, value); }

    public int TotalRooms { get => _totalRooms; private set => SetProperty(ref _totalRooms, value); }

    public int LiveRooms { get => _liveRooms; private set => SetProperty(ref _liveRooms, value); }

    //false when a filter is active and nothing in this branch matches it - the tree dims the node
    public bool HasFilterMatches { get => _hasFilterMatches; set => SetProperty(ref _hasFilterMatches, value); }

    public IEnumerable<CategoryViewModel> SelfAndDescendants()
    {
        yield return this;

        foreach (CategoryViewModel child in Children)
        {
            foreach (CategoryViewModel descendant in child.SelfAndDescendants())
            {
                yield return descendant;
            }
        }
    }

    public IEnumerable<RoomViewModel> AllRooms() => SelfAndDescendants().SelectMany(category => category.Rooms);

    public bool IsSelfOrAncestorOf(CategoryViewModel other)
    {
        for (CategoryViewModel? current = other; current != null; current = current.Parent)
        {
            if (current == this)
            {
                return true;
            }
        }

        return false;
    }

    //recomputes the counters shown next to the name, bottom up
    public void RefreshCounts(string filter)
    {
        int total = Rooms.Count;
        int live = Rooms.Count(room => room.IsOnline);
        bool matches = string.IsNullOrWhiteSpace(filter) || Rooms.Any(room => room.Matches(filter));

        foreach (CategoryViewModel child in Children)
        {
            child.RefreshCounts(filter);
            total += child.TotalRooms;
            live += child.LiveRooms;
            matches |= child.HasFilterMatches;
        }

        TotalRooms = total;
        LiveRooms = live;
        HasFilterMatches = matches;
    }

    public void SortChildren()
    {
        List<CategoryViewModel> sorted = Children.OrderBy(child => child.Name, StringComparer.CurrentCultureIgnoreCase).ToList();

        for (int i = 0; i < sorted.Count; i++)
        {
            int current = Children.IndexOf(sorted[i]);

            if (current != i)
            {
                Children.Move(current, i);
            }
        }
    }
}
